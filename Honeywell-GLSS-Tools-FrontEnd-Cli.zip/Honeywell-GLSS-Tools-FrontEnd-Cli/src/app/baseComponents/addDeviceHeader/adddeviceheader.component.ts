import { Component, Input, Output, EventEmitter } from "@angular/core";




@Component({
    selector: "add-device-header-app",
    templateUrl: "./adddeviceheader.component.html",
    styleUrls: ["./adddeviceheader.component.css"]
})
export class AddDeviceHeaderComponent {
   
    @Output() selectDeviceCategoryEvent = new EventEmitter();
   @Input() isDetector: boolean = true;
    SelectDeviceCategory(type: boolean)
    {
        this.isDetector = type;
        this.selectDeviceCategoryEvent.emit(type);
      
    }

}
