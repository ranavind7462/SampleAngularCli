import { Component, ViewChild, Input, Output, EventEmitter, ElementRef,ViewEncapsulation} from "@angular/core";
//import { CustomerDetailComponent } from "../../fireComponents/customerDetail/customer-detail.component";
import { SiteDetailComponent } from "../../fireComponents/siteDetail/site-detail.component";
import { Router } from "@angular/router";
import { StorageType, CacheComponent, StorageKey } from "../../shared/utility/cache.component";
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "sitecart-app",
    host: {
        '(document:click)': 'handleClick($event)',
    },
    templateUrl: "./sitecart.component.html",
    styleUrls: ["./sitecart.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class SiteCartComponent {
   // @ViewChild(CustomerDetailComponent)
    //private customerDetailObj: CustomerDetailComponent;

    @ViewChild(SiteDetailComponent)
    private siteDetailObj: SiteDetailComponent;

    @Output()
    editSiteEvent = new EventEmitter();

    @Output()
    deleteSiteEvent = new EventEmitter();

    @Input()
    siteCartData: any;

    @Input()
    templateIndex: any;

    //For Internaliization
    globalInstance = Globals.getInstance();
    sitecartBackground = false;
    sitecartSelected = false;
    elementRef;

    constructor(myElement: ElementRef, private route: Router, private cacheComponentObj: CacheComponent) {
        this.elementRef = myElement;
    }

    //noOfPanels = { text: "00", visible: true };
    noOfDevices = { text: "00", visible: true };
    optionVisible = { text: "", visible: false };
    gotoSite = { text: this.globalInstance.getLiteral("SITECART_SITE_BTN"), visible: true };

    panels = { text: " Panels", visible: true };
    lastUpdated = { text: this.globalInstance.getLiteral("SITE_LASTUPDATED"), visible: true };
    lastUpdatedOn = { text: "", visible: true };

    /**
     * This method is used to update the view of the customer details component based
     * on the event emitted from customer detail child component
     */
    //updateCustomerDetails() {
    //    this.customerDetailObj.customerAddress.text = this.siteCartData.Address;            
    //    this.noOfPanels.text = this.siteCartData.panelCount;
    //    if(this.siteCartData.contactName && this.siteCartData.contactName !== ""){
    //        this.customerDetailObj.customerName.text = this.siteCartData.contactName;            
    //    }
    //    if(this.siteCartData.mobileNumber && this.siteCartData.mobileNumber !== ""){
    //        this.customerDetailObj.customerContactNo.text = this.siteCartData.mobileNumber;            
    //    }
    //}

    /**
     * This method is used to update the view of the site details component based on the event
     * emitted from the site details component.
     */
    updateSiteDetails()
    {
        this.siteDetailObj.buildingName.text = this.siteCartData.label;
        this.siteDetailObj.projectId.text = this.siteCartData.siteType;//customerProjectReference;
        //this.siteDetailObj.buildingAddressLine1=
        this.siteDetailObj.buildingAddress.text = (this.siteCartData.address == null ? "" : (this.siteCartData.address + ",\n")) + (this.siteCartData.addressLine2 == null ? "" : (this.siteCartData.addressLine2 + ",\n")) + (this.siteCartData.city == null ? "" : 
            (this.siteCartData.city + ",\n")) + (this.siteCartData.country == null ? "" : (this.siteCartData.country + ",\n")) + (this.siteCartData.zipCode == null ? "" :  this.siteCartData.zipCode);
        this.siteDetailObj.lastUpdatedOn.text = (new Date(this.siteCartData.lastModifiedDate)).toLocaleDateString();
        this.siteDetailObj.panelCount.text = (this.siteCartData.panelCount < 10 ? "0" : null) + this.siteCartData.panelCount;
        if (this.siteDetailObj.buildingAddress.text === "undefined" || this.siteDetailObj.buildingAddress.text==="null")
        {
            this.siteDetailObj.buildingAddress.text = "-- Add address details here--";
        }
        
        //if(this.siteCartData.addressLine2 && this.siteCartData.addressLine2 !== ""){
        //    this.siteDetailObj.buildingAddress.text = this.siteCartData.addressLine2;
        //}        
    }

    goToSite() {
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.currentSiteId, this.siteCartData.id);
        this.route.navigateByUrl("/site");
    }

    /**
     * This method is used to display the site options popover on click of the icon.
     */
    displaySiteOptions() {
        this.optionVisible.visible = !this.optionVisible.visible;
    }

    /**
     * This method is called when the edit site option is clicked on the popover.
     */
    editSite() {
        this.optionVisible.visible = false;
        this.editSiteEvent.emit(this.siteCartData);
    }

    /**
     * This method is called when the archive site option is clicked on the popover.
     */
    archiveSite() {

    }

    /**
     * This method is called when the delete site option is clicked on the popover.
     */
    deleteSite() {
        this.optionVisible.visible = false;
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.currentSiteId, this.siteCartData.id);
        this.deleteSiteEvent.emit(this.siteCartData);
    }

    closePopOver(evt) {
        if (evt.id.split("_")[1] !== this.templateIndex.toString()) {
            this.optionVisible.visible = false;
        }
    }

    handleClick(event){
        var clickedComponent = event.target;
        var inside = false;

        /*Navigate between Parent nodes and check if one of them is current component */
        do {
           if (clickedComponent === this.elementRef.nativeElement) {
               inside = true;
           }
           clickedComponent = clickedComponent.parentNode;
        } while (clickedComponent);

        if(inside){
           this.sitecartSelected = true;
        }else{
           this.sitecartSelected = false;
           this.sitecartBackground = false;
        }
    }

    // selectSitecart(){
    //     this.sitecartSelected = true;
    // }

    onSitecartMouseHover(){
        this.sitecartBackground = true;
    }

    onSiteSitcartMouseOut(){
        if(!this.sitecartSelected){
            this.sitecartBackground = false;
        }
    }
}
