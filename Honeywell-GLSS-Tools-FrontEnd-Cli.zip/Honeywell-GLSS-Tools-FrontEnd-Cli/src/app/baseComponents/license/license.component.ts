import { Component, OnInit, ViewChild, ViewEncapsulation, ElementRef, Output, EventEmitter } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headers, Http } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { Licensetab, LicenseModel, FlexActionTypes } from "../../model/licenseModel";
import { Headerservice } from "../../fireComponents/header/header.service";
import { Globals } from '../../shared/hooks/globals';
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { LicenseService } from "../../baseComponents/license/license.service";
import { ActiveLicense } from "../../model/activeLicense";
import { LicenseHistory } from "../../model/licensesHistory"


@Component({
    selector: "license-app",
    templateUrl: "./license.component.html",
    styleUrls: ["./license.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class LicenseComponent {
   
    /**
     * This helper method gets the selected panel tab number and assigns to the selectedTab variable
     * @param num
     */
    //licensetabobj: licensetab;
    private licensetab = Licensetab;
    private flexActionTypes = FlexActionTypes;
    selectedTab = this.licensetab.Active;
    activeLicenses: ActiveLicense[] = [];
    licenseHistory: LicenseHistory[] = [];
    licenseModel = new LicenseModel();
    myVar: boolean=false;
    setTab(view: Licensetab)
    {
        this.selectedTab = view;
        switch (this.selectedTab) {

            case Licensetab.Active:
                {
                    this.activeLicenses = [];
                    this.lisenceSvcObj.GetActiveLiscenses().then(response => {
                        console.log(response)
                        this.activeLicenses = response;
                        console.log(this.activeLicenses);
                    }
                    );
                    break;
                }
            case Licensetab.History:
                {
                    this.licenseHistory = [];
                    this.lisenceSvcObj.GetLiscenseActivityHistroy().then(response => {
                        console.log(response)
                        this.licenseHistory = response;
                        console.log(this.licenseHistory);
                    }
                    );
                    break;
                }
        }
     
      }
   
    globalInstance = Globals.getInstance();
    constructor(private lisenceSvcObj: LicenseService, private headerserviceObj: Headerservice, private http: Http, private serviceUrlObj: ServiceUrl, private errorHandlerObj: MyErrorHandler, private cacheComponentObj: CacheComponent) {
       headerserviceObj.dispatchAction("License");
        this.setTab(Licensetab.Active);

    }

    /**
     * This helper function returns true if the number equals to the currently selected tab. It is used to apply the
     * appropriate css class to the tab control to indicate the "selected/unselected status" of a tab
     * @param num
     */
    isSelected(view: Licensetab) {
        return this.selectedTab === view;
    }

    activateOrTerminate(typeAction: FlexActionTypes)
    {
        this.myVar = true;
        this.licenseModel.action = typeAction;
        this.lisenceSvcObj.activateOrTerminateLicKey(this.licenseModel).then(response => {
            console.log(response)
            this.activeLicenses = response;
            this.selectedTab = Licensetab.Active;
            this.licenseModel = new LicenseModel();
            console.log(this.activeLicenses);
            this.myVar = false;
            if (this.activeLicenses.length > 0) {
                this.cacheComponentObj.setKeyData(StorageType.LocalStorage,
                    StorageKey.isLicenseAvailable,
                    true);
            }
            else
                this.cacheComponentObj.setKeyData(StorageType.LocalStorage,
                    StorageKey.isLicenseAvailable,
                    false);
            console.log(this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.isLicenseAvailable));

        });
       
    }

}

