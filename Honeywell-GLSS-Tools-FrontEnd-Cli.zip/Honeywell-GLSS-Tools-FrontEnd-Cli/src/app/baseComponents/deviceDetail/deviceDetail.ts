import { Component, ViewChild, Input, DoCheck, Output, EventEmitter } from '@angular/core';
import { Globals } from "../../shared/hooks/globals";
import { DeviceService } from "../../baseComponents/device/device.service";
import { Headerservice } from "../../fireComponents/header/header.service";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";
import { DeviceInfoComponent } from "../../fireComponents/deviceInfo/deviceinfo";
import { DeviceListComponent } from "../../fireComponents/deviceList/devicelist";
import { Detector } from "../../model/detectorModel";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { DeviceTypes } from "../../model/DetailsTypes";
import { Types } from "../../model/DetailsTypes";


import { Loop } from "../../model/loop";

@Component({
    selector: 'devicedetail-app',
    templateUrl: "./devicedetail.html",
    styleUrls: ["./devicedetail.css"],
})

export class DeviceDetailComponent {


    @Input() selectedLoop: Loop;
    deviceDefaultView = { visible: false };

    devices: Detector[];

    detailTypes: Types[] = [];
    deviceTypes: DeviceTypes[] = [];
    //@Input() selectedDevice: Device;

    @ViewChild(DeviceInfoComponent)
    deviceInfoComponentObj: DeviceInfoComponent;

    @ViewChild(DeviceListComponent)
    deviceListComponentObj: DeviceListComponent;



    //For Internaliization
    globalInstance = Globals.getInstance();
    deviceDefaultTxt = { text: this.globalInstance.getLiteral("DEVICE_DEFAULT_TEXT"), visible: true };
    addDevice = { text: this.globalInstance.getLiteral("DEVICE_ADD_DEVICES"), visible: true };
    //deleteConfirmationMsg = { text: this.globalInstance.getLiteral("DEVICE_DELETE_CONFIRMATION_MSG"), visible: true };
    //delete = { text: this.globalInstance.getLiteral("COMMON_DELETE"), visible: true };

    constructor(private cacheComponentObj: CacheComponent, private headerserviceObj: Headerservice,
        private deviceServiceObj: DeviceService, private detailsServiceObj: DetailsService) {
        //this.headerserviceObj.dispatchAction(`>${this.globalInstance.getLiteral("PANEL_AND_LOOPS")}`);
    }

    ngOnInit() {
        this.getDeviceTypes(true);
        this.populateDevices(this.selectedLoop.id);
    }


    getDeviceTypes(isDetector: boolean) {
        this.detailsServiceObj.getDeviceTypesSrvc().subscribe(response => { this.populateDeviceTypesList(response, isDetector) });
    }


    populateDeviceTypesList(resp, isDetector) {
        if (resp !== undefined) {
            this.deviceTypes = resp;

            this.detailsServiceObj.updateCache(this.deviceTypes, true);
            this.detailTypes = this.detailsServiceObj.types;
        }
        console.log(this.deviceTypes);
    }



    populateDevices(loop: number) {
        this.deviceServiceObj.getDetectorsSrvc(loop).subscribe(response => { this.populateDevicesDetails(response) });

    }
    currentDevice: Detector = null;
    populateDevicesDetails(resp) {
        if (resp) {
            this.devices = resp;
            this.devices.forEach(i => {
                i.deviceTypeLabel = this.getDeviceTypeDescription(i.deviceTypeId);
                i.deviceAddressLabel = this.globalInstance.getAddress(1, i.loopId, i.deviceAddress.toString(), true);
            });
        }
        if (this.devices && this.devices.length > 0)
        this.currentDevice = this.devices[0];
        this.updateDefaultScreen();
      //this.devicesCountEvent.emit(this.devices != null ? this.devices.length : 0);
    }

    getDeviceTypeDescription(typeId: number) {
        if (this.detailTypes !== undefined) {
            var deviceTyp = this.detailTypes.filter(i => i.value == typeId);
            return deviceTyp[0].display;
        }
        return typeId.toString();
    }



    updateDefaultScreen() {
        if (this.devices && this.devices.length > 0) {
            this.deviceDefaultView.visible = false;
        }
        else {
            this.deviceDefaultView.visible = true;
        }
    }

    deviceInfo(device: Detector)
    {
        this.currentDevice = device;
    }

    // delete the devices based on the device id passed
    deleteDevices() {
        var keys: any[] = [];
        keys.push(this.currentDevice.id);
        debugger;
        this.deviceServiceObj.deleteDevicesSrvc(keys).then(
            response => {
                if (response.ok) {
                    this.populateDevices(this.selectedLoop.id);
                }
            },
            error => {
                console.log(error);
            }
        );

    }
   

    onDeviceDeleted($event)
    {
        this.ngOnInit();
    }

    


}

