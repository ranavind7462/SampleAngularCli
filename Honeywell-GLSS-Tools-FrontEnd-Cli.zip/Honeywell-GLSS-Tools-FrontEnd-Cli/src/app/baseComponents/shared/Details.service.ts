import { Injectable } from "@angular/core";
import { Headers, Http, Response  } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { Observable } from "rxjs";
import "rxjs/Rx";
//import "rxjs/add/operator/map";
import { ProgZoneTypes, DeviceTypes } from "../../model/DetailsTypes";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
//import { contentHeaders } from "../../shared/api/header";
import { Config } from '../../shared/hooks/config';
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Types } from "../../model/DetailsTypes";
import { DeviceType } from "../../model/enums";


@Injectable()
export class DetailsService {

    types: Types[] = [];
    deviceTypes: DeviceTypes[];
    detectorsTypes: Types[] = [];
    moduleTypes: Types[] = [];
    progZoneTypes: ProgZoneTypes[];
    deviceTypedesc: string;

    
    constructor(private cacheComponentObj: CacheComponent, private http: Http, private serviceUrlObj: ServiceUrl, private errorHandlerObj: MyErrorHandler) {

    }


    getDeviceTypesById(typeId: number): any {
        if (this.deviceTypes != null && this.deviceTypes.length > 0) {
            var deviceTyp = this.deviceTypes.filter(i => i.id == typeId);
            return deviceTyp[0].deviceType;
        }
        else {
            this.getDeviceTypesSrvc().subscribe(data => {
                this.updateCache(data, true);
                this.deviceTypes = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.deviceTypes);
                this.getDeviceTypesById(typeId);
            });
           
        }

        return typeId;
    }


    getDeviceTypes(isDetector: boolean) {
        debugger;
        this.types = new Array<Types>();
        // this.deviceTypes = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.deviceTypes);
        if (this.deviceTypes == null) {

            this.getDeviceTypesSrvc().subscribe(data => { this.updateCache(data, isDetector); });
            this.deviceTypes = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.deviceTypes);

        }
        else {
            this.updateCache(this.deviceTypes, isDetector);
        }
        console.log(this.deviceTypes);


        return this.deviceTypes;
    }


    getProgZoneTypes() {
        this.progZoneTypes = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.progZoneTypes);
        if (this.progZoneTypes == null) {

            this.getProgZoneTypesSrvc().subscribe(data => { this.updateZoneCache(data) });
            this.progZoneTypes = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.progZoneTypes);
        }
        console.log(this.progZoneTypes);
        return this.progZoneTypes;

    }

    getDeviceTypesSrvc(): Observable<DeviceTypes[]> {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetDeviceTypes);
        return this.http
            .get(getSvcUrl)
            .map((response: Response) => response.json());
    }


    updateCache(resp: DeviceTypes[], isDetector: boolean) {
        this.types = new Array<Types>();
        console.log(resp);
        resp.filter(k => k.isDetector == isDetector).map(j => {
            var t = new Types();
            t.value = j.id;
            t.display = j.deviceType;
            t.imageUrl = this.getImageUrl(j.id);
            this.types.push(t);
        }
        )

        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.deviceTypes, resp);
    }

    getImageUrl(deviceType): string
    {

        switch (deviceType)
        {
            case DeviceType.Optical_Smoke:
                {
                    return "app/shared/images/Optical.png";
                }         
            case DeviceType.Heat_Sensor:
                {
                    return "app/shared/images/HeatSensor.png"
                }
            case DeviceType.Multi_Sensor:
                {
                    return "app/shared/images/Multi.png"
                }
            case DeviceType.Duct_Sensor:
                {
                    return "app/shared/images/Duct.png"
                }
            case DeviceType.Beam_Sensor:
                {
                    return "app/shared/images/Beam.png"
                }
            case DeviceType.Sounder:
                {
                    return "app/shared/images/Sounders.png"
                }
            case DeviceType.Relay:
                {
                    return "app/shared/images/Relay.png"
                }
            case DeviceType.CallPoint:
                {
                    return "app/shared/images/CallPoint.png"
                }
            case DeviceType.CTRL:
                {
                    return "app/shared/images/ControlModule.png"
                }
            case DeviceType.ZoneMonitor:
                {
                    return "app/shared/images/ZoneMonitor.png"
                }
        }

    }


    updateZoneCache(resp: ProgZoneTypes[]) {
        console.log(resp);
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.progZoneTypes, resp);
    }
    /**
     * This is a service method which makes a rest call to the webapi for fetching the prog zone type details.
    */
    getProgZoneTypesSrvc(): Observable<ProgZoneTypes[]> {
        const getprogZoneTypesUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetProgZoneTypes);
        return this.http
            .get(getprogZoneTypesUrl)
            .map((response: Response) => response.json());
            //.map((response) => {
            //    const data = response.text();
            //    return data; // Change it on integration with proper API.
            //},
            //response => {
            //    const data = response.text();
            //    return data; // Change it on integration with proper API.
            //})

    }
}
