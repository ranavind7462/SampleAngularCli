﻿import { Injectable } from "@angular/core";
import { Headers, Http } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { ActiveSites } from "../../model/activeSites";
import { CustomerSite } from "../../model/customerSite";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from '../../shared/hooks/config';

@Injectable()
export class ActiveSitesService {

    constructor(private http: Http, private serviceUrlObj: ServiceUrl, private configObj: Config, private errorHandlerObj: MyErrorHandler) { }

    /**
     * This is a service method which makes a rest call to the webapi for fetching list of active sites
     * for the logged in user.
     */
    getActiveSitesSrvc(): Promise<ActiveSites[]> {
        const activeSitesUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetActiveSites);
        return this.http
            .get(activeSitesUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data; // Change it on integration with proper API.
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching the current site details based on the
     * site id passed.
     */
    getCurrentSiteSrvc(siteId: string): Promise<CustomerSite[]> {
        const currentSiteUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetSite) + "/" + siteId;
        return this.http
            .get(currentSiteUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data; // Change it on integration with proper API.
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    /**
     * This is a service method which makes a rest call to the web-api for creating a site
     * through the add new site popup.
     */
    createSiteSrvc(siteObj) {
        const postSiteUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.AddNewSite);
        return this.http
            .post(postSiteUrl, siteObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    /**
     * This is a service method which makes a rest call to the web-api for updating a site
     * through the add new site popup.
     */
    editSiteSrvc(siteObj) {
        const siteId = JSON.parse(siteObj).id;
        const putSiteUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.EditSite) + "/" + siteId;
        return this.http
            .put(putSiteUrl, siteObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    deleteSiteSrvc(siteId: string) {
        const deleteSitesUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.DeleteSite) + "/" + siteId.replace(/"/g, "");
        return this.http
            .delete(deleteSitesUrl)
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                console.log(response);
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }
    CheckSiteNFR() {
        let checkNFRUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.CheckSiteNFR);
        return this.http
            .get(checkNFRUrl)
            .toPromise()
            .then(response => {
                console.log(response);
                return response;
            },
            response => {
                return response;
            }).catch(this.errorHandlerObj.handleServerError);
    }
}