﻿import { Injectable, Input } from "@angular/core";
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { AddDevices } from "../../model/addDevices";
import { Detector } from "../../model/detectorModel";
import { Module } from "../../model/modulesModel";
import { Observable } from "rxjs";
import { Device } from "../../model/Device";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from "../../shared/hooks/config";


@Injectable()
export class DeviceService {

    constructor(private http: Http,
        private serviceUrlObj: ServiceUrl,
        private configObj: Config,
        private errorHandlerObj: MyErrorHandler) {
        this.serviceUrlObj = new ServiceUrl(this.configObj);
    }

    /**
        * This is a service method which makes a rest call to the web-api for creating a Bulk Detectors and Modules for the loop
        * through the add devices popup.
        */
    addDetectorsModulesSrvc(addDeviceObj) {
        const postSiteUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Device);
        return this.http
            .post(postSiteUrl, addDeviceObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching list of detectors by loop id
     */
    getDetectorsSrvc(loopId: number): Observable<Detector[]> {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetDetectors);
        const re = /\/id\//g;
        getSvcUrl = getSvcUrl.replace(re, `/${loopId}/`);
        debugger;
        return this.http
            .get(getSvcUrl)
            .map((response: Response) => response.json())
            .catch(this.errorHandlerObj.handleServerError);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching list of modules by loop id
     */
    getModulesSrvc(loopId: number): Promise<Module[]> {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetModules);
        const re = /\/id\//g;
        getSvcUrl = getSvcUrl.replace(re, `/${loopId}/`);
        return this.http
            .get(getSvcUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    deleteDevicesSrvc(devices: Detector[]) {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Detector);
        return this.http.delete(getSvcUrl, new RequestOptions({
            headers: contentHeaders,
            body: devices
        }))
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                console.log(response);
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    updateDevicesSrvc(devices: Detector[]) {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Detector);
        return this.http
            .put(getSvcUrl, devices, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }
    /**
        * This is a service method which makes a rest call to the web-api for creating a Bulk Detectors and Modules for the loop
        * through the add devices popup.
        */
    addDetectorsSrvc(detectorsList:Detector[]) {
        const postdetectorUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Detector);
        return this.http
            .post(postdetectorUrl, detectorsList, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }
    addModulesSrvc(modulesList: Module[]) {
        const postmoduleUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Modules);
        return this.http
            .post(postmoduleUrl, modulesList, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

}
