import { Component } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';

@Component({
    selector: "site-app",
    templateUrl: "./site.component.html",
    styleUrls: ["./site.component.css"]
})
export class SiteComponent {

    constructor(private cacheComponentObj: CacheComponent,
        private router: Router) {

        /*  Route event types
            NavigationEnd
            NavigationCancel
            NavigationError
            RoutesRecognized
        */

        //Before Navigation Start
        router.events.forEach((event: NavigationEvent) => {
            if (event instanceof NavigationStart) {
                switch (event.url) {
                case "/site/siteoverview":
                {
                    break;
                }
                case "/site/panel":
                {
                    this.cacheComponentObj.deleteKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
                    break;
                }
                }
            }

            //After Navigation End
            if (event instanceof NavigationEnd) {
                switch (event.url) {
                case "/site/siteoverview":
                {
                    break;
                }
                case "/site/panel":
                {
                    break;
                }
                }
            }
        });
    }

    changeOfRoutes(obj) {}
}
