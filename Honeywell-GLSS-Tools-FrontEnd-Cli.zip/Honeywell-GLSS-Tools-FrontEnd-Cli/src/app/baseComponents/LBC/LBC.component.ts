import { Component, OnInit, ViewChild, ViewEncapsulation, ElementRef, Output, EventEmitter, Input } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Globals } from "../../shared/hooks/globals";
import { LBCPanel } from "../../model/LbcPanel";
import { LBCDataService } from "../../fireComponents/lbcData/lbcdata.service";
import { Loop, LBCLoopContentView } from "../../model/Loop";
import { LBCLoop } from "../../model/LBCLoop";
import { LBCDevices } from "../../model/LBCDevices";
import { PanelService } from "../../baseComponents/panel/panel.service";

@Component({
    selector: "LBC-app",
    templateUrl: "./LBC.component.html",
    styleUrls: ["./LBC.component.css"],
    encapsulation: ViewEncapsulation.None
})

export class LBCComponent {

    lbcDataDetails: LBCPanel;
    loopValue: LBCLoop;
    panelInfoDetails: string;
    private lBCLoopContentView = LBCLoopContentView;
    selectedTab = this.lBCLoopContentView.Devices;
    //For Internationalization
    globalInstance = Globals.getInstance();
    loopbatteryCalc = { text: this.globalInstance.getLiteral("LBC_HEADER"), visible: true };    
    ngOnInit() {
        const selectedPanelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        if (selectedPanelId) {
            this.panelServiceObj
                .getPanel(selectedPanelId)
                .then(response =>
                    this.panelInfoDetails = response.label
                    );
        }
       // this.panelInfoDetails = "Orion Tower 1 Honeywell, Bangalore";
       
        this.getLBCData();        
    }
  
    constructor(private cacheComponentObj: CacheComponent, private lbcServiceObj: LBCDataService, private panelServiceObj: PanelService) {
    }
    isSelected(view: LBCLoopContentView) {
        return this.selectedTab === view;
    }
    setTab(view: LBCLoopContentView) {
        this.selectedTab = view;
    }
    getLBCData() {
        const selectedPanelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        this.lbcServiceObj.getLBCData(selectedPanelId).then(response => this.populateLBCContent(response));
    }
    populateLBCContent(resp) {
        console.log(resp);
        this.lbcDataDetails = resp;
        this.lbcDataDetails.loopsList.forEach(i => {
            i.percentageValue = (i.totalLoopAlarmCurrent / 500) * 100;
            if (i.percentageValue > 100) {
                i.percentageValue = 100;
            }
        })
        if (this.lbcDataDetails.loopsList.length>0)
        this.loopValue = this.lbcDataDetails.loopsList[0];
        // this.lbcpanel.loops
    }
    LoopEventValue(loop: LBCLoop)
    {
        debugger;
        console.log(loop);
        this.loopValue = loop;
    }  
}
