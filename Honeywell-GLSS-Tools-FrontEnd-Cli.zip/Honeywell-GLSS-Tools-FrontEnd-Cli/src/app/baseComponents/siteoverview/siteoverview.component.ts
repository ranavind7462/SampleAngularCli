import { Component, OnInit, ViewChild,ElementRef,ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { ActiveSitesService } from "../shared/active-sites.service";
import { Headerservice } from "../../fireComponents/header/header.service";
import { Globals } from "../../shared/hooks/globals";
import { AddNewSiteComponent } from "../../fireComponents/addNewSite/add-new-site.component";
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";
import { CustomerSite } from "../../model/customerSite";
import { AddNewPanelComponent } from "../../fireComponents/addNewPanel/add-new-panel.component";

import { Panel } from "../../model/panel";
import { PanelService } from "../panel/panel.service";
import { ImportConfigurationComponent } from "../../fireComponents/importConfiguration/import_configuration.component";
import { NFRChecking } from "../../model/enums";

@Component({
    selector: "siteoverview-app",
    templateUrl: "./siteoverview.component.html",
    styleUrls: ["./siteoverview.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class SiteoverviewComponent implements OnInit {

    @ViewChild(AddNewSiteComponent)
    modal: AddNewSiteComponent;

    @ViewChild(DeletePopupComponent)
    deleteModal: DeletePopupComponent;

    @ViewChild(AddNewPanelComponent)
    panelModal: AddNewPanelComponent;
    IsCreatepanel = true;   
     
    constructor(private route: Router, private cacheComponentObj: CacheComponent,
        private activeSitesSrvcObj: ActiveSitesService,
        private headerserviceObj: Headerservice,
        private panelServiceObj: PanelService) {
      
    }

    //For Internaliization
    globalInstance = Globals.getInstance();
    currentSite: CustomerSite = new CustomerSite();
    addMode: boolean = true;
    numberOfPanels: number = 0;

    siteOverviewVisibility = "hidden";

    siteoverviewTitle = {
        text: this.globalInstance.getLiteral("SITE_OVERVIEW_SITEDEDAILS"),
        visible: true
    };
    siteText = { text: this.globalInstance.getLiteral("SITE_OVERVIEW_SITE"), visible: true };
    referenceText = {
        text: this.globalInstance.getLiteral("SITE_OVERVIEW_REFERENCENO"),
        visible:
            true
    };
    customerNameText = {
        text: this.globalInstance.getLiteral("SITE_OVERVIEW_CUSTOMERNAME"),
        visible: true
    };
    siteContact = { text: this.globalInstance.getLiteral("SITE_OVERVIEW_SITECONTACT"), visible: true };
    customerNoText = { text: this.globalInstance.getLiteral("SITE_OVERVIEW_CUSTOMERNO"), visible: true };
    emailText = { text: this.globalInstance.getLiteral("ADDNEWSITE_EMAIL"), visible: true };
    siteName = { text: "", visible: true };
    referenceNo = { text: "", visible: true };
    customerName = { text: "", visible: true };
    siteAddress = { text: "", visible: true };
    siteContactName = { text: "", visible: true };
    siteAddress2 = { text: "", visible: true };
    customerNo = { text: "", visible: true };
    email = { text: "", visible: true };

    lastUpdatedOn = { text: "", visible: true };
    lastUpdated = { text: this.globalInstance.getLiteral("SITE_LASTUPDATED"), visible: true };
    contactNo = { text: "Contact No.", visible: true };
    installerName = { text: "Installer Name", visible: true };
    siteAddressText = { text: "Site Address", visible: true };
    archive = { text: "Archive", visible: true };
    delete = { text: "Delete", visible: true };
    edit = { text: "Edit", visible: true };


    panelDefaultTxt = { text: this.globalInstance.getLiteral("PANEL_PANELDEFAULTMSG"), visible: true };
    addPanel = { text: this.globalInstance.getLiteral("SITE_ADDPANEL"), visible: true };
    panelSavedConfigTxt = { text: this.globalInstance.getLiteral("PANEL_OPEN_SAVED_CONFIGURATION_FILE"), visible: true };
    or = { text: this.globalInstance.getLiteral("SITE_OR"), visible: true };
    defaultText = { text: this.globalInstance.getLiteral("SITE_DEFAULT_TEXT"), visible: true };

    panelsFirmware = { text: this.globalInstance.getLiteral("SITE_PANELS_FIRMWARE"), visible: true };
    panelNeedUpdate = { text: this.globalInstance.getLiteral("SITE_PANEL_NEED_UPDATE"), visible: true };
    currentFirmwareVersion = { text: this.globalInstance.getLiteral("SITE_CURRENT_FIRMWARE_VERSION"), visible: true };
    totalNumberOfPanels = { text: this.globalInstance.getLiteral("SITE_TOTAL_NUMBER_OF_PANELS"), visible: true };


ngOnInit() {

    this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.isSiteSwitched, false);
    this.getCurrentSite();
    this.checkPanelNFR();
    }

    getCurrentSite()
    {
        this.activeSitesSrvcObj
            .getCurrentSiteSrvc(this.cacheComponentObj.getKeyData(StorageType.LocalStorage, "currentSiteId"))
            .then(response => this.populateSiteOverview(response));
    }

    populateSiteOverview(resp): any
    {
        this.siteName.text = resp.label;
        this.referenceNo.text = resp.siteType;
        this.siteAddress.text = resp.address;
        this.siteAddress2.text = resp.addressLine2;
        this.lastUpdatedOn.text = (new Date(resp.lastModifiedDate)).toLocaleDateString();
        this.headerserviceObj.dispatchAction(resp.label +
            " > " +
            this.globalInstance.getLiteral("SITE_OVERVIEW"));
        this.siteOverviewVisibility = "visible";

        this.numberOfPanels = resp.panelCount;

        this.createSiteModel(resp);
    }

    createSiteModel(siteData){
        this.currentSite.id = siteData.id;
        this.currentSite.label = siteData.label;
        this.currentSite.address = siteData.address;
        this.currentSite.addressLine2 = siteData.addressLine2;
        this.currentSite.zipCode = siteData.zipCode;
        this.currentSite.city = siteData.city;
        this.currentSite.country = siteData.country;
        this.currentSite.siteType = siteData.siteType;
        this.currentSite.panelCount = siteData.panelCount;
        this.siteAddress.text = siteData.label+",\n"+ (siteData.address == null ? "" : siteData.address + ",\n") +
            (siteData.addressLine2 == null ? "" : siteData.addressLine2 + ",\n") + (siteData.city == null ? "" :
            siteData.city+",\n") + (siteData.country == null ? "" : siteData.country+",\n") + (siteData.zipCode == null ? "" :  siteData.zipCode);
        if (this.siteAddress.text === "null")
        {
            this.siteAddress.text = "";
        }
    }

    openEditView(){
        this.modal.popupLbl.text = this.globalInstance.getLiteral("ADDNEWSITE_HEADER_EDIT");
        this.modal.importFile.visible = false;
        this.modal.confirm.text = this.globalInstance.getLiteral("COMMON_SAVE");
        this.modal.cancel.visible = true;
        this.modal.currentSite = Object.assign({}, this.currentSite);
        if (!this.modal.currentSite.siteType || this.modal.currentSite.siteType === null) {
            this.modal.currentSite.siteType = "NONE";
        }
        else {
            console.log(this.modal.currentSite.siteType);
            this.modal.selectTypeLabel.text = this.modal.currentSite.siteType;
            console.log(this.modal.selectTypeLabel.text);
            //this.modal.selectedSiteType = this.modal.currentSite.siteType;
        }
        this.addMode = false;        
    }

    editSite(editSiteData){
        this.activeSitesSrvcObj.editSiteSrvc(editSiteData).then(
            response => {
                if (response.json() != NFRChecking.Duplicate) {
                    var data = response;
                    this.getCurrentSite();
                    this.modal.onClose();
                }
                else if (response.json() == NFRChecking.Duplicate) {
                    this.modal.isWarning = true;
                    console.log(response);
                }
                error => {
                    console.log(error);
                }
            }
        );
    }

    openDeleteView(){
        this.deleteModal.currentDeleteObj.id =  "Site"; 
        this.deleteModal.currentDeleteObj.label = this.currentSite.label;
        this.deleteModal.currentDeleteObj.siteType = this.currentSite.siteType;//customerProjectReference;
        this.deleteModal.lastUpdatedOn.text = (new Date(this.lastUpdatedOn.text)).toLocaleDateString();
        this.deleteModal.currentDeleteObj.address = this.currentSite.address + "," + this.currentSite.addressLine2 + "," + this.currentSite.city + "," +
            this.currentSite.zipCode + "," + this.currentSite.country
    }

    deleteSiteData(){
        this.activeSitesSrvcObj.deleteSiteSrvc(this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId)).then(
            response => {
                var data = response;
                this.route.navigateByUrl("/dashboard");
            },
            error => {
                console.log(error);
            }
        );
    }

    /**
   * This method is used to post a service request and update the newly added panel.
   * @param obj : it is the data object created from the user inputs on add new popup page.
   */
    createPanel(obj: Panel): void
    {
        obj.siteId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
        this.panelServiceObj.createNewPanelSrvc(obj).then(
            response =>
            {
                debugger;
                if (response.json() != NFRChecking.Duplicate)
                {
                    const data = response.json();
                    this.numberOfPanels = 1;
                    this.panelModal.onClose();
                }               
                else if (response.json() == NFRChecking.Duplicate) {
                    this.panelModal.isWarning = true;
                    this.panelModal.panelWarning.text = this.globalInstance.getLiteral("PANEL_IMPORT_CONFIG_EXIST_MSG");
                    console.log(response.status);

                }
            },
            error => {
                console.log(error);
            }
        );
    }
    importPanelObj: any;
    overRidePanelObj: any;
    isSpinner: boolean = false;
    @ViewChild("importconfirmBtn") importconfirmBtn: ElementRef;

    @ViewChild(ImportConfigurationComponent) importconfirmModal: ImportConfigurationComponent;
    importConfiguration(panelObje: any) {
        var panelName = panelObje.panelList[0].label;
        this.importPanelObj = panelObje;

        var siteId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
        this.panelServiceObj.checkPanelDeuplication(panelName, siteId).then(res => {
            if (res.json() == NFRChecking.Duplicate) {
                this.overRidePanelObj = res.json();
                this.importconfirmModal.error = "";
                this.importconfirmModal.panelLabel = this.overRidePanelObj.label + " " + this.importconfirmModal.panelImportConfig.text;
                this.importconfirmModal.isSaveAsNew = false;
                this.importconfirmModal.isOverride = false;
                this.importconfirmModal.panelName = "";
                this.importconfirmModal.isDoneEnabled = false;
                this.importconfirmBtn.nativeElement.click();
            }
            else {

                this.CallImportSavinfSrvc(panelObje);
                // console.log(res);
            }

        });
        //.then((data) => {

        //    console.log(data);

        //});
    }
    CallImportSavinfSrvc(panelObje: any) {
        this.panelModal.onClose();
        this.isSpinner = true;
        panelObje.panelList[0].siteId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
        this.panelServiceObj.importConfigurationSrv(panelObje).subscribe(resp => {
            console.log(resp);
            this.numberOfPanels = 1;
            //this.getPanels();
            this.isSpinner = false;
        },
            (error) => {
                console.log("test");
            });
    }
    SaveORImportConfig(panelName: string) {
        console.log("import dublicate");
        if (panelName == "overwrite") {
            this.panelServiceObj.deletePanelSrvc(this.overRidePanelObj.id).then(res => {

                this.CallImportSavinfSrvc(this.importPanelObj);
                this.importconfirmModal.onClose();
            })
        }
        else {
            var siteId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
            this.panelServiceObj.checkPanelDeuplication(panelName, siteId).then(res => {
                if (res.json() == NFRChecking.Duplicate) {
                    this.importconfirmModal.error = "Panel name already exists."
                }
                else {
                    this.importPanelObj.panelList[0].label = panelName;

                    this.CallImportSavinfSrvc(this.importPanelObj);
                    this.importconfirmModal.onClose();

                }
            });
        }
        console.log(this.importPanelObj);
    }
    @ViewChild("importfile")
    importfile: ElementRef;
    errorMsg: string = "";
    selectImportConfiguration() {
       // this.closeBtn.nativeElement.focus();
        this.errorMsg = "";
        this.importfile.nativeElement.click();
    }
    getFiles(event) {

        var files = event.target.files;
        console.log(files[0]);
        if (files[0].type == "text/plain") {
            if (files[0].size != 0) {
                var reader = new FileReader();
                reader.onload = this._handleReaderLoaded.bind(this);
                reader.readAsBinaryString(files[0]);
            }
            else {
               this.errorMsg = "Invalid file.";
            }
        }
        else {
            this.errorMsg = "It is not valid file type.It will support only text file."
        }
        this.importfile.nativeElement.value = "";
    }
    filestring: string;
    _handleReaderLoaded(readerEvt) {
        try {
            var binaryString = readerEvt.target.result;
            this.filestring = JSON.parse(binaryString);
            console.log(this.filestring);// Converting binary string data.
            this.importConfiguration(this.filestring);
        }
        catch (Error) {
            this.errorMsg = "Invalid file.";
        }
    }
    checkPanelNFR(): any {
        debugger;
        this.panelServiceObj.CheckPanelNFR().then(response => {
            if (response.json() == NFRChecking.LimitExceded) {
                this.IsCreatepanel = false;
                return false;

            }
            else {
                this.IsCreatepanel = true;
                return true;
            }
            
        },
            error => {
                console.log(error);
                this.IsCreatepanel = false;
                return false;
            }
        );
    }
}
