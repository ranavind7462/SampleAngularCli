import { Component, OnInit, Output, EventEmitter, ViewChild, Input } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { PanelService } from "../../baseComponents/panel/panel.service";
import { DeviceService } from "../../baseComponents/device/device.service";
import { Panel, PanelType } from "../../model/panel";
import { Device, DeviceContentView, ContentViewType } from "../../model/device";
import { ActivatedRoute } from "@angular/router";
import { Globals } from "../../shared/hooks/globals";
import { DeviceComponent } from "../../baseComponents/device/device.component";
import { LoopoverviewComponent } from "../../fireComponents/loopoverview/loopoverview.component";
import { Loop } from "../../model/loop";
import { DeviceDetailComponent } from "../../baseComponents/deviceDetail/deviceDetail";
import { ModulesComponent } from "../../baseComponents/modules/modules.component";
import { LoopService } from "./loop.service";
import { FilterCriteria } from "../../model/DetailsTypes";
@Component({
    selector: "loop-app",
    templateUrl: "./loop.component.html",
    styleUrls: ["./loop.component.css"]
})
export class LoopComponent implements OnInit {

    @Output()
    updateTreeViewEvent = new EventEmitter();

    @Input() currentLoop: Loop;
    //addMode: boolean = true;

    //For Internaliization
    globalInstance = Globals.getInstance();
    isDeviceDetail: boolean = false;

    selectedTab = DeviceContentView.Overview;
    private contentViewType = ContentViewType;
    private loopContentView = DeviceContentView;
    isDetectorBtn: boolean= true;
    @ViewChild(DeviceComponent)
    deviceComponentObj: DeviceComponent;
    @ViewChild(ModulesComponent)
    moduleComponentObj: ModulesComponent;

    @ViewChild(DeviceDetailComponent)
    deviceDetailComponentObj: DeviceDetailComponent;

    @ViewChild("loopOverView")
    loopoverviewComponentObj: LoopoverviewComponent;
    loops: Loop[];
    filterIcon: string = "app/shared/images/Filter.png";
    addDevices = { text: this.globalInstance.getLiteral("DEVICE_ADD_DEVICES"), visible: true };
    overview = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW"), visible: true };
    devices = { text: this.globalInstance.getLiteral("DEVICES"), visible: true };
    detectors = { text: this.globalInstance.getLiteral("DETECTORS"), visible: true };

    modules = { text: this.globalInstance.getLiteral("MODULES"), visible: false };
    filter = { text: this.globalInstance.getLiteral("FILTER"), visible: false };
    editloop = { text: this.globalInstance.getLiteral("LOOP_SETTINGS_EDIT_LOOP"), visible: true };
    ///TODO: Get from the cache
    currentPanelLbl:string="";
    currentLoopDisplayValue = { text: "Loop" };

    srcListView:string = this.isDeviceDetail ? "app/shared/images/listViewDefaultState.png" : "app/shared/images/listViewActiveState.png";
    srcDetailView:string = this.isDeviceDetail ? "app/shared/images/DetailViewSelected.png" : "app/shared/images/DetailView.png";
    //listViewDefaultState = "app/shared/images/listViewDefaultState.png";
    //listViewActiveState = "app/shared/images/listViewActiveState.png";




    constructor(private cacheComponentObj: CacheComponent, private loopServiceObj: LoopService,
        private deviceServiceObj: DeviceService, private panelServiceObj:PanelService) {
    }

    ngOnInit() {
        const selectedPanelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        if (selectedPanelId) {
            this.panelServiceObj
                .getPanel(selectedPanelId)
                .then(response => this.populatePanelContent(response));
        }
        this.updateContentOnUi();
    }

    populatePanelContent(resp)
    {
        this.currentPanelLbl = resp.label;
    }

    populateDeviceContent(resp): any {

    }

    setTab(view: DeviceContentView) {
        this.selectedTab = view;
        this.updateContentOnUi();
    }
    setModuleDetector(isDetector: boolean)
    {
        this.selectedTab = DeviceContentView.Devices;
        this.isDetectorBtn = isDetector;
    }
    updateContentOnUi(): any {
        switch (this.selectedTab) {


            case DeviceContentView.Devices:
                {
                    if (this.isDetectorBtn) {
                        if (this.deviceComponentObj) {
                            this.deviceComponentObj.populateDevices(this.currentLoop.id);
                        }
                    }
                    else
                    {
                        if (this.moduleComponentObj) {
                            this.moduleComponentObj.populateDevices(this.currentLoop.id);
                        }
                    }
                    break;
                }
            case DeviceContentView.Overview:
                {
                    this.getLoopResponse();                    
                    break;
                }
            case DeviceContentView.Modules:
                {
                    break;
                }
            case DeviceContentView.DevicesDetail:
                {
                    if (this.deviceComponentObj) {
                        this.deviceComponentObj.populateDevices(this.currentLoop.id);
                    }
                    break;
                }
        }
    }

    isSelected(view: DeviceContentView) {
        return this.selectedTab === view;
    }

    ngOnChanges() {
        if (!!this.currentLoop) {
            this.updateContentOnUi();
        }
    }

    UpdateDeviceCount(count: number)
    {
        if (!!this.currentLoop)
            this.currentLoop.deviceCount = count;
    }

    // Loop Overview component event

    EditLoopDetails(loop: any) {

    }

    ChangeDeviceView(detailview: boolean)
    {
        this.isDeviceDetail = detailview;
        this.srcListView = this.isDeviceDetail ? "app/shared/images/listViewDefaultState.png" : "app/shared/images/listViewActiveState.png";
        this.srcDetailView = this.isDeviceDetail ? "app/shared/images/DetailViewSelected.png" : "app/shared/images/DetailView.png";

    }
    openAddDevicePopup()
    {
        console.log(this.deviceComponentObj);
        if (this.deviceComponentObj !== undefined) {
            this.deviceComponentObj.openAddDevices();
        }
        else
            this.moduleComponentObj.openAddDevices();
    }
    getLoopResponse() {
        this.loopServiceObj.getloopSrvc(this.currentLoop.panelId).then(response => {
            this.getDeviceCount(response);});
    }    
    getDeviceCount(response: any[]) {
        console.log(response);
        this.loops = response;
        for (let loop of this.loops) {
            if (loop.id == this.currentLoop.id)
                this.currentLoop.deviceCount = loop.deviceCount;
        }
    }

    SaveCancel(flag: boolean = true): void {
        this.globalInstance.saveCancelClick(flag);
    }

    LoopUdated(loop: Loop)
    {
        this.currentLoop = loop;
        this.updateTreeViewEvent.emit(loop);
    }
    filterCriteriaLoop: FilterCriteria = new FilterCriteria();

    ApplyFilter(filterCriteria: any)
    {
        this.filterCriteriaLoop = filterCriteria;
        if (this.filterCriteriaLoop.DeviceTypes.length <= 0 && this.filterCriteriaLoop.DeviceWithLabel === undefined) {
            this.filterIcon = "app/shared/images/Filter.png";
        }
        else {
            this.filterIcon = "app/shared/images/FilterApplied.svg";
        }
        console.log(filterCriteria);
    }
}
