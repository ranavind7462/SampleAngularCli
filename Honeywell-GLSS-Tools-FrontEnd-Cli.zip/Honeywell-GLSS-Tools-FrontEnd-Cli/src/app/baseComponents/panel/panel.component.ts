import { Component, OnInit, ViewChild, ViewEncapsulation, ElementRef, Output, EventEmitter } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { PanelService } from "./panel.service";
import { TimerService } from "../../fireComponents/Timer/timer.service";

import { Panel, PanelContentView, ContentViewType } from "../../model/panel";
import { Timer} from "../../model/timer";
import { TreeNode } from "../../model/treeNode";
import { PaneloverviewComponent } from "../../fireComponents/paneloverview/paneloverview.component";
import { PanelSettingComponent } from "../../fireComponents/panelSetting/panel-setting.component";
//import { PanelConfigGraphicalComponent } from    "../../fireComponents/panelConfigGraphical/panelconfiggraphical.component";
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";
import { Globals } from "../../shared/hooks/globals";
import { TreeViewComponent } from "../../fireComponents/treeview/treeview.component";
import { SaveConfirmComponent } from "../../fireComponents/saveConfirm/save-confirm.component";
import { AddNewPanelComponent } from "../../fireComponents/addNewPanel/add-new-panel.component";
import { TimerComponent } from "../../fireComponents/Timer/timer.component";
import { Loop } from "../../model/loop";
import { TimerViewComponent } from "../../fireComponents/timerview/timerview.component";
import { ImportConfigurationComponent } from "../../fireComponents/importConfiguration/import_configuration.component";
import { ConfirmPopupComponent } from "../../fireComponents/confirmPopup/confirmpopup.component";
import { NFRPopupPanel } from "../../fireComponents/NFRPopUPPanel/NFRPopupPanel.component";
import { NFRChecking, PanelVariant } from "../../model/enums";
//import jsPDF from 'jspdf';
//import * as html2canvas from 'html2canvas';
@Component({
    selector: "panel-app",
    templateUrl: "./panel.component.html",
    styleUrls: ["./panel.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class PanelComponent implements OnInit {
    @ViewChild("confirmBtn") confirmBtn: ElementRef;
    @ViewChild("importconfirmBtn") importconfirmBtn: ElementRef;
    @ViewChild("test") htmlElement: ElementRef;
    @ViewChild(ImportConfigurationComponent) importconfirmModal: ImportConfigurationComponent;    
    settings: Panel = null;
    private date: Date
    Isloop: boolean = false;
    isSpinner: boolean = false;
    onSaveClick(panel_settings: Panel)
    {
        this.selectedPanel.nodeData = panel_settings;
        this.settings = panel_settings;
        this.globalInstance.saveCancelClick(false);
    }

    onButtonClick(click_type: string) {

        switch (click_type)
        {
            case 'cancel':
                this.selectedTab = PanelContentView.panelSettings;
                break;

            case 'dontsave':
                this.settings = null;
                this.panelSettingComponentObj.getPanelSetting(this.selectedPanel.nodeData.id);
                break;

            case 'save':
                this.panelServiceObj.editPanelSrvc(this.settings);
                break;
        }
    }

    //For Internaliization
    globalInstance = Globals.getInstance();
    panelLbl = this.globalInstance.getLiteral("PANEL_OVERVIEW_PANEL");
    currentPanel = { defaultLbl: this.panelLbl, panelLbl: "", displayValue: "", visible: true };
    overview = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW"), visible: true };
    configuration = { text: this.globalInstance.getLiteral("PANEL_CONFIGURATON"), visible: true };
    hmi = { text: this.globalInstance.getLiteral("PANEL_HMI"), visible: true };
    events = { text: this.globalInstance.getLiteral("PANEL_EVENTS"), visible: true };
    timer = { text: this.globalInstance.getLiteral("PANEL_TIMER"), visible: true };
    topology = { text: this.globalInstance.getLiteral("PANEL_TOPOLOGY"), visible: true };
    newPanel = { text: this.globalInstance.getLiteral("PANEL_NEWPANEL"), visible: true };
    toggleTopology = { text: "fa fa-chevron-left", visible: true };
    panelDefaultView = { visible: false };
    addNewPanel = { text: this.globalInstance.getLiteral("PANEL_ADDNEWPANEL"), visible: true };
    panelDefaultTxt = { text: this.globalInstance.getLiteral("PANEL_PANELDEFAULTMSG"), visible: true };

    panelSavedConfigTxt = { text: this.globalInstance.getLiteral("PANEL_OPEN_SAVED_CONFIGURATION_FILE"), visible: true };

    setting = { text: this.globalInstance.getLiteral("PANEL_SETTINGS"), visible: false };
    edit = { text: this.globalInstance.getLiteral("COMMON_EDIT"), visible: true };
    delete = { text: this.globalInstance.getLiteral("PANEL_DELETE_LABEL"), visible: true };
    panelLayout = this.globalInstance.getLiteral("PANEL_LAYOUT");
    editSettings = { text: this.globalInstance.getLiteral("PANEL_EDIT_SETTINGS"), visible: true };
    addTimerLabel = { text: this.globalInstance.getLiteral("NEW_TIMER_LABEL"), visible: true};

    selectedPanel: TreeNode;
    panelVisibility = "hidden";
    panelOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9 panel__div--border";
    panelToggleVisible = false;
    selectedTab = PanelContentView.Overview;
    selectedConfigViewTab = ContentViewType.Graphical;s
    rootNode = new Array<TreeNode>();
    private contentViewType = ContentViewType;
    private panelContentView = PanelContentView;
    /* Edit Panel */
    addMode: boolean = true;
    limitexceeded: boolean = true;
    //Import related objects
    importPanelObj: any;
    overRidePanelObj: any
    IsCreatepanel = true;    
    @Output()
    editPanelEvent = new EventEmitter();

    sitepanelNFR: string = this.globalInstance.getLiteral("PANEL_NFR_LIMIT_EXCEEDED");
    /* Edit Panel */

    headertemplate: string;
    template: string;
    watermark: string;
    panelLayoutfieldsvalues: Object;
    currentpanelLayout: any;

    @ViewChild(AddNewPanelComponent)
    modal: AddNewPanelComponent;
    private panelLayoutListdata = [
        { no: "08", display: "Slots Layout", pimg: "app/shared/images/8Layout.svg" },
        { no: "06", display: "Slots Layout", pimg: "app/shared/images/6SlotLayout.svg" },
        { no: "10", display: "Slots Layout", pimg: "app/shared/images/10Layout.svg" },
        { no: "12", display: "Slots Layout", pimg: "app/shared/images/12Layout.svg" },
        { no: "14", display: "Slots Layout", pimg: "app/shared/images/14Layout.svg" }
    ];

    constructor(private cacheComponentObj: CacheComponent,
        private headerserviceObj: Headerservice,
        private panelServiceObj: PanelService, private timerServiceObj: TimerService) {
        this.headerserviceObj.dispatchAction(`>${this.globalInstance.getLiteral("PANEL_AND_LOOPS")}`);
        this.headertemplate = `<div class="panel__dropheader--size"><span>${this.panelLayout}</span></div>`;
        this.panelLayoutfieldsvalues = {
            dataSource: this.panelLayoutListdata,
            text: "no" + " " + "display",
            value: "pimg"
        };
        this.template = '<div><img class="panel__layoutimag--float" src="${pimg}"/>' +
            '<div class="panel__layouttext--pos"><div class="panel__dropitem--size"> ${no} </div><div class="panel__dropitem--size"> ${display} </div></div></div>';
    }

    @ViewChild(PaneloverviewComponent)
    paneloverviewComponentObj: PaneloverviewComponent;

    @ViewChild(PanelSettingComponent)
    panelSettingComponentObj: PanelSettingComponent;

    @ViewChild(DeletePopupComponent)
    deletepopupComponentObj: DeletePopupComponent;

    @ViewChild(TreeViewComponent)
    treeViewComponentObj: TreeViewComponent;

    panelVariantList = [
        { text: this.globalInstance.getLiteral("PANEL_STARTX_EN"), value: PanelVariant.StartXEN },
        { text: this.globalInstance.getLiteral("PANEL_STARTX_UL"), value: PanelVariant.StartXUL },
        { text: this.globalInstance.getLiteral("PANEL_SMARTX_EN"), value: PanelVariant.SmartXEN },
        { text: this.globalInstance.getLiteral("PANEL_SMARTX_UL"), value: PanelVariant.SmartXUL },
        { text: this.globalInstance.getLiteral("PANEL_SMARTX_AUS"), value: PanelVariant.SmartXAUS }
    ];
    ngOnInit()
    {
        this.getPanels();
        this.checkPanelNFR();
    }

    getPanels() 
    {
        this.settings = null;
        this.panelServiceObj
            .getPanelsSrvc(this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId))
            .then(response => this.createBulkTreeViewNodes(response));
    }

    createBulkTreeViewNodes(panelList: Panel[])
    {
        this.rootNode = new Array<TreeNode>();
        if (panelList) {
            if (panelList.length > 0) {
                for (let i = 0; i < panelList.length; i++) {
                    this.rootNode.push(
                        new TreeNode(panelList[i].id,
                            panelList[i],
                            null,
                            this.panelVariantList.filter(j => j.value == panelList[i].variant)[0].text,
                            panelList[i].label + " - " + this.panelVariantList.filter(j => j.value == panelList[i].variant)[0].text)
                            
                    );
                    
                }

                this.rootNode.sort((b, a) => (new Date(a.nodeData.lastModifiedDate) > new Date(b.nodeData.lastModifiedDate))
                    ? 1
                    : ((new Date(b.nodeData.lastModifiedDate) > new Date(a.nodeData.lastModifiedDate)) ? -1 : 0));
            }
        }
        this.updatePanelViewVisibility();
    }

    createNewTreeViewNode(newPanel: Panel) {
        console.log(this.rootNode);
        var t = this.rootNode.find(a => a.id == newPanel.id);
        var panelType = this.panelVariantList.filter(j => j.value == newPanel.variant)[0].text;
        console.log(panelType);
        console.log(t);
        if (newPanel) {
            const newNode = new TreeNode(newPanel.id,
                newPanel,
                null,
                this.panelVariantList.filter(j => j.value == newPanel.variant)[0].text,
                newPanel.label + " - " + this.panelVariantList.filter(j => j.value == newPanel.variant)[0].text);
            this.rootNode.unshift(newNode);
            this.updatePanelViewVisibility();
        }
        //this.rootNode.pop()
    }

    deleteTreeViewNode(panelId: any) {
        if (panelId) {
            const node = this.rootNode.filter(x => x.nodeData.id === panelId)[0];
            this.rootNode.splice(this.rootNode.indexOf(node), 1);
            this.updatePanelViewVisibility();
        }
    }

    updatePanelViewVisibility(): any {
        if (this.rootNode && this.rootNode.length > 0) {
            this.panelDefaultView.visible = false;
            this.panelVisibility = "visible";
           
            this.selectedPanel = this.rootNode[0];
            this.updateContentOnUi(this.selectedPanel);
        } else {
            this.panelDefaultView.visible = true;
            this.panelVisibility = "hidden";
        }
        this.checkPanelNFR();
    }

    updateContentOnUi(treeNode: TreeNode): any {
        this.settings = null;
        this.Isloop = false;
        this.selectedPanel = treeNode;
        this.currentPanel.displayValue = this.selectedPanel.nodeData.label;
        this.currentPanel.panelLbl = this.selectedPanel.nodeData.label;
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage,
            StorageKey.selectedPanelId,
            this.selectedPanel.nodeData.id);

        switch (this.selectedTab) {
            
        case PanelContentView.Overview:
            {
                if (this.paneloverviewComponentObj) {
                    this.paneloverviewComponentObj.getPanel(this.selectedPanel.nodeData.id);
                }
                break;
            }
        case PanelContentView.panelSettings:
                {
                    if (this.panelSettingComponentObj)
                    {
                        this.SaveCancel(false);
                    }
                }
            case PanelContentView.HMI:
                {
                    break;
                }
            case PanelContentView.Events:
                {
                    break;
                }
            case PanelContentView.Timer:
                {
                    break;
                }
           
        }
    }

    toggleTopologyText(): any {
        if (this.toggleTopology.text === "fa fa-chevron-right") {
            this.toggleTopology.text = "fa fa-chevron-left";
            this.panelOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9 panel__div--border";
            this.panelToggleVisible = false;
        } else {
            this.panelOverviewCss = "col-xs-12 col-sm-12 col-md-12 col-lg-12 panel__div--borderwidth";
            this.toggleTopology.text = "fa fa-chevron-right";
            this.panelToggleVisible = true;
        }
    }
    checkPanelNFR(): any {
        debugger;
        this.panelServiceObj.CheckPanelNFR().then(response => {
            console.log(response);
            if (response.json() == NFRChecking.LimitExceded)
            {
                this.IsCreatepanel = false;
                return false;

            }
            else
            {
                this.IsCreatepanel = true;
                return true;
            }
                     
        },
            error => {
                console.log(error);
                this.IsCreatepanel = false;
                return false;
            }
        );
    }

    /**
    * This method is used to post a service request and update the newly added panel in the panel overview page.
    * @param obj : it is the data object created from the user inputs on add new popup page.
    */
    createPanel(obj: Panel): void {
        obj.siteId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
       // obj.type = 1;
        this.panelServiceObj.createNewPanelSrvc(obj).then(
            response => 
            {
               
                    const data = response.json();
                  // this.SaveCancel(false);
                //To DO remove 
                    if (data == "Duplicate Value") {
                        this.modal.isWarning = true;
                        this.modal.panelWarning.text = this.globalInstance.getLiteral("PANEL_IMPORT_CONFIG_EXIST_MSG");
                
                    }
                    else{
                        this.modal.onClose();
                        this.updateTreeView(data.id);
                         console.log(data);
                         console.log(response);
                        }
                            
              
            },
            error => {
               
                console.log(error);
            }
        );
    }
    /* Edit Panel */
    createOrEditPanel(obj: Panel): void {
        if (this.addMode) {
            this.createPanel(obj);
        }
        else {
            ///TODO: Service call to update the panel
            this.panelServiceObj.editPanelSrvc(obj)
                .then(response => {
                    if (response.json() != NFRChecking.Duplicate) {

                        const data = response.json
                        console.log(data);
                        this.modal.onClose();
                        this.getPanels();
                        this.addPanel();
                    }
                    else if (response.json() == NFRChecking.Duplicate) {
                        this.modal.isWarning = true;
                        console.log(response);
                    }
                },
                error => {
                    console.log(error);
                }
                );
        }
    }


    addPanel(): void {
        this.modal.popupLbl.text = this.globalInstance.getLiteral("PANEL_ADDNEWPANEL");
        this.modal.panelSavedConfigTxt.visible = true;
        this.modal.add.text = this.globalInstance.getLiteral("COMMON_ADD");
        this.modal.panel = new Panel();
        this.modal.panel.noOfLoops = this.modal.loop01.text;
        this.modal.panel.variant = this.modal.panelVariantList[0].value;
        this.modal.loops = [1,2];
        this.modal.selectedLoop = this.modal.loop01.text;
        this.modal.isWarning = false;
        this.modal.addMode = true;
        this.addMode = true;
        this.modal.errorMsg = "";

    }

    editPanel(panelData): void {
        this.modal.popupLbl.text = this.globalInstance.getLiteral("ADDNEWPANEL_HEADER_EDIT");
        this.modal.panelSavedConfigTxt.visible = false;
        this.modal.add.text = this.globalInstance.getLiteral("COMMON_SAVE");
        this.modal.cancel.visible = true;
        this.modal.panel = panelData;
        this.modal.addMode = false;
        this.modal.noofLoopsSelectedPanel = panelData.noOfLoops;
        this.addMode = false;
        this.modal.selectedLoop = panelData.noOfLoops;
        this.modal.OnVariantChange(panelData.variant);
        this.modal.errorMsg = "";
        this.modal.isWarning = false;
    }



     /* Edit Panel */
    updateTreeView(newPanelId : string) {
        this.panelServiceObj
            .getPanel(newPanelId)
            .then(response => {
                //Required when UI is not loaded
                this.createNewTreeViewNode(response);
            });
    }

    setConfigTabView(view: ContentViewType) {
        this.selectedConfigViewTab = view;
    }

    /**
     * This helper method gets the selected panel tab number and assigns to the selectedTab variable
     * @param num
     */
    setTab(view: PanelContentView)
    {
        this.selectedTab = view;
    }



    /**
     * This helper function returns true if the number equals to the currently selected tab. It is used to apply the
     * appropriate css class to the tab control to indicate the "selected/unselected status" of a tab
     * @param num
     */
    isSelected(view: PanelContentView) {
        return this.selectedTab === view;
    }

    deletePanel() {
        this.deletepopupComponentObj.popupLabel.text = this.globalInstance.getLiteral("PANEL_DELETE_LABEL");
        this.deletepopupComponentObj.confirmationMsg.text = this.globalInstance
            .getLiteral("PANEL_DELETE_CONFIRMATION_MSG");
        this.deletepopupComponentObj.deletemsg.text = this.globalInstance.getLiteral("DELETE_MESSAGE_PANEL");
        this.deletepopupComponentObj.currentDeleteObj.label = this.panelLbl + this.selectedPanel.nodeData.number;
        this.deletepopupComponentObj.currentDeleteObj.desc = this.selectedPanel.nodeData.label + ", " + this.selectedPanel.nodeData.noOfLoops + "  " +  this.globalInstance.getLiteral("PANEL_LOOPS_PANEL");
        this.deletepopupComponentObj.currentDeleteObj.id = "Panel";
        this.deletepopupComponentObj.lastUpdatedOn.text = (new Date(this.selectedPanel.nodeData.lastModifiedDate)).toLocaleDateString();
        this.deletepopupComponentObj.enterPassword.visible = false;
        this.deletepopupComponentObj.deleteFiles.visible = false;
        this.deletepopupComponentObj.description.visible = true;
        this.deletepopupComponentObj.projId.visible = false;
        this.deletepopupComponentObj.deleteicon = "panel.png";
    }



    deletePanelData() {
        this.panelServiceObj.deletePanelSrvc(this.selectedPanel.nodeData.id).then(
            response => {
                if (response.ok)
                {
                    this.cacheComponentObj.setKeyData(StorageType.LocalStorage,
                        StorageKey.selectedPanelId,
                        {});
                    this.deleteTreeViewNode(this.selectedPanel.nodeData.id);
                }
            },
            error => {
                console.log(error);
            }
        );
    }
    /* Timers code start here Added By Ranavind */
    @ViewChild(TimerComponent)
    timerComponentObj: TimerComponent;
    @ViewChild(TimerViewComponent)
    timerViewComponentObj: TimerViewComponent;
    createOrEditTimer(obj: Timer): void {
        this.timerServiceObj.createTimerSrvc(obj).then(
            response => {
                if (response.ok) {
                    const data = response.json();                   
                    this.timerViewComponentObj.getTimers();
                }
                if (!response.ok)
                {
                    console.log(response);
                }
            },
            error => {
                console.log(error);
            }
        );
       
    }
    editTimer(timerData): void {

        this.timerComponentObj.paneltimer = timerData;
        this.timerComponentObj.newTimer.text = this.globalInstance.getLiteral("EDIT_TIMER_LABEL");
        this.timerComponentObj.Add.text = this.globalInstance.getLiteral("COMMON_SAVE"); 
        this.timerComponentObj.showCustomFields = timerData.repeatMode == 1 ? true : false;
        
        if (timerData.repeatMode == 1) {
            this.timerComponentObj.daysArray = timerData.repeatDays !== undefined ? timerData.repeatDays.split(",") : [];
        }
        else
        {
            for (var i = 0; i < this.timerComponentObj.weekdays.length; i++) {
                
                        this.timerComponentObj.weekdays[i].checked = false;
                                   
            }
            this.timerComponentObj.daysArray = [];
        }
        for (var i = 0; i<this.timerComponentObj.weekdays.length;i++)
        {
            for (var j = 0; j<this.timerComponentObj.daysArray.length; j++)
            {
                if (this.timerComponentObj.weekdays[i].text == this.timerComponentObj.daysArray[j])
                {
                    this.timerComponentObj.weekdays[i].checked = true;
                }
            }
        }
        console.log(timerData);
    }

    //Loop code
    loopDetails: Loop;
    getLoopdetails(loop: Loop)
    {
        console.log(Loop);
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.selectedLoopId, loop.id);
        this.Isloop = true;
        this.loopDetails =  loop;
        
    }
    @ViewChild(TimerComponent)
    timerModal: TimerComponent;
    addTimer(): void {
        console.log(this.timerModal);
        this.timerModal.paneltimer = new Timer();
        this.timerModal.paneltimer.repeatMode = 1;
        this.timerModal.daysArray = [];
        this.timerModal.newTimer.text = this.globalInstance.getLiteral("NEW_TIMER_LABEL");
        this.timerModal.Add.text = this.globalInstance.getLiteral("COMMON_ADD");
       
    }

    SetTimerLimit(timerCount:any)
    {
        this.limitexceeded = timerCount < 14 ? true : false;
    }

    shareConfiguration() {
        var panelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        this.panelServiceObj.shareConfiguration(panelId).subscribe((data) => {

            var fileName = "panelConfig.txt"
            this.saveTextAsFile(JSON.stringify(data), fileName);

        });
    }
    saveTextAsFile(data, filename) {

        if (!data) {
            console.error('Console.save: No data')
            return;
        }

        if (!filename) filename = 'console.json'

        var blob = new Blob([data], { type: 'application/text' }),
            e = document.createEvent('MouseEvents'),
            a = document.createElement('a')
        // FOR IE:

        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(blob, filename);
        }
        else {
            // window.navigator.msSaveOrOpenBlob(blob, filename);
            var data1 = window.URL.createObjectURL(blob);
            var e = document.createEvent('MouseEvents'),
                a = document.createElement('a');

            a.download = filename;
            a.href = data1;
            // a.dataset.uri = ['text/plain', a.download, a.href].join(':');
            e.initEvent('click', false, true);
            //a.dataset.downloadurl = ['text/plain', a.download, a.href].join(':');
            //e.initEvent('click', true, false, window,
            //   0, 0, 0, 0, 0, false, false, false, false, 0, null);
            a.dispatchEvent(e);
        }
    }

    importConfiguration(panelObje: any) {
        var panelName = panelObje.label;
        this.importPanelObj = panelObje;

        var siteId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
        this.panelServiceObj.checkPanelDeuplication(panelName, siteId).then(res => {
            //TODO
            if (res.json() == "Duplicate Value")
            {
                this.overRidePanelObj = panelObje;
                this.importconfirmModal.error = "";
                this.importconfirmModal.panelLabel = this.overRidePanelObj.label +" " + this.importconfirmModal.panelImportConfig.text;
                this.importconfirmModal.isSaveAsNew = false;
                this.importconfirmModal.isOverride = false;
                this.importconfirmModal.panelName = "";
                this.importconfirmModal.isDoneEnabled = false;
                this.importconfirmBtn.nativeElement.click();

            }
            else
            {
                
                this.CallImportSavinfSrvc(panelObje);
               // console.log(res);
            }

        });
        //.then((data) => {

        //    console.log(data);

        //});
    }
    CallImportSavinfSrvc(panelObje: any)
    {
        this.modal.onClose();
        this.isSpinner = true;
        panelObje.siteId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
        this.panelServiceObj.importConfigurationSrv(panelObje).subscribe(resp => {
            console.log(resp);

            this.getPanels();
            this.isSpinner = false;
        },
            (error) => {
                console.log("test");
            });
    }
    SaveORImportConfig(panelName: string)
    {
        console.log("import dublicate");
        if (panelName=="overwrite") {
            this.panelServiceObj.deletePanelSrvc(this.overRidePanelObj.id).then(res => {

                this.CallImportSavinfSrvc(this.importPanelObj);
                this.importconfirmModal.onClose();
            })
        }
        else {
            var siteId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
            this.panelServiceObj.checkPanelDeuplication(panelName, siteId).then(res => {
                if (res.json() == NFRChecking.Duplicate) {
                    this.importconfirmModal.error="Panel name already exists."
                }
                else {
                    this.importPanelObj.label = panelName;

                    this.CallImportSavinfSrvc(this.importPanelObj);
                    this.importconfirmModal.onClose();

                }
            });
        }
        console.log(this.importPanelObj);
    }
    selectImportFile()
    {
        this.modal.importConfiguration();
    }

    SaveCancel(flag: boolean = true): void
    {
        this.globalInstance.saveCancelClick(flag);
    }
    updateTreeViewloopNode()
    {
        console.log('test over view');
        this.getPanels();
        //this.Isloop = true;
    }
    ontimerSettingSaveClick(panelSetting: Panel)
    {
        this.selectedPanel.nodeData = panelSetting;
    }
    //exportPdf() {
    //    let pdf = new jsPDF();
    //    let specialElementHandlers = {
    //        '#editor': function (element, renderer) {
    //            return true;
    //        }
    //    };
    //    let content = this.htmlElement.nativeElement;
    //    pdf.fromHTML(content, 15, 15, {
    //        'width': 190,
    //        'elementHandlers': specialElementHandlers
    //    }, function (bla) {
    //        pdf.save('saveInCallback.pdf');
    //    }, 15);
    //}
}
