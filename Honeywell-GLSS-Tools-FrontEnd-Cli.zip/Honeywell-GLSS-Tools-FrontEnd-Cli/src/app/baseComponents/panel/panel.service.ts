﻿import { Injectable } from "@angular/core";
import { Headers, Http, Response } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { Panel } from "../../model/panel";
import { PanelModule } from "../../model/panelmodule";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from "../../shared/hooks/config";
import { Subject, Observable } from "rxjs/Rx";


@Injectable()
export class PanelService {

    constructor(private http: Http,
        private serviceUrlObj: ServiceUrl,
        private configObj: Config,
        private errorHandlerObj: MyErrorHandler) {
        this.serviceUrlObj = new ServiceUrl(this.configObj);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching list of panel by site id
     */
    getPanelsSrvc(siteId: string): Promise<Panel[]> {

        let getPanelsUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetPanels);
        const re = /\/id\//g;
        getPanelsUrl = getPanelsUrl.replace(re, `/${siteId}/`);
        return this.http
            .get(getPanelsUrl)
            .toPromise()
            .then(response => {
                const data = response.json();

                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
        // return Promise.resolve(data);
    }

    /**
    * This is a service method which makes a rest call to the webapi for creating or updating a panel
    * through the add new panel popup.
    */
    createNewPanelSrvc(panelObj) {
        const postPanelUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Panel);
        return this.http
            .post(postPanelUrl, panelObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching the current site details based on the
     * site id passed.
     */
    getPanel(panelId: string): Promise<any> {

        const getPanelUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Panel) + "/" + panelId;

        return this.http
            .get(getPanelUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data; // Change it on integration with proper API.
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
        //return Promise.resolve(panel);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching the new card configuration details based on the
     * panel id passed.
     */
    getSupportedModuleTypesSrvc(panelId: string): Promise<PanelModule> {
        let getSupportedModuleUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetSupportedModuleTypes);
        const re = /\/id\//g;
        getSupportedModuleUrl = getSupportedModuleUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(getSupportedModuleUrl)
            .toPromise()
            .then(response => {
                const data = response.text();
                return data; // Change it on integration with proper API.
            },
            response => {
                const data = response.text();
                return data; // Change it on integration with proper API.
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    /**
  * This is a service method which makes a rest call to the webapi for creating or updating a panel
  * through the add new panel popup.
  */
    createNewCardConfDetailsSrvc(panelObj) {
        const postPanelModuleUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.PostPanelModule);
        return this.http
            .post(postPanelModuleUrl, panelObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            }).catch(this.errorHandlerObj.handleServerError);
    }

    updatePanelModuleSrvc(panelObj) {
        const panelId = JSON.parse(panelObj, this.camelCaseReviver).id;
        const postPanelModuleUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.EditPanelModule) + "/" + panelId;
        return this.http
            .put(postPanelModuleUrl, panelObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }
    private camelCaseReviver(key, value) {
        if (value && typeof value === 'object')
            for (let k in value) {
                if (/^[A-Z]/.test(k) && Object.hasOwnProperty.call(value, k)) {
                    value[k.charAt(0).toLowerCase() + k.substring(1)] = value[k];
                    delete value[k];
                }
            }
        return value;
    }

    getModuleList(panelId: string) {
        let getModuleListUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.PanelModuleList);
        const re = /\/id\//g;
        getModuleListUrl = getModuleListUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(getModuleListUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    getModuleDetails(moduleId: string) {
        const getModuleDetailUrl = this.serviceUrlObj
            .fetchUrlEndPoint(ApiName.PanelModuleDetail) + "/" + moduleId.replace(/"/g, "");
        return this.http
            .get(getModuleDetailUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    deletePanelSrvc(panelId: string) {
        const deletePanelUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.DeletePanel) + "/" + panelId;
        return this.http
            .delete(deletePanelUrl)
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                console.log(response);
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    deletePanelModuleSrvc(moduleId: string) {
        const deletePanelModuleUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.DeletePanelModule) + "/" + moduleId;
        return this.http
            .delete(deletePanelModuleUrl)
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                console.log(response);
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    getFreeSlots(moduleDetail: any) {
        let panelFreeSlotsUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetFreeSlots);
        const re = /\/id\//g;
        panelFreeSlotsUrl = panelFreeSlotsUrl.replace(re, `/${moduleDetail.PanelId}/`);
        // Optional query parameter. If this parameter is not set all free slots will be provided
        panelFreeSlotsUrl = panelFreeSlotsUrl.concat("/?moduleType=", `${moduleDetail.ModuleType}`);
        // Optional query parameter. Currently not used (can be removed).
        panelFreeSlotsUrl = panelFreeSlotsUrl.concat("&layoutType=", `${moduleDetail.LayoutType}`);
        return this.http
            .get(panelFreeSlotsUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data;
            },
            response => {
                const data = response.json();
                return data;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    editPanelSrvc(panelObj) {
        debugger;
        console.log(panelObj.id);
        const panelId = panelObj.id;
        const putPanelUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Panel) + "/" + panelId;
        return this.http
            .put(putPanelUrl, panelObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }
    shareConfiguration(panelId: number): Observable<any> {
        let shareConfigUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.ShareConfig) + "/" + panelId;
        //const re = /\/panelId\//g;
        //shareConfigUrl = shareConfigUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(shareConfigUrl)
            .map((response: Response) => response.json());
    }
    importConfigurationSrv(importpanel: any): Observable<any> {
      
                let importConfigUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.ImportConfig);
                return this.http
                   .post(importConfigUrl, importpanel, { headers: contentHeaders })
                   .map(response => {
                        return response;
                    },
                    response => {
                        return response;
                    }).catch(this.errorHandlerObj.handleServerError);
          
    }
    checkPanelDeuplication(panelName: string,siteId:number) {
        let checkPanelDeuplicationUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.CheckPanelDeuplication) + "/" + panelName + "/" + siteId;
        return this.http
            .get(checkPanelDeuplicationUrl)
            .toPromise()
            .then(response => {
                console.log(response);
                return response;
            },
            response => {
                return response;
            }).catch(this.errorHandlerObj.handleServerError);
    }
    CheckPanelNFR() {
        let checkNFRUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.CheckPanelNFR);
        return this.http
            .get(checkNFRUrl)
            .toPromise()
            .then(response => {
                console.log(response);
                return response;
            },
            response => {
                return response;
            }).catch(this.errorHandlerObj.handleServerError);
    }
}