import { Component, OnInit, Output, Input, ViewChild, EventEmitter,ViewEncapsulation } from "@angular/core";
import { ActiveSitesService } from "../shared/active-sites.service";
import { CustomerSite } from "../../model/customerSite";
import { AddNewSiteComponent } from "../../fireComponents/addNewSite/add-new-site.component";
import { SubHeaderComponent } from "../../fireComponents/subHeader/sub-header.component";
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "active-sites-app",
    templateUrl: "./active-sites.component.html",
    styleUrls: ["./active-sites.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class ActiveSitesComponent implements OnInit {
    @Input()
    currentContext: any;
    activeSites: CustomerSite[];

    @Output()
    activeSiteDetailsEvent = new EventEmitter();

    @Output()
    updateSubheaderEvent = new EventEmitter();

    @Output()
    editSiteDetailsEvent = new EventEmitter();

    @Output()
    deleteSiteDetailsEvent = new EventEmitter();

    @ViewChild(AddNewSiteComponent)
    modal: AddNewSiteComponent;

    //For Internaliization
    globalInstance = Globals.getInstance();

    gridView = { text: "", visible: true };
    listView = { text: "", visible: true };
    siteCart = { text: "", visible: false };
    defaultView = { text: "", visible: false };
    addNewSite = { text: this.globalInstance.getLiteral("ACTIVESITE_NEWSITE_BTN"), visible: true };
    defaultTxt = {
        text: this.globalInstance.getLiteral("ACTIVESITE_DEFAULT_MESG"),
        visible: false
    };

    constructor(private activeSitesSrvcObj: ActiveSitesService) {}

    ngOnInit() {
        this.getActiveSites();
    }

    /**
     * This method is used to make use of the response coming from getActiveSitesSrvc() method and
     * load the respective template.
     * @param resp : it is the response object coming as a return from getActiveSitesSrvc() method.
     */
    populateActiveSite(resp): any {
        if (this.activeSites) {
            let updateFlag = false;
            for (let i = 0; i < this.activeSites.length; i++) {
                if (this.activeSites[i].id === resp.id) {
                    this.activeSites[i] = resp;
                    updateFlag = true;
                    break;
                }
            }
            if (!updateFlag) {
                this.activeSites.unshift(resp);
            }
        } else {
            if (resp) {
                if (!Array.isArray(resp)) {
                    this.activeSites = [resp];
                } else {
                    this.activeSites = resp;
                }
            }
        }
        this.updateDefaultScreen();
    }

    updateDefaultScreen() {
        if (this.activeSites && this.activeSites.length > 0) {
            this.siteCart.visible = true;
            this.defaultView.visible = false;
            this.activeSiteDetailsEvent.emit();
            this.updateSubheaderEvent.emit(true);
           // this.editSiteDetailsEvent.emit();
          //  this.deleteSiteDetailsEvent.emit();

        } else {
            this.defaultView.visible = true;
            this.siteCart.visible = false;
            this.updateSubheaderEvent.emit(false);
        }
    }

    /**
     * This method calls the service getActiveSitesSrvc() or getCurrentSiteSrvc() based on the action like Create or Edit
     * and makes the response available for usage.
     * @param siteId : based on the availability of siteId, respective service will be called.
     */
    getActiveSites(): void {
        this.activeSitesSrvcObj
            .getActiveSitesSrvc()
            .then(response => this.populateActiveSite(response));
        //var result1 = this.activeSitesSrvcObj
        //    .getCurrentSiteSrvc("123");
        //console.log(result1);
        //this.populateActiveSite(result1);
    }
    getActiveSite(siteId): void {
        this.activeSitesSrvcObj
            .getCurrentSiteSrvc(siteId)
            .then(response => this.populateActiveSite(response));
        //var result1 = this.activeSitesSrvcObj
        //    .getCurrentSiteSrvc(siteId);
        //console.log(result1);
        //this.populateActiveSite(result1);
        //  //  .then(response => this.populateActiveSite(response));
    }

    removeDeletedSite(siteId): any {
        siteId = siteId.replace(/"/g, "");
        const item = this.activeSites.filter(x => x.id === siteId)[0];
        this.activeSites.splice(this.activeSites.indexOf(item), 1);
        this.updateDefaultScreen();
        if (this.activeSites && this.activeSites.length === 0) {
            this.updateSubheaderEvent.emit(false);
        }

    }

    showGridView(): void {
        //TODO
    }

    showListView(): void {
        //TODO
    }

    /**
    * This method emits the edit site event to its parent ie dashboard component.
    * @param siteData : it holds the site cart data and the same is emitted to dashboard component for usage.
    */
    editSite(siteData): void {
        this.editSiteDetailsEvent.emit(siteData);
    }

    deleteSite(siteData): void {
        this.deleteSiteDetailsEvent.emit(siteData);
    }
}
