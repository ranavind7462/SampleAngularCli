import { Component,Output,EventEmitter } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { ProgZoneTypes } from "../../model/DetailsTypes";
import { Observable } from "rxjs";
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "progZone-header",
    templateUrl: "./progzoneheader.component.html",
    styleUrls: ["./progzoneheader.component.css"]
})
export class ProgZoneHeaderComponent {
    @Output() selectzoneTypeEvent = new EventEmitter();
    selectedZoneType: number = 1; 

   private zoneTypes:any[]= [];
    //private zoneTypes = [
    //    { id: "0", progZoneType: "On" },
    //    { id: "1", progZoneType: "Pulse"},
    //    { id: "2", progZoneType: "Delay" },
    //    { id: "3", progZoneType: "Coincidence" },
    //    { id: "4", progZoneType: "Coincidence_3" }
        
        
       
    //];


   isSelected(type: number) {
       return this.selectedZoneType === type;
   }
    selectZoneType(type: number)
    {
        this.selectedZoneType = type;
        this.selectzoneTypeEvent.emit(type);
    }

    constructor(private detailsServiceObj: DetailsService) {


        this.detailsServiceObj.getProgZoneTypesSrvc().subscribe(data => {
            this.zoneTypes = data;
        })
    }

    //getProgZonesTypes() {
    //    this.detailsServiceObj.getProgZoneTypesSrvc().then((response) => { this.getProgZoneList(response). });

       
    //}

    getProgZoneList(resp)
    {
        this.zoneTypes = resp;
        console.log(this.zoneTypes);
    }
}
