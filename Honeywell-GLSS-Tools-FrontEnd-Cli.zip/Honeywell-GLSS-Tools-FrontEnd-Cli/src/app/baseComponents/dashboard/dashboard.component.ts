import { Component, OnInit, Output, ViewChild } from "@angular/core";
import { AddNewSiteComponent } from "../../fireComponents/addNewSite/add-new-site.component";
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";
import { SubHeaderComponent } from "../../fireComponents/subHeader/sub-header.component";
import { ActiveSitesComponent } from "../activesite/active-sites.component";
import { ActiveSitesService } from "../shared/active-sites.service";
import { Headerservice } from "../../fireComponents/header/header.service";
import { Globals } from '../../shared/hooks/globals';
import { CustomerSite } from "../../model/customerSite";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Router } from "@angular/router";
import { NFRChecking } from "../../model/enums";
import { UserRegistrationService } from "../../fireComponents/userregistration/user-registration.service";
import { User } from "../../model/user";

@Component({
    selector: "dashboard-app",
    templateUrl: "./dashboard.component.html",
    styleUrls: ["./dashboard.component.css"]
})
export class DashboardComponent {
  
    @ViewChild(AddNewSiteComponent)
    modal: AddNewSiteComponent;

    @ViewChild(DeletePopupComponent)
    deleteModal: DeletePopupComponent;

    @ViewChild(SubHeaderComponent)
    subHeader: SubHeaderComponent;

    @ViewChild(ActiveSitesComponent)
    activeSite: ActiveSitesComponent;

    //For Internaliization
    globalInstance = Globals.getInstance();

    addMode: boolean = true;
    constructor(private cacheComponentObj: CacheComponent, private activeSitesSrvcObj: ActiveSitesService,
        private headerserviceObj: Headerservice, private route: Router, private userRegSrvcObj: UserRegistrationService) {
        headerserviceObj.dispatchAction(this.globalInstance.getLiteral("HEADER_DASHBOARD_TXT"));
        let userList: User[] = [];
      
    }
    
    /**
     * This method is used to make the add new site button visible based on an action.
     * @param obj
     */
    activeSiteEvent(obj): void {
       // this.subHeader.addSite.visible = true;
    }

    getUserInfo(): void {
        //TODO
    }

    loadActiveSites(): void {
        //TODO
    }

    loadArchivedSites(): void {
        //TODO
    }

    /**
    * This method is used to refresh the modal properties before its load in Add mode.
    */
    addNewSite(): void {
        this.modal.popupLbl.text = this.globalInstance.getLiteral("ACTIVESITE_NEWSITE_BTN");
        this.modal.importFile.visible = true;
        this.modal.confirm.text = this.globalInstance.getLiteral("COMMON_ADD");
        this.modal.cancel.visible = false;
        this.addMode = true;

    }

    /**
    * This method is used to post a service request and update the newly added site in the dashboard.
    * @param obj : it is the data object created from the user inputs on add new popup page.
    */
    createOrEditSite(obj): void {
        if (this.addMode) {
            this.activeSitesSrvcObj
                .createSiteSrvc(obj)
                .then(response => {
                    debugger;
                    if (response.json() == NFRChecking.Duplicate) {
                        this.modal.isWarning = true;
                        this.modal.sitenameWarning.text = this.globalInstance.getLiteral("ADDNEWSITE_SITENAME_ERR_MSG");
                    }
                    else {
                        var siteId = response.json().id;
                        this.activeSite.getActiveSite(siteId);
                        this.modal.onClose();
                    } 
                    
                },
                error => {
                    console.log(error);
                }
                );
        } else {
            this.activeSitesSrvcObj
                .editSiteSrvc(obj)
                .then(response => {
                    if (response.json() != NFRChecking.Duplicate) {
                        var siteId = response.json().id;
                        this.activeSite.getActiveSite(siteId);
                        this.modal.onClose();
                    }
                    else if (response.json() == NFRChecking.Duplicate) {
                        this.modal.isWarning = true;
                        console.log(response);
                    }
                },
                error => {
                    console.log(error);
                }
                );
        }
        
    }

    /**
   * This method is used to refresh the modal properties before its load in Edit mode.
   * @param siteData : it is the data object created from the user inputs on edit popup page.
   */
    editSite(siteData): void {
        this.modal.popupLbl.text = this.globalInstance.getLiteral("ADDNEWSITE_HEADER_EDIT");
        this.modal.importFile.visible = false;
        this.modal.confirm.text = this.globalInstance.getLiteral("COMMON_SAVE");
        this.modal.cancel.visible = true;
        //this.modal.currentSite = Object.assign({}, siteData);
        this.modal.currentSite = siteData;
        this.addMode = false;
    }

    deleteSite(siteData) {
        
        this.deleteModal.currentDeleteObj.id =  "Site"; 
        this.deleteModal.currentDeleteObj.label = siteData.label;
        this.deleteModal.currentDeleteObj.siteType = siteData.siteType;
        this.deleteModal.currentDeleteObj.address = siteData.address + "," + siteData.addressLine2 + "," + siteData.city + "," +
            siteData.zipCode + "," + siteData.country;//customerProjectReference;
    }

    deleteSiteData(obj): void {
        var siteId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
        this.activeSitesSrvcObj
            .deleteSiteSrvc(siteId)
            .then(response => {
                if (response.ok) {
                    this.activeSite.removeDeletedSite(siteId);
                }
            },
            error => {
                console.log(error);
            }
            );
    }

    updateSubheader(flag: boolean) {
        this.subHeader.addSite.visible = flag;
    }

    ngOnInit()
    {
        // this.route.navigateByUrl("/registration");
        let userList: User[] = [];
         this.userRegSrvcObj.getRegisteredUsersSrvc().subscribe((res) => {
             userList = res;

        
         if (userList.length > 0) {
             var isSiteSwitched = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.isSiteSwitched);
             if (isSiteSwitched === "true")
                 this.route.navigateByUrl("/site");
         }
         else {
             this.route.navigateByUrl("/registration");
             }
         });
        //console.log(result);
    }
}
