import { Component, ViewChild, Input, DoCheck, Output, EventEmitter,ElementRef } from '@angular/core';
import { Globals } from "../../shared/hooks/globals";
import { ModulesService } from "./modules.service";
import { Headerservice } from "../../fireComponents/header/header.service";
import { AddDevices } from "../../model/addDevices";
import { Module } from "../../model/modulesModel";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { AddDeviceComponent } from "../../fireComponents/addDevice/add-device.component";
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";
import { AssignDeviceToZone } from "../../fireComponents/assignDevicetoZone/assigndevicetozone.component";
import { Loop } from "../../model/loop";
import { Types } from "../../model/DetailsTypes";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { DeviceTypes } from "../../model/DetailsTypes";
import { ProgZonesComponent } from "../../fireComponents/progZones/prog_zones.component";

import { ModuleCategory } from "../../model/enums";
import { EJComponents } from "ej-angular2";
import { FilterCriteria } from "../../model/DetailsTypes";
//import { RowSelectEventArgs, Grid, Selection } from "@syncfusion/ej2-grids";


@Component({
    selector: 'modules-app',
    templateUrl: "./modules.component.html",
    styleUrls: ["./modules.component.css"],
})

export class ModulesComponent {
    @ViewChild("gridModule") grid: EJComponents<any,any>;
  
    
    
    @ViewChild(ProgZonesComponent) progZonesModel: ProgZonesComponent;
    @ViewChild(AddDeviceComponent) addDeviceModal: AddDeviceComponent;
    @ViewChild(AssignDeviceToZone) assignZoneModal: AssignDeviceToZone;
    @ViewChild(DeletePopupComponent)
    deleteModal: DeletePopupComponent;
    //@Output() devicesCountEvent = new EventEmitter<number>(); scrollSettings = { height: 326, allowVirtualScrolling: false, autoHide: true };
    scrollSettings = { height: 326, allowVirtualScrolling: false, autoHide: true };
    selectionSettings = { selectionMode: ["row"], persistSelection: true };
    @Input() filterCriteriaDetectors: FilterCriteria = new FilterCriteria();
    @Input() selectedLoop: Loop;
    isTypes: boolean = false;
    //For Internaliization
    globalInstance = Globals.getInstance();
    selectedDeviceType: number = -1;
    selectedModule: Module;
    deviceDefaultTxt = { text: this.globalInstance.getLiteral("DEVICE_DEFAULT_TEXT"), visible: true };
    addDevice = { text: this.globalInstance.getLiteral("DEVICE_ADD_DEVICES"), visible: true };
    devicesSelected = { text: this.globalInstance.getLiteral("DEVICES_SELECTED"), visible: true };
    deviceAssignProgZone = { text: this.globalInstance.getLiteral("DEVICES_ASSIGN_TO_PROG_ZONE"), visible: true };
    deviceChangeType = { text: this.globalInstance.getLiteral("DEVICES_CHANGE_TYPE"), visible: true };
    deviceAssignZone = { text: this.globalInstance.getLiteral("DEVICES_ASSIGN_TO_ZONE"), visible: true };
    deleteConfirmationMsg = { text: this.globalInstance.getLiteral("DEVICE_DELETE_CONFIRMATION_MSG"), visible: true };    
    delete = { text: this.globalInstance.getLiteral("COMMON_DELETE"), visible: true };    
    noOfdeviceSelected = { text: "00" };
    rowsSelected = false;
    deviceDefaultView = { visible: false };
    devices: Module[];
    selectedModules: Module[];

    loopView: Loop = new Loop();
    isProgZoneEnabled = false;

    detailTypes: Types[] = [];
    deviceTypes: DeviceTypes[] = [];

    public gridData: any;
    onrowdatabound(e: any) {
        // var indexLabel =  e.model.columns.filter(c => { if (c.field == "deviceAddressLabel") return c.index; });
        var deviceType = e.rowData.deviceTypeId

        var innervalue = this.globalInstance.getAddress(1, this.selectedLoop.loopNumber, e.row["0"].cells["2"].innerHTML, false);
        var imagehtml = "<span><img src = '" + this.detailsServiceObj.getImageUrl(deviceType) + "'/></span>";
        e.row["0"].cells["2"].innerHTML = imagehtml + innervalue;

    }


    constructor(private cacheComponentObj: CacheComponent, private headerserviceObj: Headerservice,
        private moduleServiceObj: ModulesService, private detailsServiceObj: DetailsService) {
    }

    ngOnInit() {
       // this.loopView = this.selectedLoop;
        this.getDeviceTypes(false);
       // this.populateDevices(this.selectedLoop.id);
    }


    getDeviceTypes(isDetector: boolean) {
        this.detailsServiceObj.getDeviceTypesSrvc().subscribe(response => { this.populateDeviceTypesList(response, isDetector) });
    }

    populateDeviceTypesList(resp, isDetector) {
        if (resp !== undefined) {
            this.deviceTypes = resp;

            this.detailsServiceObj.updateCache(this.deviceTypes, isDetector);
            this.detailTypes = this.detailsServiceObj.types;
            this.isTypes = true;
        }
        console.log(this.deviceTypes);
    }

    populateDevices(loop: number) {
        this.moduleServiceObj.getModulesSrvc(loop).then(response => { this.populateDevicesGrid(response) });
        this.noOfdeviceSelected.text = "00";
    }
    isFilterApplied: boolean = false;
    populateDevicesGrid(resp) {
        if (resp !== undefined) {
            if (this.filterCriteriaDetectors.DeviceTypes.length > 0) {
                this.devices = resp.filter(i => this.filterCriteriaDetectors.DeviceTypes.some(j => j == i.deviceTypeId));
                if (this.filterCriteriaDetectors.DeviceWithLabel != undefined) {
                    if (this.filterCriteriaDetectors.DeviceWithLabel == true) {
                        this.devices = this.devices .filter(i => i.description !== "" && i.description !== null);
                    }
                    else {
                        this.devices = this.devices .filter(i => i.description == "" || i.description == null);
                    }
                }
                this.isFilterApplied = true;
            }
            else {
                if (this.filterCriteriaDetectors.DeviceWithLabel != undefined) {

                    if (this.filterCriteriaDetectors.DeviceWithLabel == true) {
                        this.devices  = resp.filter(i => i.description !== "" && i.description !== null);
                    }
                    else {
                        this.devices = resp.filter(i => i.description == "" || i.description == null);
                    }
                }
                else {
                    this.devices  = resp;
                }
            }

           
            this.devices.forEach(i => {
                i.deviceTypeLabel = this.getDeviceTypeDescription(i.deviceTypeId);
                i.zoneNumber = Number(i.zoneNumber) <= 9 ? (String('0').repeat(2) + i.zoneNumber).substr((2 * -1), 2) : i.zoneNumber;
                i.progZoneOn = this.prgZonesUIManipulation(i.progZoneOn);
                i.progZonePulse = this.prgZonesUIManipulation(i.progZonePulse);
                i.progZoneCoincide = this.prgZonesUIManipulation(i.progZoneCoincide);
                i.progZoneCoincide3 = this.prgZonesUIManipulation(i.progZoneCoincide3);
                i.progZoneDelay = this.prgZonesUIManipulation(i.progZoneDelay);
            });
        }
        else if(resp === undefined)
        {
            this.devices = [];
        }
        this.gridData = this.devices;
        this.updateDefaultScreen();
        this.enableDisableFooterActions();
        //this.devicesCountEvent.emit(this.devices != null ? this.devices.length : 0);
    }

    prgZonesUIManipulation(prgZones: any):string
    {
        if (prgZones) {
            var pZones = [];
            var prg = prgZones.split(', ', 5);
            prg.forEach(pZone => {
                var z = Number(pZone) <= 9 ? (String('0').repeat(2) + pZone).substr((2 * -1), 2) : pZone;
                pZones.push(z);
                 })
            return pZones.join(', ');   
        }
        return null;
    }

    updateDefaultScreen() {
        if (this.devices && this.devices.length > 0) {
            this.deviceDefaultView.visible = false;
        }
        else {
            if (!this.isFilterApplied)
            this.deviceDefaultView.visible = true;
        }
    }

    //method customizes the delete pop up for the delete devices
    openDeleteView() {
        this.deleteModal.currentDeleteObj.id = "Modules";

        var keyslabel: string[] = [];
        this.devices.filter(i => i.isSelected == true).map(j => { keyslabel.push(this.globalInstance.getAddress(1, this.selectedLoop.id, j.deviceAddress.toString(), false)) });
        var devicesDeleted = keyslabel.join();
        this.deleteModal.currentDeleteObj.label = devicesDeleted;
        this.deleteModal.deletemsg.text = this.deleteConfirmationMsg.text;;
        this.deleteModal.popupLabel.text = this.globalInstance.getLiteral("DEVICE_DELETE_LABEL");
        this.deleteModal.currentDeleteObj.id = "Modules";
        this.deleteModal.lastUpdated.visible = false;
        this.deleteModal.enterPassword.visible = false;
        this.deleteModal.deleteFiles.visible = false;
        this.deleteModal.description.visible = true;
        this.deleteModal.projId.visible = false;
        this.deleteModal.deleteicon = "";
        this.deleteModal.confirmationMsg.text = "";
    }

    onChangeProgZone() {
        ///todo: on prog Zone
    }

    onAssignToZone() {  ///TODO: change zone
        this.assignZoneModal.ngOnInit();
        this.assignZoneModal.isDetector = false;
        this.assignZoneModal.currentDevices = this.selectedModules;
       // this.assignZoneModal.assignZone();
       // this.populateDevices(this.selectedLoop.id);
    }

    //// delete the devices based on the device id passed
    deleteModuleDevices() {
        var keys: any[] = [];
        this.devices.filter(i => i.isSelected == true).map(j => { keys.push(j.id) });
        this.moduleServiceObj.deleteModulesSrvc(keys).then(
            response => {
                if (response.ok) {
                    this.populateDevices(this.selectedLoop.id);
                    this.noOfdeviceSelected.text = "00";
                }
            },
            error => {
                console.log(error);
            }
        );
    }


    ///TODO: checkbox change event to populate the number of selected devices
    onchange(args: any) {
        var keys: any[] = [];
        this.devices.filter(i => i.isSelected == true).map(j => { keys.push(j.id) });
    }

  
    GetCategory(type: number): ModuleCategory {
        if (type == 9 || type == 10) {
            return ModuleCategory.Input_Modules;
        }
        else {
            return ModuleCategory.Output_Modules;
        }
    }


    updateModuleDevices(type: number) {
        if (type != -1) {
            console.log(type);
            var keys: Module[] = [];
            this.devices.filter(i => i.isSelected == true).map(j => { keys.push(j) });
            keys.forEach(i => { i.deviceTypeId = type; i.modulesCategory = this.globalInstance.GetModuleDeviceCategory(type); });
            debugger;
            this.moduleServiceObj.updateModulesSrvc(keys).then(
                response => {
                    if (response.ok) {
                        this.populateDevices(this.selectedLoop.id);
                        this.selectedDeviceType = -1;
                    }
                },
                error => {
                    console.log(error);
                }
            );
        }
    }





    padLeft(text: string): string {
        return "P1L" + this.selectedLoop.id + "D" + (String('0').repeat(3) + text).substr((3 * -1), 3);
    }
    //Add bulk Detectors/Modules 
    addDetectorsModules(): void {
        this.populateDevices(this.selectedLoop.id);
        this.addDeviceModal.onClose();
        this.addDeviceModal.ngOnDestroy();

    }
    openAddDevices() {
        this.addDeviceModal.isDetector = false;
        this.addDeviceModal.isAddBtnDisabled = true;
        this.addDeviceModal.getDevicesList();
    }

    openChangeType() {
        var selecteddevicetypes: any[] = [];
        this.devices.filter(i => i.isSelected == true).map(j => {
            if (selecteddevicetypes.indexOf(j.deviceTypeId) === -1)
                selecteddevicetypes.push(j.deviceTypeId)
        });
        if (selecteddevicetypes.length == 1) {
            this.selectedDeviceType = selecteddevicetypes[0];
        }
        else
        {
            this.selectedDeviceType = -1;
        }
        console.log(this.selectedDeviceType);
        ///TODO: change type
    }

    onAssignProgZone() {
        this.devices.filter(i => i.isSelected == true).map(j => {
            this.selectedModule = j;
        });
        console.log(this.selectedModule);
        this.progZonesModel.selectedModule = this.selectedModule;
      
        this.progZonesModel.getProgZones();
        this.progZonesModel.progZonesheaderModel.selectZoneType(1);
        //this.progZonesModel.selectZoneType = 1;
    }

    assignedZones() {
        this.assignZoneModal.onClose();
        this.populateDevices(this.selectedLoop.id);
        this.rowsSelected = false;
    }
    assignedProgZones() {
        this.progZonesModel.onClose();
        this.populateDevices(this.selectedLoop.id);
        this.selectedDeviceType = -1;
        this.rowsSelected = false;
        this.isProgZoneEnabled = false;
    }

    getDeviceTypeDescription(typeId: number) {
        console.log(this.detailTypes);
        if (this.detailTypes !== undefined) {
            var deviceTyp = this.detailTypes.filter(i => i.value == typeId);
            console.log(deviceTyp);
            return deviceTyp[0].display;
        }
        return typeId.toString();
    }

    onRowSelected(e: any) {
        var selectedRecords: Object[] = this.grid.widget.getSelectedRecords();
        this.setSelectedRowsCount(selectedRecords.length, e, true);
        this.noOfdeviceSelected.text = (String('0').repeat(2) + selectedRecords.length).substr((2 * -1), 2);
        this.enableDisableFooterActions();
     }
     onRowDeselected(e: any)
     {
         var selectedRecords: Object[] = this.grid.widget.getSelectedRecords();
         this.setSelectedRowsCount(selectedRecords.length, e, false);
         this.noOfdeviceSelected.text = (String('0').repeat(2) + selectedRecords.length).substr((2 * -1), 2);
         this.enableDisableFooterActions();
    }
    setSelectedRowsCount(count: number, e: any, selected: boolean)
     {
       
         if (this.devices.length == count) {
             this.devices.forEach(res => {
                 res.isSelected = selected;
             });
         }
         else if(count==0)
         {
             this.devices.forEach(res => {
                 res.isSelected = selected;
             });
         }
         else {
             this.devices.filter(i => i.id == e.row["0"].cells["1"].innerHTML).map(res => {
                 res.isSelected = selected;
             });
         }
     }
    enableDisableFooterActions()
    {
        if (this.devices && this.devices.length > 0) {

           if (Number(this.noOfdeviceSelected.text) == 1) {
                var curModules = this.devices.filter(i => i.isSelected == true);
                var cate = this.GetCategory(curModules[0].deviceTypeId);
                if (cate == ModuleCategory.Output_Modules)
                    this.isProgZoneEnabled = true;
                else
                    this.isProgZoneEnabled = false;
            }
            else {
                this.isProgZoneEnabled = false;
            }

            if (Number(this.noOfdeviceSelected.text) > 0) {
                this.rowsSelected = true;
                this.selectedModules = this.devices.filter(i => i.isSelected == true);
            }
            else
                this.rowsSelected = false;
        }
    }
    //TO DO 
    //show() {
    //    this.grid.widget.columnChooserModule.openColumnChooser(200, 50); // give X and Y axis
    //}
    //Formating the grid cell values
    //public valueAccess = (field: string, data: Object, column: Object) => {
    //    var innervalue = this.globalInstance.getAddress(1, this.selectedLoop.loopId, data[field], false);
    //    var imagehtml = "<span><img src = 'app/shared/images/Optical.png'/></span>";
      
    //    return imagehtml + innervalue;
    //}
    ngOnChanges() {
        this.loopView = this.selectedLoop;
        this.populateDevices(this.selectedLoop.id);
    }
    getcustom(e:any)
    {
        console.log(e);
    }
}
