﻿import { Injectable, Input } from "@angular/core";
import { Headers, Http, RequestOptions } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { Module } from "../../model/modulesModel";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from "../../shared/hooks/config";


@Injectable()
export class ModulesService {

    constructor(private http: Http,
        private serviceUrlObj: ServiceUrl,
        private configObj: Config,
        private errorHandlerObj: MyErrorHandler) {
        this.serviceUrlObj = new ServiceUrl(this.configObj);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching list of modules by loop id
     */
    getModulesSrvc(loopId: number): Promise<Module[]> {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetModules);
        const re = /\/id\//g;
        getSvcUrl = getSvcUrl.replace(re, `/${loopId}/`);
        return this.http
            .get(getSvcUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    deleteModulesSrvc(modules: any[]) {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Modules);
        return this.http.delete(getSvcUrl, new RequestOptions({
            headers: contentHeaders,
            body: modules
        }))
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                console.log(response);
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    updateModulesSrvc(modules: Module[]) {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Modules);
        return this.http
            .put(getSvcUrl, modules, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }



}
