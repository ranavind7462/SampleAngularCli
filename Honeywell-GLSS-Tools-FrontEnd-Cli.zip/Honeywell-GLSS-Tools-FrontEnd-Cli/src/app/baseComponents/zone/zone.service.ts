﻿import { Injectable } from "@angular/core";
import { Headers, Http, Response, RequestOptions } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { Zone } from "../../model/zone";
import { PanelModule } from "../../model/panelmodule";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from "../../shared/hooks/config";
import { Panel } from "../../model/panel";
import { DeviceComplex } from "../../model/device";
import { Observable } from "rxjs";

@Injectable()
export class ZoneService {

    constructor(private http: Http,
        private serviceUrlObj: ServiceUrl,
        private configObj: Config,
        private errorHandlerObj: MyErrorHandler) {
        this.serviceUrlObj = new ServiceUrl(this.configObj);
    }

    getPanels(siteId: string): Promise<Panel[]>
    {
        let getPanelsUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetPanels);
        const re = /\/id\//g;
        getPanelsUrl = getPanelsUrl.replace(re, `/${siteId}/`);
        return this.http
            .get(getPanelsUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching list of zone by panel id
     */
    geZones(panelId: number): Promise<Zone[]> {
      
        let getServiceUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetZones);
        const re = /\/id\//g;
        getServiceUrl = getServiceUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(getServiceUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
       // return Promise.resolve(data);
    }

    geZonesByPanelId(panelId: number): Observable<Zone[]>
    {

        let getServiceUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetZones);
        const re = /\/id\//g;
        getServiceUrl = getServiceUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(getServiceUrl)
            .map((res: Response) => res.json());
    }

    /**
    * This is a service method which makes a rest call to the webapi for creating or updating a zone
    * through the add new zone popup.
    */
    createZone(zoneObj)
    {
        const postUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Zone);
        return this.http
            .post(postUrl, zoneObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    editZone(zoneObj) {
        console.log(zoneObj.id);
        const zoneId = zoneObj.id;
        const putUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Zone) + "/" + zoneId;
        return this.http
            .put(putUrl, zoneObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching the current zone details based on the
     * zone id passed.
     */
    getZone(zoneId: number): Promise<any> {
        const getUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Zone) + "/" + zoneId;
        
        return this.http
            .get(getUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
               return data; // Change it on integration with proper API.
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }

    deleteZone(zoneIds)
    {
        const deleteUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Zone);
        return this.http.delete(deleteUrl, new RequestOptions({
            headers: contentHeaders,
            body: zoneIds
        }))
            .toPromise()
        //return this.http
        //    .delete(deleteUrl, zoneIds, { headers: contentHeaders })
        //    .toPromise()
            .then(response => {
                return response;
            },
            response => {
                console.log(response);
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }
    
    //deleteZone(zoneId: number) {
    //    const deleteUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Zone) + "/" + zoneId;
    //    return this.http
    //        .delete(deleteUrl)
    //        .toPromise()
    //        .then(response => {
    //            return response;
    //        },
    //        response => {
    //            console.log(response);
    //            return response;
    //        })
    //        .catch(this.errorHandlerObj.handleServerError);
    //}  

    getNextZoneNumber(panelId: number)
    {
        let getServiceUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.NextZoneNumber);
        const re = /\/id\//g;
        getServiceUrl = getServiceUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(getServiceUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }


    getDevicesByPanelId(panelId: number): Observable<any> {
        let getUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.DevicesByPanelId);
        const re = /\/id\//g;
        getUrl = getUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(getUrl)
            .map((res: Response) => res.json());
          
    }

    getDevicesByZoneId(zoneId: number): Observable<DeviceComplex[]>
    {
        let getUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.DevicesByZoneId);
        const re = /\/id\//g;
        getUrl = getUrl.replace(re, `/${zoneId}/`);
        return this.http
            .get(getUrl)
            // ...and calling .json() on the response to return data
            .map((res: Response) => res.json());
            //...errors if any
          //  .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
    }
   
    assignDevicesToZone(devices: DeviceComplex[], zoneId: number)
    {
        let postUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.AssignDevicesToZone);
        let re = /\/id\//g;
        postUrl = postUrl.replace(re, `/${zoneId}/`);
        return this.http
            .post(postUrl, devices, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }
}