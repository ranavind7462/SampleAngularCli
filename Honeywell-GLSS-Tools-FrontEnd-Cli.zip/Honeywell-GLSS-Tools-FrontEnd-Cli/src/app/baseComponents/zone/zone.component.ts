import { Component, OnInit, ViewChild, ViewEncapsulation, ElementRef, Output, EventEmitter, Input } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { ZoneService } from "./zone.service";
import { PanelService } from "../panel/panel.service";
import { Panel } from "../../model/panel";
import { Zone, ZoneContentView } from "../../model/zone";
import { PanelSettingComponent } from "../../fireComponents/panelSetting/panel-setting.component";
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";
import { Globals } from "../../shared/hooks/globals";
import { TreeViewComponent } from "../../fireComponents/treeview/treeview.component";
import { AddNewPanelComponent } from "../../fireComponents/addNewPanel/add-new-panel.component";
import { ZoneListComponent } from "../../fireComponents/zoneList/zoneList";
import { AddNewZoneComponent } from "../../fireComponents/addNewZone/add-new-zone.component";
import { ZoneOverviewComponent } from "../../fireComponents/zoneoverview/zoneoverview.component";
import { DeviceGridComponent } from "../../fireComponents/devicegrid/devicegrid";
import { DeviceComplex } from "../../model/device";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { ZoneDevicesGridComponent } from "../../fireComponents/zonedevicesgrid/zonedevicesgrid.component";
import { ZoneGridViewComponent } from "../../fireComponents/zonegridview/zonegridview.component";
import { NFRChecking } from "../../model/enums";
@Component({
    selector: "zone-app",
    templateUrl: "./zone.component.html",
    styleUrls: ["./zone.component.css"],
    encapsulation: ViewEncapsulation.None
})

export class ZoneComponent //implements OnInit {
 {
    @ViewChild("confirmBtn") confirmBtn: ElementRef;
        
    zones: Zone[];
    allDevices: DeviceComplex[];
    gridDevices: DeviceComplex[];
    zoneDevices: DeviceComplex[];
    selectedZone: Zone;
    selectedGridZones: Zone[];    

    selectedPanel: number;
    //selectedPanelLabel: string;

    @ViewChild(AddNewZoneComponent)
    addZoneModel: AddNewZoneComponent;

    //@ViewChild(ZoneDevicesComponent)
    //zoneDevicesComponentObj: ZoneDevicesComponent;

    @ViewChild(ZoneOverviewComponent)
    zoneOverviewComponentObj: ZoneOverviewComponent;

    @ViewChild(DeviceGridComponent)
    deviceGridComponentObj: DeviceGridComponent;

    @ViewChild(ZoneDevicesGridComponent)
    zoneDevicesGridComponentObj: ZoneDevicesGridComponent;

    @ViewChild(ZoneGridViewComponent)
    zoneGridViewComponentObj: ZoneGridViewComponent;

    @ViewChild(DeletePopupComponent)
    deletepopupComponentObj: DeletePopupComponent;

    zoneDeleteVisibility = "hidden";

    //For Internaliization
    globalInstance = Globals.getInstance();
    overview = { text: this.globalInstance.getLiteral("ZONE_OVERVIEW"), visible: true };
    toggleTreeTopology = { text: "fa fa-chevron-left", visible: true };
    toggleGridTopology = { text: "true", visible: true };
    zoneDefaultView = { visible: false };
    devices = { text: this.globalInstance.getLiteral("ZONE_DEVICES"), visible: false };
    deviceList = { text: this.globalInstance.getLiteral("ZONE_DEVICE_LIST"), visible: true };
    addZone = { text: this.globalInstance.getLiteral("ZONE_ADD"), visible: true };
    editZone = { text: this.globalInstance.getLiteral("ZONE_EDIT"), visible: true };
    deleteZone = { text: this.globalInstance.getLiteral("ZONE_DELETE_LABEL"), visible: true };
    save = { text: this.globalInstance.getLiteral("COMMON_SAVE"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };
    zoneLayout = this.globalInstance.getLiteral("ZONE_LAYOUT");
    zoneVisibility = "hidden";
    //zoneOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9 zone__div--border";
    //zoneOverviewCss = "col-xs-6 col-sm-6 col-md-6 col-lg-6 zone__div--border";
    zoneOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9";
    selectedTab = ZoneContentView.Overview;
    private zoneContentView = ZoneContentView;
    addMode: boolean = true;
    zoneMiddleContentCss = "col-xs-6 col-sm-6 col-md-6 col-lg-6";
    zoneRightRontentCss = "col-xs-3 col-sm-3 col-md-3 col-lg-3";
    zoneHeadrMiddleContentCss = "col-xs-6 col-sm-6 col-md-6 col-lg-6";
    zoneHeadrRightRontentCss = "col-xs-3 col-sm-3 col-md-3 col-lg-3";
    zoneLeftContentCss = "col-xs-3 col-sm-3 col-md-3 col-lg-3";
    spanDisplay = "";
    footerWidth = "zone_overview_footer_width";
    /* Edit Zone */

    headertemplate: string;
    template: string;
    //watermark: string;
    //panelLayoutfieldsvalues: Object;
    //currentpanelLayout: any;

    constructor(private cacheComponentObj: CacheComponent,
        private headerserviceObj: Headerservice,
        private zoneServiceObj: ZoneService,
        private panelServiceObj: PanelService,
        private detailsServiceObj: DetailsService)
    {
        this.headerserviceObj.dispatchAction(`>${this.globalInstance.getLiteral("ZONES")}`);
        this.headertemplate = `<div class="zone__dropheader--size"><span>${this.zoneLayout}</span></div>`;
        this.template = '<div><img class="zone__layoutimag--float" src="${pimg}"/>' +
            '<div class="zone__layouttext--pos"><div class="zone__dropitem--size"> ${no} </div><div class="zone__dropitem--size"> ${display} </div></div></div>';     
    }

    ngOnInit()
    {
        this.selectedZone = null;
        this.getPanels();
    }

    panels: Panel[];

    getPanels()
    {
        this.zoneServiceObj
            .getPanels(this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId))
            .then(response => this.getPanelList(response));
    }

    getPanelList(resp: Panel[])
    {
        this.panels = resp;
        if (this.panels && this.panels.length > 0)
        {
            this.selectedPanel = this.panels[0].id;
            //this.selectedPanelLabel = this.panels[0].label;
            this.getZones();
            this.getDevices();
        }
    }

    getZones() 
    {
        this.zoneServiceObj
            .geZonesByPanelId(this.selectedPanel).subscribe((data) =>
            {
                this.createBulkTreeViewNodes(data);
         });        
    }

    switchOverPanel(panelId: number)
    {
        this.selectedPanel = panelId;   
        this.selectedZone = null;
        this.getZones();
        this.getDevices();
    }

    createBulkTreeViewNodes(resp: Zone[])
    {
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId, this.selectedPanel);
        this.zones = resp;
        this.zones = this.globalInstance.getZoneNumberDisplay(this.zones);
        this.updatePanelViewVisibility();
       
    }

    updatePanelViewVisibility(): any
    {
        if (this.zones && this.zones.length > 0)
        {
            this.zoneDefaultView.visible = false;
            this.zoneVisibility = "visible";

            if (this.selectedZone == null)
            {
                this.selectedZone = this.zones[0];
            }
            this.updateContentOnUi(this.selectedZone);
        }
        else
        {
            this.zoneDefaultView.visible = true;
            this.zoneVisibility = "hidden";
        }
    } 

    createNewTreeViewNode(newZone: Zone)
    {
        if (newZone)
        {
            newZone.zoneNumberDisplay = this.globalInstance.getSingleZoneNumberDisplay(newZone.zoneNumber);
            this.zones.unshift(newZone);
            this.zoneGridViewComponentObj.bingGrid(this.zones);
            this.updatePanelViewVisibility();
        }
    }

    deleteTreeViewNode(zoneId: any)
    {
        if (zoneId) {
            const node = this.zones.filter(x => x.id === zoneId)[0];
            this.zones.splice(this.zones.indexOf(node), 1);
            this.updatePanelViewVisibility();
        }
    }

    getDevices()
    {
        this.zoneServiceObj.getDevicesByPanelId(this.selectedPanel).subscribe((data) =>
        {
            this.setDevicesResponse(data);
        });
    }

    setDevicesResponse(resp: DeviceComplex[])
    {   
        this.allDevices = resp;
        if (resp)
        {
            resp = this.globalInstance.getZoneNumberDisplay(resp);
            this.detailsServiceObj.getDeviceTypesSrvc().subscribe((i) => {
                resp.forEach((item) => {

                    var result = i.filter(i => i.id == item.deviceTypeId);
                    item.deviceType = result[0].deviceType;
                    item.address = this.globalInstance.getAddress(1, item.loopNumber, item.address, item.isDetector);

                    this.allDevices = resp;
                    this.updatePanelViewVisibility();
                    this.loadDevices();
                });               
            });
        }
        else
        {
            this.loadDevices();
        }
    }

    loadDevices()
    {
        if (this.allDevices && this.allDevices.length > 0)
        {
            this.gridDevices = this.allDevices.filter(d => d.zoneNumber != this.selectedZone.zoneNumber && d.panelId == this.selectedPanel);
            this.zoneDevices = this.allDevices.filter(d => d.zoneNumber == this.selectedZone.zoneNumber && d.panelId == this.selectedPanel);
        }
        else
        {
            this.gridDevices = null;
            this.zoneDevices = null;
        }    
    }

    updateContentOnUi(zoneNode: Zone): any
    {
        this.selectedZone = zoneNode;
        this.zoneDeleteVisibility = (zoneNode.zoneNumber < 2 ? "hidden" : "visible");
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.selectedZoneId, this.selectedZone.id);
        this.loadDevices();

        this.deviceGridComponentObj.setGridDevices(this.gridDevices);

        switch (this.selectedTab)
        {   
        case ZoneContentView.Overview:
                {
                    if (this.zoneOverviewComponentObj)
                    {
                        this.SaveCancel(false);                      
                    }
                break;
            }
        case ZoneContentView.Devices:
                {
                    if (this.zoneDevicesGridComponentObj)
                    {
                        this.zoneDevicesGridComponentObj.bingGrid(this.zoneDevices);
                    }                    
                    break;
                }
           
        }
    }

    //toggleTreeTopologyText(): any
    //{
    //    if (this.toggleTreeTopology.text === "fa fa-chevron-right")
    //    {
    //        this.toggleTreeTopology.text = "fa fa-chevron-left";
    //        this.zoneOverviewCss = "col-xs-6 col-sm-6 col-md-6 col-lg-6 zone__div--border";
    //    }
    //    else
    //    {
    //        this.zoneOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9 zone__div--border";
    //        this.toggleTreeTopology.text = "fa fa-chevron-right";
    //    }
    //}

    toggleGridTopologyText(): any
    {
        if (this.toggleGridTopology.text === "true")
        {
            this.toggleGridTopology.text = "false";
            //this.zoneOverviewCss = "col-xs-12 col-sm-12 col-md-12 col-lg-12 zone__div--borderwidth";
            this.zoneMiddleContentCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9";
            this.zoneRightRontentCss = "hide__Span_Text";
            this.zoneHeadrMiddleContentCss = "col-xs-8 col-sm-8 col-md-8 col-lg-8";
            this.zoneHeadrRightRontentCss = "col-xs-1 col-sm-1 col-md-1 col-lg-1";
            this.footerWidth = "zone_overview_footer_extendwidth";
            this.spanDisplay = "hide__Span_Text";
        }
        else
        {
           // this.zoneOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9 zone__div--border";
            this.zoneMiddleContentCss = "col-xs-6 col-sm-6 col-md-6 col-lg-6";
            this.zoneRightRontentCss = "col-xs-3 col-sm-3 col-md-3 col-lg-3";
            this.zoneHeadrMiddleContentCss = "col-xs-6 col-sm-6 col-md-6 col-lg-6";
            this.zoneHeadrRightRontentCss = "col-xs-3 col-sm-3 col-md-3 col-lg-3";
            this.toggleGridTopology.text = "true";
            this.spanDisplay = "";
            this.footerWidth = "zone_overview_footer_width";
        }
    }

    //toggleTopologyText(): any
    //{
    //    if (this.toggleTreeTopology.text === "fa fa-chevron-right")
    //    {
    //        this.toggleTreeTopology.text = "fa fa-chevron-left";
    //        if (this.toggleGridTopology.text === "fa fa-chevron-right")
    //        {
    //            this.zoneOverviewCss = "col-xs-6 col-sm-6 col-md-6 col-lg-6 zone__div--border";
    //        }
    //        else
    //        {
    //            this.zoneOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9 zone__div--border";
    //        }
            
    //    }
    //    else
    //    {
    //        this.toggleTreeTopology.text = "fa fa-chevron-right";
    //        if (this.toggleGridTopology.text === "fa fa-chevron-right")
    //        {
    //            this.zoneOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9 zone__div--border";                
    //        }
    //        else
    //        {
    //            this.zoneOverviewCss = "col-xs-12 col-sm-12 col-md-12 col-lg-12 zone__div--borderwidth";
    //        }
    //    }
    //}

    //toggleGridTopologyText(): any
    //{
    //    if (this.toggleGridTopology.text === "fa fa-chevron-right")
    //    {
    //        this.toggleGridTopology.text = "fa fa-chevron-left";
    //        if (this.toggleTreeTopology.text === "fa fa-chevron-right")
    //        {
    //            this.zoneOverviewCss = "col-xs-12 col-sm-12 col-md-12 col-lg-12 zone__div--borderwidth";
    //        }
    //        else
    //        {
    //            this.zoneOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9 zone__div--border";
    //        }
    //    }
    //    else
    //    {
    //        this.toggleGridTopology.text = "fa fa-chevron-right";
    //        if (this.toggleTreeTopology.text === "fa fa-chevron-right")
    //        {
    //            this.zoneOverviewCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9 zone__div--border";
    //        }
    //        else
    //        {
    //            this.zoneOverviewCss = "col-xs-6 col-sm-6 col-md-6 col-lg-6 zone__div--border";
    //        }
    //    }
    //}

    deleteCurrentZone()
    {
        let obj: Zone = this.selectedZone;
        this.setDeleteView();        
        this.deletepopupComponentObj.currentDeleteObj.id = "Zone";
        this.deletepopupComponentObj.deletemsg.text = this.globalInstance.getLiteral("ZONE_DELETE_CONFIRMATION_MSG");
        this.deletepopupComponentObj.deleteicon = "Zone.png";
        this.deletepopupComponentObj.showDeleteicon = true;
        this.deletepopupComponentObj.currentDeleteObj.desc = this.zoneDevices.length + this.globalInstance.getLiteral("ZONE_DELETE_DEVICES");
        this.deletepopupComponentObj.currentDeleteObj.label = obj.zoneNumberDisplay + " - " + obj.zoneDescription;        
    }

    deleteBulkZone(obj: Zone[])
    {    
        this.setDeleteView();

        this.deletepopupComponentObj.currentDeleteObj.id = "MulZone";
        this.deletepopupComponentObj.deletemsg.text = this.globalInstance.getLiteral("ZONE_MUL_DELETE_CONFIRMATION_MSG");
        this.deletepopupComponentObj.showDeleteicon = false;
        this.deletepopupComponentObj.currentDeleteObj.desc = "";
        this.deletepopupComponentObj.currentDeleteObj.label = "";   
        this.selectedGridZones = obj;
    }

    setDeleteView()
    {
        this.deletepopupComponentObj.popupLabel.text = this.globalInstance.getLiteral("ZONE_DELETE_LABEL");        
        this.deletepopupComponentObj.deleteNote.text = this.globalInstance.getLiteral("ZONE_DELETE_NOTE").replace('{0}', `${this.zones[0].zoneDescription}`);
        this.deletepopupComponentObj.lastUpdated.visible = false;
        this.deletepopupComponentObj.enterPassword.visible = false;
        this.deletepopupComponentObj.deleteFiles.visible = false;
        this.deletepopupComponentObj.description.visible = true;
        this.deletepopupComponentObj.projId.visible = false;
        this.deletepopupComponentObj.deleteNote.visible = true;
        this.deletepopupComponentObj.confirmationMsg.text = "";
    }

    addNewZone(): void
    {
        this.addZoneModel.popupTitle.text = this.globalInstance.getLiteral("ZONE_ADD_ZONE");
        this.addZoneModel.addZone = new Zone();
        this.addMode = true;
        this.addZoneModel.isZoneNoRange = true;
        this.addZoneModel.isDuplicate = false;

        this.zoneServiceObj.getNextZoneNumber(this.selectedPanel).then(
            response => {
                if (response)
                {
                    let newZone: Zone = new Zone();
                    newZone.zoneNumber = response;
                    this.addZoneModel.isZoneMaxReached = false;
                    newZone.zoneNumberDisplay = this.globalInstance.getSingleZoneNumberDisplay(newZone.zoneNumber);
                    this.addZoneModel.addZone = newZone;
                }
                else
                {
                    this.addZoneModel.isZoneMaxReached = true;
                }
            },
            error => {
                console.log(error);
            }
        );
    }

    createZone(obj: Zone): void
    {
        obj.panelID = this.selectedPanel;
        this.zoneServiceObj.createZone(obj).then(
            response => {
                if (response.json() != NFRChecking.Duplicate)
                {
                    this.addZoneModel.onClose();
                    const data = response.json();
                    data.zoneNumberDisplay = this.globalInstance.getSingleZoneNumberDisplay(data.zoneNumber);
                    this.selectedZone = data;
                    this.updateTreeView(data.id);
                    this.SaveCancel(false);  
                }
                else if (response.json() == NFRChecking.Duplicate)
                {
                    this.addZoneModel.isDuplicate = true;
                    console.log(response);
                }
            },
            error => {
                console.log(error);
            }
        );
    }

    createOrEditZone(obj: Zone): void
    {
        if (obj != null)
        {
            obj.zoneNumber = Number(obj.zoneNumberDisplay);
            if (this.addMode)
            {
                this.createZone(obj);
            }
            else
            {
                ///TODO: Service call to update the Zone
                this.zoneServiceObj.editZone(obj)
                    .then(response =>
                    {
                        if (response.json() != NFRChecking.Duplicate)
                        {
                            const data = response.json();                           
                            this.selectedZone = obj;
                            this.getZones();
                            this.SaveCancel(false);
                        }
                        else if(response.json() == NFRChecking.Duplicate)
                        {
                            this.zoneOverviewComponentObj.isDuplicate = true;
                            console.log(response);
                        }
                    },
                    error => {
                        console.log(error);
                    }
                    );
            }
        }
    }

    deleteZoneData()
    {
        var keys: any[] = [];
        keys.push(this.selectedZone.id);
        this.zoneServiceObj.deleteZone(keys).then(
            response => {
                if (response.ok)
                {
                    this.selectedZone = null;
                    this.getZones();
                }
            },
            error => {
                console.log(error);
            }
        );
    }

    // delete the zones selected in grid
    deleteSelectedZones()
    {
        var keys: any[] = [];
        this.selectedGridZones.forEach(j => { keys.push(j.id); });
        this.zoneServiceObj.deleteZone(keys).then(
            response => {
                if (response.ok) {
                    this.selectedZone = null;
                    this.getZones();
                }
            },
            error => {
                console.log(error);
            }
        );
    }

     /* Edit Zone */
    updateTreeView(newZoneId : number) {
        this.zoneServiceObj
            .getZone(newZoneId)
            .then(response =>
            {
                this.createNewTreeViewNode(response);
            });
    }

    /**
     * This helper method gets the selected panel tab number and assigns to the selectedTab variable
     * @param num
     */
    setTab(view: ZoneContentView)
    {
        this.selectedTab = view;
    }

    /**
     * This helper function returns true if the number equals to the currently selected tab. It is used to apply the
     * appropriate css class to the tab control to indicate the "selected/unselected status" of a tab
     * @param num
     */
    isSelected(view: ZoneContentView)
    {
        return this.selectedTab === view;
    }

    assignDevices(obj): void
    {
        this.zoneServiceObj.assignDevicesToZone(obj, this.selectedZone.id)
            .then(response => {
                if (response.ok)
                {
                    const data = response.json();
                    this.getZones();
                    this.getDevices();
                }
            },
            error => {
                console.log(error);

            }
            );
    }

    isDetailsView: boolean = true;
    detailsViewImgSrc: string = "app/shared/images/listViewActiveState.png";
    gridViewImgSrc: string = "app/shared/images/gridViewDefaultState.png";

    switchZoneView(detailsView: boolean): void
    {
        this.isDetailsView = detailsView;

        if (detailsView)
        {
            this.detailsViewImgSrc = this.detailsViewImgSrc.replace("Default", "Active");
            this.gridViewImgSrc = this.gridViewImgSrc.replace("Active", "Default");
            this.zoneMiddleContentCss = "col-xs-6 col-sm-6 col-md-6 col-lg-6";
            this.zoneLeftContentCss = "col-xs-3 col-sm-3 col-md-3 col-lg-3";
            this.toggleGridTopologyText();
        }
        else
        {
            this.detailsViewImgSrc = this.detailsViewImgSrc.replace("Active", "Default");
            this.gridViewImgSrc = this.gridViewImgSrc.replace("Default", "Active");
            //this.zoneMiddleContentCss = "col-xs-9 col-sm-9 col-md-9 col-lg-9";
            this.zoneMiddleContentCss = "col-xs-12 col-sm-12 col-md-12 col-lg-12";
            this.zoneLeftContentCss = "hide__Span_Text";
            this.zoneRightRontentCss = "hide__Span_Text";
            this.toggleGridTopology.text = "true";
            this.toggleGridTopologyText();
        }

    }

    SaveCancel(flag: boolean = true): void
    {
        this.globalInstance.saveCancelClick(flag);
        this.zoneOverviewComponentObj.isDuplicate = false;
        this.zoneOverviewComponentObj.isZoneNoRange = true;
        this.addMode = false;
    }

    cancelAddZone(): void
    {
        this.addMode = false;
    }
}
