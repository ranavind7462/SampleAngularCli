﻿import { LBCLoop } from "./LBCLoop";
import { OnBoardIO } from "./OnBoardIO";

export class LBCPanel {
    numberOfLoops: number;
    quiscentCurrent: number | ConstrainDouble;
    alarmCurrent: number | ConstrainDouble;    
    loopsList: LBCLoop[];
    onboardIOList: OnBoardIO[];
}