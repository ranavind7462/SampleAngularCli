export enum DeviceType
    {
        Optical_Smoke = 1,
        Heat_Sensor,
        Multi_Sensor,        
        Beam_Sensor,
        Duct_Sensor,
        Sounder,
        CTRL,
        Relay,
        CallPoint,
        ZoneMonitor
}
export enum ProgZoneType
  {
    On,
    Pulse,
    Delay,
    Coincidence,
    Coincidence_3
  }
export enum ModuleCategory
  {    
    Input_Modules,
    Output_Modules,
    IO_Modules
  };
  /// <summary>
  /// DeviceCategory contains all supported device categories 
  /// </summary>
  export enum DeviceCategory
    {
        Sensors = 0,
        Input_Modules,
        Output_Modules,
        IO_Modules
    };

    /// <summary>
    /// DeviceAction contains all supported device actions 
    /// </summary>
    export enum DeviceAction
    {
        Fire = 0,
        Plant_Warning
    };


    export enum OnBoardIODevice
    {
        Auxiliaries = 0,
        OnBoardSounderC1,
        OnBoardSounderC2,
        CommunicationModule,
        NetworkModule
    };

    export enum Protocol
    {
        MorelyIAS = 0,
        Honeywell = 1,
        SystemSensor = 2,
        Apollo = 3,
        Hochiki = 4,
        Nittan = 5
    };
    export enum PanelVariant {
        None,
        MorleyDXc,
        StartXUL,
        StartXEN,
        SmartXUL,
        SmartXEN,
        SmartXAUS
    } 
    export enum PanelLanguage
    {
        English = 65,
        Swedish = 66,
        Spanish = 67,
        Portuguese = 68,
        Icelandic = 69,
        Italian = 70,
        Polish = 71,
        Hungarian = 72,
        Sloverian = 73,
        Dutch = 74,
        French = 75,
        German = 76,
        Belgium = 77,
        Danish = 78,
        Norwegian = 79,
        Czech = 80,
        Unknown = 81,
        Turkish = 82,
        Russian = 83,
        Romanian = 84,
        Bulgarian = 85,
        Austrian = 86,
        Slovak = 87,
        Croatian = 88,
        Greek = 89,
        Latvian = 90,
        Estonian = 91,
        Lithuanian = 92,
        Indonesian = 93
    };

   
export class NFRChecking {
    static Duplicate: string = "Duplicate Value";
    static LimitExceded: string = "LimitExceded";
    static NoData: string = "Not in database";
    };

