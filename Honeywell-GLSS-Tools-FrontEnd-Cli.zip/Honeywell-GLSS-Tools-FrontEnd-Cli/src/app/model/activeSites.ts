﻿export class ActiveSites {
    organizationId: number;
    label: string;
    staus: string;
    authUser: string;
    address: string;
    contactNo: string;
}