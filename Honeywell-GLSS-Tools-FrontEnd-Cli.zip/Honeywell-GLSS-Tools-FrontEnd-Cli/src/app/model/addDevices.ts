﻿export class AddDevices
{
    loopId: number;
    numberOfDetector: number | null = null;
    typeOfDetector: number;
    numberOfModule: number | null = null;
    typeOfModule: number;
}    