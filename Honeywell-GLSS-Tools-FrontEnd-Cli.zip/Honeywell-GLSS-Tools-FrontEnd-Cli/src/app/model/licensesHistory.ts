﻿export class LicenseHistory {
    date: string;
    action: string;
    licenseKey: string;
}