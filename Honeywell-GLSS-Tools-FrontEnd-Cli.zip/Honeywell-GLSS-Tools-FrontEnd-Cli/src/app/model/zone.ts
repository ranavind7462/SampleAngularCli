
import { Detector } from "./detectorModel";
import { Module } from "./modulesModel";

export class Zone
{   
    id: number;
    panelID: number;
    zoneNumber: number;
    zoneNumberDisplay: string;
    zoneDescription: string;
    lstDetectors: Detector[];
    lstModules: Module[];
    devicesCount: number;
    isSelected: boolean = false;
}

export enum ZoneContentView
{
    Overview,
    Devices
}