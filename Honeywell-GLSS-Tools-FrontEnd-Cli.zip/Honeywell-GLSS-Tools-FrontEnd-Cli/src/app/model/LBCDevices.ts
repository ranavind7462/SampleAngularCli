﻿import { DeviceType } from "./enums";

export class LBCDevices {
    quiscentCurrent: number | ConstrainDouble;
    alarmCurrent: number | ConstrainDouble;
    quantity: number;
    quiscentCurrentTotal: number | ConstrainDouble;
    alarmCurrentTotal: number | ConstrainDouble;
    deviceType: DeviceType;
    deviceName: string;   
    minAlarm: number | ConstrainDouble;
    maxAlarm: number | ConstrainDouble;
    minQuiescent: number | ConstrainDouble;
    maxQuiescent: number | ConstrainDouble;
    loopId: number;
}