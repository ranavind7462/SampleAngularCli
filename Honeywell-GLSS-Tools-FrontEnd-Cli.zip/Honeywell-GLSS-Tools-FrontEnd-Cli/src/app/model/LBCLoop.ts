﻿import { LBCDevices } from "./LBCDevices";

export class LBCLoop {
    totalDeviceQuantity: number;
    quiscentCurrentLoopDevices: number | ConstrainDouble;
    alaramCurrentLoopDevices: number | ConstrainDouble;    
    loopId: number;
    loopDes: string;
    deviceList: LBCDevices[];
    totalLoopAlarmCurrent: any ;
    totalLoopQuiscentCurrent: number | ConstrainDouble;
    percentageValue: number;

}