export class Device {
    id: number;
    loopId: number;
    description: string;
    deviceAddress: number;
    deviceAddressLabel: string;
    zoneIDs: number | null;
    zoneDescription: string;
    deviceType: number = 0;
    deviceTypeLabel: string;
    deviceCategory: number = 1;
    deviceCategoryLabel: string;
    deviceAction: number = 0;
    deviceActionLabel: string;
    deviceLabel: string;
    deviceProfile: string = "Profile 1";
    level: number | null;
    mode: number | null;
    isLatched: boolean = true;
    isSilenceable: boolean = true;
    isEvacuable: boolean = true;
    isMonitored: boolean = true;
    isPulsable: boolean = true;
    isSounder: boolean = true;
    rawType: number | null;
    pcSpecifier: number | null;
    dPreAlarm: number = 80;
    dFullAlarm: number = 100;
    nPreAlarm: number = 80;
    nFullAlarm: number = 100;
    lastModifiedDate: Date = new Date();
    isSelected: boolean = false;
    isLedBlink: boolean = true;
}

export enum DeviceContentView {
    Overview,
    Devices,
    DevicesDetail,
    Modules,
}

export enum ContentViewType {
    Graphical,
    List
}

export enum DeviceType {
    Devices,
    Modules
}

export enum DetailsViewType {
    DeviceInfo,
    Comments
}


export class DeviceComplex
{
    id: number;
    isDetector: boolean = true;
    address: string;
    label: string;
    deviceTypeId: number;
    deviceType: string;
    zoneNumber: number;
    zoneNumberDisplay: string;
    zoneDescription: string;
    loopNumber: number;
    loopId: number;
    panelId: number;
    isSelected: boolean = false; 
    ImageUrl: string;
}