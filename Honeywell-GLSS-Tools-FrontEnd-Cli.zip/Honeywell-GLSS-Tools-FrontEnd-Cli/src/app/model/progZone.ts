export class ProgZone
{   
    id: number;
    moduleID: number;
    zoneID: number;
    progZoneTypeID: number;
    progZoneDelay: number;    
}

