export enum AlertTypes {
    Warning,
    Info,
    Error
}