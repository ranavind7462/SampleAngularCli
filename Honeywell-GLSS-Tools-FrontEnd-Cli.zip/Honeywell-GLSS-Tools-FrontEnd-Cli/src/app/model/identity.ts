export class Identity {
    constructor(
        public UserName: string,
        public Password: string
    ) {
    }
}