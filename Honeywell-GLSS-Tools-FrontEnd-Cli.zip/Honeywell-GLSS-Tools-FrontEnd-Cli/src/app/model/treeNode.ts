export class TreeNode {
    showIcon = true;
    expanded = false;
    icon = "fa fa-sort-down ";
    index: number;
    lable: string;

    constructor(public id, public nodeData, public image,public panelType, public displayLable) {

        //Enable only when tree has some child
         //if (id) {
         //    this.showIcon = true;
         //    this.icon = this.getIcon();
         //}
    }

    expand() {
        this.expanded = !this.expanded;
        this.icon = this.getIcon();
    }

    private getIcon() {
        if (this.showIcon) {
            if (this.expanded) {
                return "fa fa-sort-up ";
            }
            return "fa fa-sort-down ";
        }
        return null;
    }
}