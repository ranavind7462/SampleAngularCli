﻿import { OnBoardIODevice } from "./enums";

export class OnBoardIO {
    id: number;
    panelId: number;    
    alarmCurrent: DoubleRange;
    quiscentCurrent: DoubleRange;
    quantity: number;
    onBoardDeviceID: OnBoardIODevice;
}