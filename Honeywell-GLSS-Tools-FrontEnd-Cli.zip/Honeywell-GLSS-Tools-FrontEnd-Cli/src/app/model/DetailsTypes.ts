export class ProgZoneTypes
{   
    id: number;
    progZoneType: string;
}

export class DeviceTypes {
    id: number;
    deviceType: string;
    isModule: boolean;
    isDetector: boolean;
    isSelected: boolean;
}

export class Types {
    value: number;
    display: string;
    imageUrl: string;
}
export class FilterCriteria {
    DeviceTypes: number[]=[];
    DeviceWithLabel: boolean;
    //DetectorTypes: DeviceTypes[];
    //ModulesTypes: DeviceTypes[];
    //DeviceWithLabel: string;
    //DeviceWithOutLabel: string;
}