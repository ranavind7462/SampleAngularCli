﻿export class CustomerSite {
    id: number;
    label: string;
    //customerName: string;
   // contactName: string;
    //phoneNumber: string;
   // email: string;
   // mobileNumber: string;
    address: string;
    addressLine2: string;
    zipCode: number | null = null;
    city: string;
    //state: string;
    country: string;
    //name: boolean;
    //customerProjectReference: string;
    siteType: string;
    panelCount: number = 0;
    lastModifiedDate: Date;
}