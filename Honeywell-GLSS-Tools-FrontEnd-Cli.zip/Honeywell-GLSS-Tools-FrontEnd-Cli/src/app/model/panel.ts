import {Loop } from "../model/Loop";
import { PanelVariant } from "./enums";
export class Panel {
    id: number;
    siteId: string;
    variant: PanelVariant; 
    label: string;
    number: number;
    noOfLoops: number = 1;
    protocol: string = "Morely IAS";
    isBlinking: boolean = true;
    isIOCardFitted: boolean = false;
    isFatFbeFitted: boolean = false;
    ioSounderId: number = 0;
    softwareVer: string = "No Panel Connected";
    language: number = 0;
    dateFormat: number = 0;
    accessTimeout: number = 10;
    inhibitTimeout: number = 0;
    numberOfRepeater: number = 0;
    isLogDiagnostic: boolean = false;
    isAutoResound: boolean = true;
    isExtendedPSUFitted: boolean = false;
    isSounderDisable: boolean = false;
    defaultSounderMode: number = 16;
    stage: number = 0;
    detectionMode: number = 0;
    nextServiceDate: Date = new Date();
    phoneNo: string;
    lastModifiedDate: Date = new Date();
    NormalOperation: number = 48;
    InAlarm: number = 20;
    delayT1: number;
    delayT2: number;
    verificationT1: number;
    verificationT2: number;
    loops: Loop[];    
}

let date: Date = new Date();


export enum PanelType {
    PANEL_STARTX_EN = 0,
    PANEL_STARTX_UL = 1,
    PANEL_SMARTX_EN =2,
    PANEL_SMARTX_UL = 3,
    PANEL_SMARTX_AUS=4
}

//export enum PanelMode {
//    Unknown = 0,
//    Operation = 1,
//    Commission = 2,
//    Test = 3
//}

//export enum CountryFunctionality {
//    Britian = 0,
//    German = 1,
//}

export enum PanelContentView {
    Overview,
    panelSettings,
    Timer,
    Configuration,
    HMI,
    Events
}

export enum ContentViewType {
    Graphical,
    List
}