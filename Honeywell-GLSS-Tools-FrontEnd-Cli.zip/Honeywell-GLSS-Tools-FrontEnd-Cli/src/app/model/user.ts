﻿export class User {
    userName: string;
    designation: string;
    organization: string;
    mobileNo: number;
    emailID: string;
   }