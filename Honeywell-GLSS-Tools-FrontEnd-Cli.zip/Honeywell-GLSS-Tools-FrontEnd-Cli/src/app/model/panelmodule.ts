import { Globals } from "../shared/hooks/globals";

export namespace literalConstants {
    
    export class ModuleType {
        globalInstance = Globals.getInstance();
        literal = this.globalInstance.literalObj;

        moduleTypeList: Map<number, any> = new Map(<[number, any][]>[
            [0, this.literal['PANEL_MODULETYPE_UNKNOWN']],
            [1, this.literal['PANEL_CONFIGLIST_PANELMODULES']],
            //[2, this.literal['PANEL_MODULETYPE_MAINCPU']],
            [2, this.literal['PANEL_MODULETYPE_REDUNDANTMAINCPU']],
            [3, this.literal['PANEL_MODULETYPE_SYSTEMSENSORLOOP']],
            [4, this.literal['PANEL_MODULETYPE_FUSIONLOOP']],
            [5, this.literal['PANEL_MODULETYPE_ESSERBUSLOOP']],
            [6, this.literal['PANEL_MODULETYPE_VIGILONLOOP']],
            [7, this.literal['PANEL_MODULETYPE_IDNETGATEWAY']],
            [8, this.literal['PANEL_MODULETYPE_FUSIONICONICNETWORK']],
            [9, this.literal['PANEL_MODULETYPE_ESSERNETGATEWAY']],
            [10, this.literal['PANEL_MODULETYPE_VIGILONNETWORKGATEWAY']],
            [11, this.literal['PANEL_MODULETYPE_DELTANETWORKGATEWAY']],
            [12, this.literal['PANEL_MODULETYPE_CHARGER']],
            [13, this.literal['PANEL_MODULETYPE_FATFBF']],
            [14, this.literal['PANEL_MODULETYPE_FAREFRE']],
            [15, this.literal['PANEL_MODULETYPE_SERIALCOMMUNICATION']],
            [16, this.literal['PANEL_MODULETYPE_IO']]
        ]);        
    }
}

export class PanelModule {
    value: number;
    labelRows: string;
    imageUrl: number;
}

export class PanelModuleViewModel {
    Id: number;
    PanelId: number;
    Label: string;
    SlotNumber: number;
    moduleType : number;
}
export class PanelLayout {
    panelId: string;
    layoutId: number;
}

export enum ModuleType {
    Unknown = 0,
    NotifierP1 = 1,
    MainCpu = 1,
    RedundantMainCpu = 2,
    SystemSensorLoop = 3,
    FusionLoop = 4,
    EsserbusLoop = 5,
    VigilonLoop = 6,
    IdNetGateway = 7,
    FusionIconicNetwork = 8,
    EssernetGateway = 9,
    VigilonNetworkGateway = 10,
    DeltaNetworkGateway = 11,
    Charger = 12,
    FatFbf = 13,
    FareFre = 14,
    SerialCommunication = 15,
    IO = 16,
}