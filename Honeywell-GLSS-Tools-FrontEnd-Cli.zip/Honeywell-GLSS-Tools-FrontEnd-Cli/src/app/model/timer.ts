﻿export class Timer {
    id: number;
    panelId: number;
    startTime: string;
    endTime: string;
    repeatMode: number;
    noOfDays: number;
    repeatDays: string;
    isSelected: boolean = false;
}