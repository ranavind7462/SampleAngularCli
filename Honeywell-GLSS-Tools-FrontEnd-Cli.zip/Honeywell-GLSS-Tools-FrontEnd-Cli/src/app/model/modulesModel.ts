import { DeviceType, Protocol, DeviceAction, ModuleCategory } from "./enums";

export class Module {
    id: number;
    dxdbRef: number;
    pcSpecifier: number;
    protocol: Protocol;
    deviceTypeId: DeviceType;
    rawType: string;
    zoneID: number;
    zoneDescription: string;
    comment: string;
    loopID: number;
    deviceAction: DeviceAction;
    modulesCategory: ModuleCategory;
    mode: number;
    level: number;
    isSilenceable: boolean;
    isEvacuable: boolean;
    isMonitored: boolean;
    isPulsable: boolean;
    deviceAddress: string;
    description: string;
    isAssigned: boolean;
    delaySeconds: number;
    progZoneOn: string;
    progZonePulse: string;
    progZoneDelay: string;
    progZoneCoincide: string;
    progZoneCoincide3: string;
    progZonesByType: any;
    isSelected: boolean;
    zoneNumber: string;
    deviceTypeLabel: string;
}
