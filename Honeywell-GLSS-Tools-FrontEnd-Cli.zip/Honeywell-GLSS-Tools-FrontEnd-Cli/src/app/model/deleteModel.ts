﻿export class DeleteModel {
    id: string;
    label: string;
    desc: string;
    //customerProjectReference: string;
    siteType: string;
    address: string;
}