﻿export class LicenseModel {
    action: number;
    key: string;
}
export enum Licensetab {
    History,
    Active
}
export enum FlexActionTypes { Activation, Return, Synchronizing, None }