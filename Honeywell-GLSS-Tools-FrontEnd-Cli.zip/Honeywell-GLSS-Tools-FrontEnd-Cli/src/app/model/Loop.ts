import { Panel } from "./panel";

export class Loop {
    id: number;
    panelId: number;
    loopNumber: number;  
    loopDescription: string;
    loopProtocol: string;
    deviceProfile: string;
    loopResistance: number;   
    deviceCount: number;
    deviceFault: number;
    defaultDetectorZoneId: number;
    defaultModuleZoneId: number;
}

let date: Date = new Date();

export enum PanelType {
    StartX = 0,
    SmartX = 1,
}
export enum PanelContentView {
    Overview,
    panelSettings,
    Configuration,
    HMI,
    Events
}
export enum LBCLoopContentView {
    Devices,
   Parameters
}

export enum ContentViewType {
    Graphical,
    List
}