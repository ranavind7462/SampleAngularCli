import { DeviceType, Protocol, DeviceAction } from "./enums";

export class Detector {
    id: number;
    dxDbRef: number;
    pcSpecifier: number;
    protocol: Protocol;
    deviceTypeId: DeviceType;
    deviceTypeLabel: string;
    rawType: string;
    zoneId: number;
    zoneDescription: string;
    comment: string;
    loopId: number;
    action: DeviceAction;
    isLedBlink: boolean;
    isLatched: boolean;
    dPreAlarm: number;
    dFullAlarm: number;
    nPreAlarm: number;
    nFullAlarm: number;
    deviceAddress: string;
    description: string;
    isAssigned: boolean;
    isSelected: boolean;
    zoneNumber: string;
    deviceAddressLabel: string;
}
