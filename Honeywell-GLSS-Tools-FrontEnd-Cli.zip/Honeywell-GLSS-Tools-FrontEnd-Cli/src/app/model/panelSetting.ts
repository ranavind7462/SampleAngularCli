﻿
export class PanelSetting
{
    protocol: string;
    enableDeviceBlink: boolean;
    phoneNo: number | null;
    nextServiceDate: any;
    enableSysIOCardFitted: boolean;
    fatFbeFitted: boolean;
    sysIOSounder2: string;
    softwareVersion: string;
    panelLanguage: string;
    dateFormat: string;
    acessTimeout: number;
    inhibitTimeout: number;
    noOfRepeaters: number;
    enableLogDiagnostics: boolean;
    enableAutomaticResound: boolean;
    enableExtendedPsuFitted: boolean;
    enableSounderGroup: boolean;
    defaultSounderMode: number;
    stage1_2: string;
    detectionMode: number;
    delayT1: number;
    delayT2: number;
    verificationT1: number;
    verificationT2: number;
}