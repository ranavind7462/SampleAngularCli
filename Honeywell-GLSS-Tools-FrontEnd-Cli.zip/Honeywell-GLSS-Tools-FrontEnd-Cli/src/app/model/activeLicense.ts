﻿export class ActiveLicense {
    feature: string;
    activationDate: string;
    endDate: string;
    mode: string;
}