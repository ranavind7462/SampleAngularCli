﻿export interface BlueToothDevices {
    plutoBLE6: string;   
}