//This file is used to read the keys from the configuration json file and provide the values to the application.

import { Injectable } from "@angular/core";
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable";
import "rxjs/Rx";
import "rxjs/add/operator/map";

import { MyErrorHandler } from "../utility/errorhandler";
import { Globals } from "./globals";

@Injectable()
export class Config {
    private config: any;
    globalInstance = Globals.getInstance();

    constructor(private http: Http, private errorHandler: MyErrorHandler) {
    }

    //Loads the config json file before the application bootstraps and load.
    load() {
        return new Promise((resolve) => {
          this.http.get("assets/configuration/env.json").map(res => res.json())
                .subscribe(configData => {
                        this.config = configData;

                        this.http.get(`assets/resources/resource_${this.config.lang}.json`).map(res => res.json())
                            .subscribe(data => {
                                this.globalInstance.literalObj = data;
                                resolve(true);
                            });

                        if (!(this.config.lang === "en")) {
                            this.http.get(`assets/resources/resource_en.json`).map(res => res.json())
                                .subscribe(data => {
                                    this.globalInstance.literalEngObj = data;
                                    resolve(true);
                                });
                        }
                    },
                    err => this.errorHandler.handleFailureResponse(err));
        });
    }

    //Returns the value for given key from the config file(json file)
    getEnvVar(key: any) {
        const envVar = this.config;
        return envVar[key];
    }
};
