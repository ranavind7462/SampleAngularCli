﻿import { ProgZoneTypes, DeviceTypes } from "../../model/DetailsTypes";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from '../../shared/hooks/config';
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headers, Http } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { ModuleCategory } from "../../model/enums";

export class Globals {

    literalObj: Object = {};
    literalEngObj: Object = {};
    isEditClicked: boolean = false;

    private static instance: Globals;       

    static getInstance() {
        if (!Globals.instance) {
            Globals.instance = new Globals();
           
        }
        return Globals.instance;
    }

    getLiteral(key): any {
        const value = this.literalObj[key];
        if (value)
            return value;
        return this.literalEngObj[key];
    }

    getAddress(panelId:number,loopId:number, address:string, isDetector: boolean): string {
        var type: string = "D";
        if (isDetector)
            type = "D";
        else
            type = "M";
        return "P" + panelId + "L" + loopId + type + (String('0').repeat(3) + address).substr((3 * -1), 3);
    }

    getZoneNumberDisplay(zones: any):any
    {
        if (zones)
        {
            if (zones && zones.length > 0) {
                zones.forEach(i => { i.zoneNumberDisplay = Number(i.zoneNumber) <= 9 ? (String('0').repeat(2) + i.zoneNumber).substr((2 * -1), 2) : i.zoneNumber.toString(); });
            }
        }
        return zones;
    }

    getSingleZoneNumberDisplay(zoneNumber: number): string
    {
        return zoneNumber <= 9 ? (String('0').repeat(2) + zoneNumber).substr((2 * -1), 2) : zoneNumber.toString();
    }

    ///TODO: move this to DB & API
    GetModuleDeviceCategory(type: number): ModuleCategory {
        if (type == 9 || type == 10) {
            return ModuleCategory.Input_Modules;
        }
        else {
            return ModuleCategory.Output_Modules;
        }
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    } 

    onlyAlphaNumericKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : (event.charCode >= 48 && event.charCode <= 57) || (event.charCode >= 65 && event.charCode <= 90) || event.charCode == 32 || (event.charCode >= 97 && event.charCode <= 122);
    } 

    saveCancelClick(flag: boolean, divId: string = "divEditContainer")
    {
        var div = document.getElementById(divId); 
        if (div)
        {
            this.isEditClicked = flag;

            let inputs = div.getElementsByTagName('input');
            let selects = div.getElementsByTagName('select');

            if (this.isEditClicked) {
                for (var i = 0; i < inputs.length; i++) {
                    inputs[i].removeAttribute("disabled");
                    inputs[i].style.backgroundColor = "#FFFFFF";
                }

                for (var i = 0; i < selects.length; i++) {
                    selects[i].removeAttribute("disabled");
                    selects[i].style.backgroundColor = "#FFFFFF";
                }
            }
            else {
                for (var i = 0; i < inputs.length; i++) {
                    inputs[i].setAttribute("disabled", "true");
                    inputs[i].style.backgroundColor = "#F2F2F2";
                }

                for (var i = 0; i < selects.length; i++) {
                    selects[i].setAttribute("disabled", "true");
                    selects[i].style.backgroundColor = "#F2F2F2";
                }
            }
        }
    }
}