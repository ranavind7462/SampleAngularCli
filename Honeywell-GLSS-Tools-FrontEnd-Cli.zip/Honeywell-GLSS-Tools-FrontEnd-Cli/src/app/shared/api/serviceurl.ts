//Rest endpoints used across the application will be mapped to the respective WebAPI.
import { Inject } from "@angular/core";
import { Config } from "../hooks/config";

export enum ApiName {
    GetActiveSites,
    GetSite,
    AddNewSite,
    EditSite,
    DeleteSite,
    Panel,
    DeletePanel,
    GetPanels,
    GetSupportedModuleTypes,
    GetFreeSlots,
    PostPanelModule,
    EditPanelModule,
    DeletePanelModule,
    PanelModuleDetail,
    PanelModuleList,
    Device,
    Modules,
    GetDetectors,
    GetModules,
    Timer,
    DeleteTimer,
    GetTimers,
    Zone,
    GetZones,
    EditLoop,
    //ModulesByZoneId,
    //DetectorsByZoneId,
    NextZoneNumber,
    DevicesByPanelId,
    DevicesByZoneId,
    AssignDevicesToZone,
    Flex,
    UpdateDetectorwithZone,
    GetProgZones,
    Detector,
    GetDeviceTypes,
    GetProgZoneTypes,
    ProgZones,
    GetLBCData,
    Bluetooth,
    ScanBluetooth,
    pairBluetooth,
    ShareConfig,
    ImportConfig,
    CheckPanelDeuplication,
    GetLoops,
    GetLoopDeviceCount,
    CheckPanelNFR,
    CheckSiteNFR,
    SaveLBCData,
    Registration,
    GetRegisterUsers
}



export class ServiceUrl {

    private configObject;
    constructor( @Inject(Config) configObj: Config) {
        this.configObject = configObj;
    }

    private url: string;
    private base: string;
    private port: string;

    fetchUrlEndPoint(apiName: ApiName): string {
        this.base = this.configObject.getEnvVar("baseUrl");
        this.port = this.configObject.getEnvVar("port");

        // todo: the version number should come from configObject
        const version = "1";
        this.url = this.base.concat(this.port, `/api/v${version}/`);
        switch (apiName) {
            case ApiName.GetActiveSites:
                this.url = this.url.concat("users/6706b743-cbe3-4161-9c2d-71024525e5c1/sites");
                break;
            case ApiName.GetSite:
            case ApiName.AddNewSite:
            case ApiName.EditSite:
            case ApiName.DeleteSite:
                this.url = this.url.concat("sites");
                break;
            case ApiName.Panel:
            case ApiName.DeletePanel:
                this.url = this.url.concat("panels");
                break;
            case ApiName.GetPanels:
                this.url = this.url.concat("sites/id/panels");
                break;
            case ApiName.Zone:
                this.url = this.url.concat("zones");
                break;
            case ApiName.GetZones:
                this.url = this.url.concat("panels/id/zones");
                break;
            case ApiName.NextZoneNumber:
                this.url = this.url.concat("panels/id/NextZoneNumber");
                break;
            case ApiName.DevicesByPanelId:
                this.url = this.url.concat("panels/id/devices");
                break;
            case ApiName.DevicesByZoneId:
                this.url = this.url.concat("zones/id/devices")
                break;
            case ApiName.AssignDevicesToZone:
                this.url = this.url.concat("zones/id/devices");
                break;
            case ApiName.GetSupportedModuleTypes:
                this.url = this.url.concat("panels/id/modules/supportedtypes");
                break;
            case ApiName.GetFreeSlots:
                this.url = this.url.concat("panels/id/freeslots");
                break;
            case ApiName.PostPanelModule:
            case ApiName.EditPanelModule:
            case ApiName.DeletePanelModule:
            case ApiName.Modules:
                this.url = this.url.concat("modules");
                break;
            case ApiName.PanelModuleList:
                this.url = this.url.concat("panels/id/modules");
                break;
            case ApiName.Device:
                this.url = this.url.concat("devices");
                break;
            case ApiName.GetDetectors:
                this.url = this.url.concat("loop/id/detectors");
                break;
            case ApiName.GetModules:
                this.url = this.url.concat("modules/id/loop");
                break;
            case ApiName.GetProgZones:
                this.url = this.url.concat("progzones/id/modules");
                break;
            case ApiName.Timer:
            case ApiName.DeleteTimer:
                this.url = this.url.concat("timer");
                break;
            case ApiName.GetTimers:
                this.url = this.url.concat("panel/id/timer");
                break;
            case ApiName.Flex:
                this.url;
                break;
            case ApiName.UpdateDetectorwithZone:
                this.url = this.url.concat("detectors/zoneID/deviceID/updatedetectorID");
                break;
            case ApiName.Detector:
                this.url = this.url.concat("detectors");
                break;
            case ApiName.GetDeviceTypes:
                this.url = this.url.concat("details/deviceTypes");
                break;
            case ApiName.GetProgZoneTypes:
                this.url = this.url.concat("details/progZoneTypes");
                break;
            case ApiName.ProgZones:
                this.url = this.url.concat("progzones");
                break;
            case ApiName.GetLBCData:
                this.url = this.url.concat("getLBCData/id/lbc");
                break;
            case ApiName.Bluetooth:
                this.url = this.url.concat("Bluetooth");
                break;
            case ApiName.ScanBluetooth:
                this.url = this.url.concat("scan/Bluetooth");
                break;
            case ApiName.pairBluetooth:
                this.url = this.url.concat("pair/Bluetooth");
                break;
            case ApiName.ShareConfig:
                this.url = this.url.concat("ExportConfiguration/ImportExport");
                break;
            case ApiName.ImportConfig:
                this.url = this.url.concat("ImportConfiguration/ImportExport");
                break;
            case ApiName.CheckPanelDeuplication:
                this.url = this.url.concat("CheckPanelduplication/Panel");
                break;
            case ApiName.GetLoops:
                this.url = this.url.concat("loops/loop");
                break;
            case ApiName.EditLoop:
                this.url = this.url.concat("loops/loop");
                break;
            case ApiName.GetLoopDeviceCount:
                this.url = this.url.concat("loops/{id}/loopDeviceCount");
                break;
            case ApiName.CheckPanelNFR:
                this.url = this.url.concat("CheckPanelNFR");
                break;
            case ApiName.CheckSiteNFR:
                this.url = this.url.concat("CheckSiteNFR");
                break;
            case ApiName.SaveLBCData:
                this.url = this.url.concat("lbc/SaveLBCData");
                break;
            case ApiName.Registration:
                this.url = this.url.concat("User");
                break;
            case ApiName.GetRegisterUsers:
                this.url = this.url.concat("User/GetRegisteredUser");
                break;
            default:
                break;
        }
        return this.url;
    }
}