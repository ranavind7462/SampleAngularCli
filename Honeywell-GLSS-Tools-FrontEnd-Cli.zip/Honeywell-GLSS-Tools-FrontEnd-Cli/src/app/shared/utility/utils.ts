﻿//This file holds all Client Side and Generic validation logics.

import { Injectable, Directive, forwardRef, Attribute } from "@angular/core";
import { Http, Response, Headers } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { Observable } from "rxjs";

import { ServiceUrl } from "../api/serviceUrl";
import { FormControl, Validator, AbstractControl, NG_VALIDATORS } from "@angular/forms";

@Injectable()
export class UtilsService {

    constructor() {}

    // Validate at server side
    isAvailable(apiName, data) {
        //TODO
    }

    isValid(apiName, data) {
        //TODO
    }

    isInRange(apiName, data) {
        //TODO
    }

}

// Validate Equal Passowrd for Password and Confirm Password field.
// Below is the Custom validator.

@Directive({
    selector: "[validateEqual][formControlName],[validateEqual][formControl],[validateEqual][ngModel]",
    providers: [
        { provide: NG_VALIDATORS, useExisting: forwardRef(() => EqualValidator), multi: true }
    ]
})
export class EqualValidator implements Validator {
    constructor(@Attribute("validateEqual") public validateEqual: string) {}

    validate(c: AbstractControl): { [key: string]: any } {
        // self value (e.g. retype password)
        const v = c.value;

        // control value (e.g. password)
        const e = c.root.get(this.validateEqual);

        // value not equal
        if (e && v !== e.value)
            return {
                validateEqual: false
            };
        return null;
    }
}