﻿//error handler component
import { ErrorHandler } from "@angular/core";

export class MyErrorHandler implements ErrorHandler {
    handleError(error) {
        // TODO Code Error 
        console.log(`in error handler${error}`);
    }

    handleServerError(error: any): Promise<any> {
        //TODO Server errors like Invalid HTTP request, server not available.
        console.error("An error occurred", error);
        return Promise.reject(error.message || error);
    }

    handleFailureResponse(error: any) {
        //TODO Failure in the response.
        console.log(`Handle Failure Response${error}`);
    }
}

export class MyModule {
}