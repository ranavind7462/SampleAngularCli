﻿//Caching Framework

//import {CacheService, CacheStoragesEnum} from 'ng2-cache/ng2-cache';

export class CacheComponent {

    private siteData;
    //private siteData = new ReplaySubject(1);

    setServiceData(cacheObj, apiName) {
        //set the fetched data in the cache as an object.
        switch (apiName) {
            case "GETSITE":
                this.siteData = cacheObj;
                break;
            case "":
                //TODO
                break;
            default:
                break;
        }
    }

    getServiceData(apiName): any {
        //fetch the cached response 
        switch (apiName) {
            case "GETSITE":
                return this.siteData;
            case "":
                //TODO
                break;
            default:
                return false;
        }
    }

    //set individual data in cache memory in key value format.
    setKeyData(type: StorageType, key, value) {
        switch (type) {
            case StorageType.LocalStorage:
                localStorage.setItem(key, value);
                break;
            case StorageType.SessionStorage:
                sessionStorage.setItem(key, value);
                break;
        }

    }

    //get individual cached data using the key.
    getKeyData(type: StorageType, key) {
        let cachedValue: any;

        switch (type) {
            case StorageType.LocalStorage:
                cachedValue = localStorage.getItem(key);
                break;
            case StorageType.SessionStorage:
                cachedValue = sessionStorage.getItem(key);
                break;
            default:
                cachedValue = "";
                break;
        }
        return cachedValue;
    }

    //delete individual cached data using the key.
    deleteKeyData(type: StorageType, key) {
        switch (type) {
            case StorageType.LocalStorage:
                localStorage.removeItem(key);
                break;
            case StorageType.SessionStorage:
                break;
            default:
                break;
        }
    }
}

export const enum StorageType {
    LocalStorage,
    SessionStorage
}

export class StorageKey {
    static readonly selectedLoopId = "selectedLoopId";
    static readonly selectedPanelId = "selectedPanelId";
    static readonly selectedZoneId = "selectedZoneId";
    static readonly currentSiteId = "currentSiteId";
    static readonly selectedModuleId = "selectedModuleId";
    static readonly selectedModuleName = "selectedModuleName";
    static readonly isSiteSwitched = false;
    static readonly isLicenseAvailable = false;
    static readonly deviceTypes = "DeviceTypeDetails";
    static readonly progZoneTypes = "ProgZoneTypeDetails";
}