import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER, ChangeDetectorRef } from '@angular/core';

import { AppComponent } from './app.component';
import { EJAngular2Module } from 'ej-angular2';

import { HttpModule } from "@angular/http";
import { RouterModule } from "@angular/router";
import { SiteoverviewComponent } from "./baseComponents/siteoverview/siteoverview.component";
import { DashboardComponent } from "./baseComponents/dashboard/dashboard.component";
//import { LoginComponent } from "./baseComponents/login/login.component";
import { ActiveSitesComponent } from "./baseComponents/activesite/active-sites.component";
import { SiteCartComponent } from "./baseComponents/sitecart/sitecart.component";
import { HeaderComponent } from "./fireComponents/header/header.component";
import { Headerservice } from "./fireComponents/header/header.service";
import { SubHeaderComponent } from "./fireComponents/subHeader/sub-header.component";
//import { SignInComponent } from "./fireComponents/signIn/sign-in.component";
//import { CustomerDetailComponent } from "./fireComponents/customerDetail/customer-detail.component";
import { SiteDetailComponent } from "./fireComponents/siteDetail/site-detail.component";
import { AddNewSiteComponent } from "./fireComponents/addNewSite/add-new-site.component";
import { AddNewPanelComponent } from "./fireComponents/addNewPanel/add-new-panel.component";
//import { AuthenticateService } from "./fireComponents/signIn/auth.service";
import { EqualValidator, UtilsService } from "./shared/utility/utils";
import { ActiveSitesService } from "./baseComponents/shared/active-sites.service";
import { CacheComponent } from "./shared/utility/cache.component";
import { Config } from "./shared/hooks/config";
import { MyErrorHandler } from "./shared/utility/errorhandler";
import { FormsModule } from "@angular/forms";
import { ServiceUrl } from "./shared/api/serviceurl";
import { SiteComponent } from "./baseComponents/site/site.component";
import { NavappComponent } from "./fireComponents/navapp/navapp.component";
import { ClickOutsideDirective } from "./shared/directives/click-outside";
import { DeletePopupComponent } from "./fireComponents/deletePopup/delete-popup.component";
import { PanelComponent } from "./baseComponents/panel/panel.component";
import { PanelService } from "./baseComponents/panel/panel.service";
import { PaneloverviewComponent } from "./fireComponents/paneloverview/paneloverview.component";
import { PanelSettingComponent } from "./fireComponents/panelSetting/panel-setting.component";
import { TimerComponent } from "./fireComponents/Timer/timer.component";
import { SaveConfirmComponent } from "./fireComponents/saveConfirm/save-confirm.component";
import { DeviceComponent } from "./baseComponents/device/device.component";
import { DeviceService } from "./baseComponents/device/device.service";
import { AddPanelModuleService } from "./fireComponents/addNewPanelModule/addpanelmodule.service";
import { AddPanelModuleComponent } from "./fireComponents/addNewPanelModule/addpanelmodule.component";
import { Globals } from "./shared/hooks/globals";
import { TabContentComponent } from "./fireComponents/tabContent/tabContent.Component";
import { PanelConfigComponent } from "./fireComponents/panelConfig/panel-config.component";
import { PanelModuleListComponent } from "./fireComponents/panelModuleList/panelmodulelist.component";
import { PanelModuleDetailComponent } from "./fireComponents/panelModuleDetail/panelmoduledetail.component";
import { PanelConfigGraphicalComponent } from "./fireComponents/panelConfigGraphical/panelconfiggraphical.component";
import { TreeViewComponent } from "./fireComponents/treeview/treeview.component";
import { DlsAlertBoxComponent } from "./fireComponents/dlsAlertBox/dlsAlertBox.component";
import { LoopoverviewComponent } from "./fireComponents/loopoverview/loopoverview.component";
import { TimerService } from "./fireComponents/Timer/timer.service";
import { TimerViewComponent } from "./fireComponents/timerview/timerview.component";
import { TimerSettingComponent } from "./fireComponents/TimerSetting/timer-setting.component";
import { LoopComponent } from "./baseComponents/loop/loop.component";
import { AddDeviceComponent } from "./fireComponents/addDevice/add-device.component";
import { DeviceTypeComponent } from './fireComponents/deviceType/device-type.component';
import { DeviceInfoComponent } from './fireComponents/deviceInfo/deviceInfo';
import { DeviceListComponent } from './fireComponents/deviceList/deviceList';
import { DeviceDetailComponent } from './baseComponents/deviceDetail/deviceDetail';
import { ZoneComponent } from "./baseComponents/zone/zone.component";
import { ZoneService } from "./baseComponents/zone/zone.service";
import { ZoneListComponent } from './fireComponents/zoneList/zoneList';
import { AddNewZoneComponent } from "./fireComponents/addNewZone/add-new-zone.component";
import { ZoneOverviewComponent } from "./fireComponents/zoneoverview/zoneoverview.component";
import { LicenseComponent } from "./baseComponents/license/license.component";
import { LicenseHistoryComponent } from "./fireComponents/licenseshistory/licensehistory.component";
import { ActiveLicenseComponent } from "./fireComponents/activelicenses/activelicense.component"
import { LicenseService } from "./baseComponents/license/license.service";
import { ConfirmPopupComponent } from "./fireComponents/confirmPopup/confirmpopup.component";
import { AssignDeviceToZone } from "./fireComponents/assignDevicetoZone/assigndevicetozone.component";
import { ZoneDevicesComponent } from "./fireComponents/zonedevices/zonedevices.component";

import { DetectorsModulesComponent } from "./fireComponents/detectorsModulesList/detectors_modules.component";
import { AddDeviceHeaderComponent } from "./baseComponents/addDeviceHeader/adddeviceheader.component";
import { DeviceAddressComponent } from "./fireComponents/deviceAddress/deviceaddress.component";

import { ModulesComponent } from "./baseComponents/modules/modules.component";
import { ModulesService } from "./baseComponents/modules/modules.service";
import { ProgZonesComponent } from "./fireComponents/progZones/prog_zones.component";
import { ProgZoneService } from "./fireComponents/progZones/prog_zones.service";
import { DeviceGridComponent } from './fireComponents/devicegrid/devicegrid';

import { DetailsService } from "./baseComponents/shared/Details.service";

import { ZoneDeviceService } from "./fireComponents/assignDevicetoZone/zonedevice.service";
import { ProgZoneHeaderComponent } from "./baseComponents/progZoneHeader/progzoneheader.component";
import { ProgZoneListComponent } from "./fireComponents/progZoneList/progzonelist.component";
import { LBCDataService } from "./fireComponents/lbcData/lbcdata.service";
import { LBCData } from "./fireComponents/lbcData/lbcdata.component";
import { BluetoothPairingComponent } from "./fireComponents/bluetoothPairing/bluetooth.pairing.component";

import { ZoneDevicesGridComponent } from "./fireComponents/zonedevicesgrid/zonedevicesgrid.component";
import { ZoneGridViewComponent } from "./fireComponents/zonegridview/zonegridview.component";
import { ImportConfigurationComponent } from "./fireComponents/importConfiguration/import_configuration.component";
import { LoopService } from "./baseComponents/loop/loop.service";
import { NFRPopupPanel } from "./fireComponents/NFRPopUPPanel/NFRPopupPanel.component";
import { LBCValuePopupComponent } from "./fireComponents/lbcvaluepopup/lbcvaluepopup.component";
import { LBCPanelModuleGridComponent } from "./fireComponents/lbcpanelmodulegrid/lbcpanelmodulegrid.component";
import { LBCPanelBatteryComponent } from "./fireComponents/lbcpanelbatterydetails/lbcpanelbatterydetails.component";
import { LBCLoopParaComponent } from "./fireComponents/lbcloopparameter/lbcloopparameter.component";
import { LBCLoopDeviceGridComponent } from "./fireComponents/lbcloopdevicesgrid/lbcloopdevicesgrid.component";
import { LBCListViewComponent } from "./fireComponents/lbclistview/lbclistview.component";
import { LBCComponent } from "./baseComponents/LBC/LBC.component";
import { UserRegistrationComponent } from "./fireComponents/userregistration/user-registration.component";
import { UserRegistrationService } from "./fireComponents/userregistration/user-registration.service";
import { FilterComponet } from "./fireComponents/filter/filter.component";
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent, DashboardComponent, DeletePopupComponent, ClickOutsideDirective,
    NavappComponent, PaneloverviewComponent, PanelSettingComponent, TimerComponent, TimerSettingComponent,
    SubHeaderComponent, EqualValidator, SiteCartComponent, SiteDetailComponent,
    AddNewSiteComponent, ActiveSitesComponent, SiteComponent, SiteoverviewComponent,
    PanelComponent, AddNewPanelComponent, AddPanelModuleComponent,
    TabContentComponent, TreeViewComponent, DlsAlertBoxComponent,
    PanelConfigComponent, PanelModuleListComponent, PanelModuleDetailComponent,
    PanelConfigGraphicalComponent, TimerViewComponent, SaveConfirmComponent, DeviceComponent,
    LoopoverviewComponent, AddDeviceComponent, LoopComponent, DeviceTypeComponent,
    DeviceInfoComponent, DeviceListComponent, DeviceDetailComponent, ZoneComponent, ZoneListComponent, AddNewZoneComponent,
    ZoneOverviewComponent, AssignDeviceToZone, LicenseComponent, LicenseHistoryComponent, ConfirmPopupComponent
    , DetectorsModulesComponent, AddDeviceHeaderComponent, DeviceAddressComponent, ModulesComponent, ProgZonesComponent
    , ActiveLicenseComponent, ZoneDevicesComponent, DeviceGridComponent, ProgZoneHeaderComponent, ProgZoneListComponent, LBCData
    , BluetoothPairingComponent, ZoneDevicesGridComponent, ZoneGridViewComponent, ImportConfigurationComponent, NFRPopupPanel, LBCValuePopupComponent, LBCPanelModuleGridComponent, LBCPanelBatteryComponent
    , LBCLoopParaComponent, LBCLoopDeviceGridComponent, LBCListViewComponent, LBCComponent, UserRegistrationComponent, FilterComponet
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    EJAngular2Module.forRoot(),
    RouterModule.forRoot([
      { path: "dashboard", component: DashboardComponent },
      { path: "registration", component: UserRegistrationComponent },
      { path: "sitecart", component: SiteCartComponent },
      { path: "", redirectTo: "/dashboard", pathMatch: "full" },
      {
        path: "site",
        component: SiteComponent,
        children: [
          { path: "", redirectTo: "siteoverview", pathMatch: "full" },
          { path: "siteoverview", component: SiteoverviewComponent },
          {
            path: "panel", component: PanelComponent
            //children: [
            //    { path: "", redirectTo: "panel", pathMatch: "full" },

            //]
          },
          { path: "zone", component: ZoneComponent },
          { path: "device", component: DeviceComponent },
          { path: "modules", component: ModulesComponent },
          { path: "LBC", component: LBCComponent }
        ]
      }
    ],
    { useHash: true })
  ],
  providers: [UtilsService, Headerservice, MyErrorHandler, CacheComponent, ModulesService, ProgZoneService,
    ActiveSitesService, ServiceUrl, Config, PanelService, AddPanelModuleService, DeviceService, TimerService, ZoneService,
    LicenseService, DetailsService, ZoneDeviceService, LBCDataService, LoopService, UserRegistrationService, {
      provide: APP_INITIALIZER,
      useFactory: (config: Config) => () => config.load(),
      deps: [Config],
      multi: true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
