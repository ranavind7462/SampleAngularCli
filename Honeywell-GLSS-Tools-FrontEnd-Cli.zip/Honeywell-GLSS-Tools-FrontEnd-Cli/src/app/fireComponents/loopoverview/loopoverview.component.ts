import { Component, OnInit, Output, EventEmitter,ViewChild,Input,OnChanges } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { PanelService } from "../../baseComponents/panel/panel.service";
import { LoopService } from "../../baseComponents/loop/loop.service";
import { Panel, PanelType } from "../../model/panel";
import { ActivatedRoute } from "@angular/router";
import { Globals } from "../../shared/hooks/globals";
import {AddNewPanelComponent } from "../../fireComponents/addNewPanel/add-new-panel.component"
import { Loop } from "../../model/loop";
import { DeviceComplex } from "../../model/device";
import { ZoneDevicesComponent } from "../../fireComponents/zonedevices/zonedevices.component";
import { ZoneService } from "../../baseComponents/zone/zone.service";
import { NFRChecking } from "../../model/enums";

@Component({
    selector: "loopoverview-app",
    templateUrl: "./loopoverview.component.html",
    styleUrls: ["./loopoverview.component.css"]
})
export class LoopoverviewComponent implements OnInit {

    @Output()
    editLoopDetailsEvent = new EventEmitter<Loop>();

    @Input() selectedLoop: Loop;

    deviceCount: DeviceComplex[] = [];
    @ViewChild(ZoneDevicesComponent)
    zoneDevicesComponentObj: ZoneDevicesComponent;
    //currentPanel: Panel;
    loopConnected: boolean = true;

    //For Internaliization
    globalInstance = Globals.getInstance();

    loopIDLbl = { text: this.globalInstance.getLiteral("LOOP_SETTING_LABEL_ID"), visible: true };
    loopIDValue = { text: " ", visible: true };
    loopDescriptonLbl = { text: this.globalInstance.getLiteral("LOOP_SETTING_LABEL_DESCRIPTION"), visible: true };
    loopDescriptonValue = { text: " ", visible: true };
    loopProtocolLbl = { text: this.globalInstance.getLiteral("LOOP_SETTING_LABEL_PROTOCOL"), visible: true };
    loopProtocolValue = { text: " ", visible: true };
    deviceProfileLbl = { text: this.globalInstance.getLiteral("LOOP_SETTING_LABEL_DEVICE_PROFILE"), visible: true };
    deviceProfileValue = { text: " ", visible: true };
    loopMaxResLbl = { text: this.globalInstance.getLiteral("LOOP_SETTING_LABEL_MAX_LOOPRES"), visible: true };
    loopMaxResValue = { text: " ", visible: true };
    loopDiagnosticsLbl = { text: this.globalInstance.getLiteral("LOOP_SETTING_LABEL_DIAGNOSTICS"), visible: true };
    loopNotConnectedLbl = { text: this.globalInstance.getLiteral("LOOP_SETTING_LABEL_NOT_CONNECTED"), visible: true };
    if(loopConnected) {
        this.loopNotConnectedLbl = { text: this.globalInstance.getLiteral("LOOP_SETTING_LABEL_CONNECTED"), visible: true };
    }
    deviceCountLbl = { text: this.globalInstance.getLiteral("DEVICE_SETTING_LABEL_DEVICECOUNT"), visible: true };
    deviceFaultsLbl = { text: this.globalInstance.getLiteral("DEVICE_SETTING_LABEL_DEVICEFAULTS"), visible: true };
    deviceTypeLbl = { text: this.globalInstance.getLiteral("DEVICE_SETTING_LABEL_TYPE"), visible: true };
    loopUpdateLbl = { text: this.globalInstance.getLiteral("LOOP_SETTINGS_LABEL_UPDATE_LOOP"), visible: true };
    loopReadBtn = { text: this.globalInstance.getLiteral("LOOP_SETTINGS_LABEL_READ_LOOP"), visible: true };
   

    resistanceRangeError = { text: this.globalInstance.getLiteral("LOOP_SETTING_MAX_LOOPRES_ERR_MSG"), visible: true };

 


    save = { text: this.globalInstance.getLiteral("COMMON_SAVE"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: false };

    loopOverviewVisibility = "hidden";
    loopView: Loop = new Loop();

    private deviceProfileList = [
        { value: "Hospital", text: "Hospital" },
        { value: "Residency", text: "Residency" },
        { value: "Office", text: "Office" }
    ];
    constructor(private cacheComponentObj: CacheComponent,
        private panelServiceObj: PanelService, private loopServiceObj: LoopService, private zoneServiceObj: ZoneService,) {
        this.loopView = Object.assign({}, this.selectedLoop);
    }

    ngOnInit() {
        this.loopView = Object.assign({}, this.selectedLoop);
        this.globalInstance.saveCancelClick(false);  
        this.GetDeviceCountByLoopID();
    }

    GetDeviceCountByLoopID() {
        this.zoneServiceObj.getDevicesByPanelId(this.selectedLoop.panelId).subscribe((data) => {
            if (data == NFRChecking.NoData) {
                this.deviceCount = null;
            }
            else {
                this.setDevicesResponse(data);
            }
        });
    }

    setDevicesResponse(resp: DeviceComplex[]) {
        if (resp) {
           
            var loopDeviceCount :DeviceComplex[] = [];
            resp.filter(device => device.loopId == this.selectedLoop.id).map(d => { console.log(d); loopDeviceCount.push(d) });
            this.deviceCount = loopDeviceCount;
            this.loopView.deviceCount = loopDeviceCount.length;
        }
        else {
            this.deviceCount = null;
            this.loopView.deviceCount = 0;
        }
        this.zoneDevicesComponentObj.isZoneOverview = false;
    }

    ngOnChanges() {
        this.loopView = Object.assign({}, this.selectedLoop);
        this.GetDeviceCountByLoopID();
    }

    cancelClick() {
        this.globalInstance.saveCancelClick(false);
        this.loopView = Object.assign({}, this.selectedLoop);
    }

    SaveLoop() {
        this.loopServiceObj.updateloopSrv(this.loopView).then(() => {
            if (this.loopView.loopDescription == null || this.loopView.loopDescription == "") {
                this.loopView.loopDescription = "Loop " + this.loopView.loopNumber.toString();
            }
            this.selectedLoop = this.loopView;
            this.editLoopDetailsEvent.emit(this.selectedLoop);
            this.globalInstance.saveCancelClick(false);
        });

       
    }

    validateRange(val: any) {


        if (val.value > 120 || val.value < 0) {
            return this.loopView.loopResistance = null;
        }
    }

        onlyAlphaNumericKey(event)
        {
            return this.globalInstance.onlyAlphaNumericKey(event);
        }
}
