import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from "@angular/core";
import { Router } from "@angular/router";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { PanelService } from "../../baseComponents/panel/panel.service";
import { Panel, PanelContentView } from "../../model/panel";
import { ModuleType, literalConstants } from "../../model/panelmodule";
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "panelmodulelist-app",
    templateUrl: "./panelmodulelist.component.html",
    styleUrls: ["./panelmodulelist.component.css"]
})
export class PanelModuleListComponent {

    @Output()
    loadModuleList = new EventEmitter();

    @Output()
    loadModuleDetail = new EventEmitter();

    @Output()
    addNewModuleEvent = new EventEmitter();

    //For Internationalization
    globalInstance = Globals.getInstance();
    private moduleListCount: any;
    private panelLayoutNumber: any;
    moduleType: any = ModuleType;
    appModuleTypes: any = new literalConstants.ModuleType();

    panelModules = {
        text: this.globalInstance.getLiteral("PANEL_CONFIGLIST_PANELMODULES"),
        visible: true
    };
    newCard = { text: this.globalInstance.getLiteral("PANEL_CONFIGLIST_NEWCARD"), visible: true };
    moduleListArray = [];

    constructor(private cacheComponentObj: CacheComponent) {
    }

    loadPanelModuleList(moduleList: any) {
        let active = false;
        this.moduleListArray = [];
        for (let i = 0; i < moduleList.length; i++) {
            active = (i === 0);
            this.moduleListArray.push({
                id: moduleList[i].id,
                moduleName: this.appModuleTypes.moduleTypeList.get(moduleList[i].moduleType),
                configuredOutput: "Short Description",
                selected: active
            });
        }
        this.moduleListCount = (`00${this.moduleListArray.length}`).slice(-2).toString();
        this.loadModuleDetail.emit(moduleList[0].id);
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.selectedModuleId, moduleList[0].id);
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage,
            StorageKey.selectedModuleName,
            this.moduleType[moduleList[0].moduleType]);
    }

    /**
     * This method will update the layout number based on slotNumber selcted and later we will
     * replace this logic once we will get layout detail from web api.
     * @param moduleList : list of modules
     */
    updatePanelLayoutNo(moduleList: any) {
        moduleList.sort((b, a) => (a.slotNumber > b.slotNumber) ? 1 : ((b.slotNumber > a.slotNumber) ? -1 : 0));
        let panelLayoutNumber = moduleList[0].slotNumber;
        if (panelLayoutNumber > 6) {
            if (panelLayoutNumber % 2 !== 0)
                panelLayoutNumber = panelLayoutNumber + 1;
        } else {
            panelLayoutNumber = 6;
        }
        this.panelLayoutNumber = (`00${panelLayoutNumber}`).slice(-2).toString();
    }

    setPanelLayoutNo(panelLayoutNo: any) {
        this.panelLayoutNumber = (`00${panelLayoutNo}`).slice(-2).toString();
    }

    updateModuleDetail(module: any) {
        module.selected = true;
        this.moduleListArray.filter(x => x.id !== module.id).forEach(y => y.selected = false);
        this.loadModuleDetail.emit(module.id);
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.selectedModuleId, module.id);
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.selectedModuleName, module.moduleName);
    }

    addNewModule() {
        this.addNewModuleEvent.emit();
    }
}
