import { Input, Component, ViewChild, Output, EventEmitter, OnInit } from '@angular/core';
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { ZoneService } from "../../baseComponents/zone/zone.service";
import { Zone } from "../../model/zone";
import { ActivatedRoute } from "@angular/router";
import { Globals } from "../../shared/hooks/globals";
import { AddNewZoneComponent } from "../../fireComponents/addNewZone/add-new-zone.component"
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";
import { DeviceComplex } from "../../model/device";
import { ZoneDevicesComponent } from "../../fireComponents/zonedevices/zonedevices.component";

@Component({
    selector: "zoneoverview-app",
    templateUrl: "./zoneoverview.component.html",
    styleUrls: ["./zoneoverview.component.css"]
})
export class ZoneOverviewComponent implements OnInit {

    @Input() currentZone: Zone;
    overZone: Zone;
    @ViewChild('zoneOverviewForm') form;
    @Output() editZonEvent = new EventEmitter<Zone>();
    @ViewChild(ZoneDevicesComponent)
    zoneDevicesComponentObj: ZoneDevicesComponent;
    @Input() footerWidth: string;
    //For Internaliization
    globalInstance = Globals.getInstance();

    @ViewChild(DeletePopupComponent)
    deletepopupComponentObj: DeletePopupComponent;
    @Input() deviceCount: DeviceComplex[];

    zoneNumberLabel = { text: this.globalInstance.getLiteral("ZONE_ZONE_NO"), visible: true };
    zoneDescriptionLabel = { text: this.globalInstance.getLiteral("ZONE_ZONE_DESCRIPTION"), visible: true };
    save = { text: this.globalInstance.getLiteral("COMMON_SAVE"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };
    rangeErrMsg = { text: this.globalInstance.getLiteral("ZONE_RANGE_ERR_MSG"), visible: true };
    zoneExistMsg = { text: this.globalInstance.getLiteral("ZONE_EXIST_ERR_MSG"), visible: true };

    isDuplicate: boolean = false;
    isZoneNoRange: boolean = true;

    constructor(private cacheComponentObj: CacheComponent, private zoneServiceObj: ZoneService) {
    }

    ngOnChanges()
    {
        this.overZone = Object.assign({}, this.currentZone);
    }

    ngOnInit()
    {
        this.globalInstance.saveCancelClick(false);
        this.zoneDevicesComponentObj.loadDevicesCount(this.deviceCount);
        this.isDuplicate = false;
        this.isZoneNoRange = true;
    }

    cancelClick() {
        this.globalInstance.saveCancelClick(false);
        this.isDuplicate = false;
        this.isZoneNoRange = true;
        this.populateContent(this.currentZone);
    }

    populateContent(resp): any {
        this.overZone.zoneNumber = resp.zoneNumber;
        this.overZone.zoneDescription = resp.zoneDescription;
        this.overZone.zoneNumberDisplay = this.globalInstance.getSingleZoneNumberDisplay(this.overZone.zoneNumber);
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    validateRange(val: any) {
        this.isDuplicate = false;
        this.isZoneNoRange = true;
        let min: number = 2;

        if (val > 199 || val < min) {
            this.isZoneNoRange = false;
        }
        else {
            this.isZoneNoRange = true;
        }
    }

    editZone(): void {
        this.editZonEvent.emit(this.overZone);
    }
}
