import { Component, Output, Input, ViewChild, EventEmitter, ElementRef, ViewEncapsulation,OnInit } from "@angular/core";
import { Globals } from "../../shared/hooks/globals";
import { User } from "../../model/user";
import { UserRegistrationService } from "./user-registration.service";
import { NFRChecking } from "../../model/enums";
import { Router } from "@angular/router";
@Component({
    selector: "usr-registration-app",
    templateUrl: "./user-registration.component.html",
    styleUrls: ["./user-registration.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class UserRegistrationComponent {
    globalInstance = Globals.getInstance();
    constructor(private userRegSrvcObj: UserRegistrationService, private route: Router) {
    }
    userName = this.globalInstance.getLiteral("REGISTRATION_USER_NAME");
    designation = this.globalInstance.getLiteral("REGISTRATION_DESIGNATION");
    organization = this.globalInstance.getLiteral("REGISTRATION_ORGANIZATION");
    emailId = this.globalInstance.getLiteral("REGISTRATION_EMAILID");
    mobileNumber = this.globalInstance.getLiteral("REGISTRATION_MOBILE_NUMBER");
    register = this.globalInstance.getLiteral("REGISTRATION_SUBMIT");
    user: User = new User();
    registerUser() {
        //ToDo
        console.log("user click");
        console.log(this.user);
        this.userRegSrvcObj.registerUserSrvc(this.user).subscribe((data) => {
            this.route.navigateByUrl("/dashboard");
        });
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ngOnInit() {
        // this.route.navigateByUrl("/registration");
        let userList: User[] = [];
        this.userRegSrvcObj.getRegisteredUsersSrvc().subscribe((res) => {
            userList = res;


            if (userList.length > 0) {
                
                this.route.navigateByUrl("/dashboard");
            }
        });
        //console.log(result);
    }
}
