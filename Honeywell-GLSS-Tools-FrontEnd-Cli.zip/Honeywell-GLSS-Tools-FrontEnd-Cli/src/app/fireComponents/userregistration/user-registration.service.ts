﻿import { Injectable } from "@angular/core";
import { Headers, Http, RequestOptions, Response } from "@angular/http";

import { Timer } from "../../model/timer";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from "../../shared/hooks/config";
import { Observable } from "rxjs";
import { User } from "../../model/user";


@Injectable()
export class UserRegistrationService {
    constructor(private http: Http,
        private serviceUrlObj: ServiceUrl,
        private configObj: Config,
        private errorHandlerObj: MyErrorHandler) {
        this.serviceUrlObj = new ServiceUrl(this.configObj);
    }
    registerUserSrvc(userObj): Observable<User> {
        const url = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Registration);
        return this.http
            .post(url, userObj, { headers: contentHeaders })
            .map((response: Response) => response.json())
            .catch(this.errorHandlerObj.handleServerError);
    };
    getRegisteredUsersSrvc(): Observable<User[]> {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetRegisterUsers);
       
        return this.http
            .get(getSvcUrl)
            .map((response: Response) => response.json())
            .catch(this.errorHandlerObj.handleServerError);
    }
}