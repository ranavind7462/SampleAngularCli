import { Component, OnInit, Output, EventEmitter,ViewChild ,ViewEncapsulation} from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { PanelService } from "../../baseComponents/panel/panel.service";
import { Panel, PanelType } from "../../model/panel";
import { ActivatedRoute } from "@angular/router";
import { Globals } from "../../shared/hooks/globals";
import {AddNewPanelComponent } from "../../fireComponents/addNewPanel/add-new-panel.component"

@Component({
    selector: "paneloverview-app",
    templateUrl: "./paneloverview.component.html",
    styleUrls: ["./paneloverview.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class PaneloverviewComponent implements OnInit {

    @Output()
    editPanelDetailsEvent = new EventEmitter();

    //currentPanel: Panel;
    addMode: boolean = true;

    //For Internaliization
    globalInstance = Globals.getInstance();

    fusionPanel = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW_FUSIONPANEL"), visible: true };
    fusionPanelLable = { text: " ", visible: true };
    panelTxt = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW_PANEL"), visible: true };
    panelStatus = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW_OFFLINE"), visible: true };
    panelIdTxt = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW_PANEL_NUMBER"), visible: true };
    panelId = { text: "", visible: true };
    serialnotxt = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW_SERIALNO"), visible: true };
    nextserviceontxt = { text: this.globalInstance.getLiteral("PANEL_NEXT_SERVICE_ON"), visible: true };
    nextserviceon = { text: "-", visible: true };
    lastupdateontxt = { text: this.globalInstance.getLiteral("PANEL_LAST_UPDATE_ON"), visible: true };
    lastupdateon = { text: "-", visible: true };
    edit = { text: this.globalInstance.getLiteral("COMMON_EDIT"), visible: true };
    serialno = { text: "xxxxxxxxxx", visible: true };
    panelfunTxt = {
        text: this.globalInstance.getLiteral("PANEL_OVERVIEW_PANELFUNCTION"),
        visible: true
    };
    panelfun = { text: "", visible: true };
    panelSyncStatus = {
        text: this.globalInstance.getLiteral("PANEL_OVERVIEW_PANELSYNCSTATUS"),
        visible: true
    };
    activeEvents = {
        text: this.globalInstance.getLiteral("PANEL_OVERVIEW_ACTIVEEVENTS"),
        visible: true
    };
    conflictDiff = {
        text: this.globalInstance.getLiteral("PANEL_OVERVIEW_CONFLICTSDIFF"),
        visible: true
    };
    loopstxt = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW_LOOPS"), visible: true };
    totladevice = {
        text: this.globalInstance.getLiteral("PANEL_OVERVIEW_TOTAL_DEVICE_DISCOVERED"),
        visible: true
    };
    resolveConflicts = {
        text: this.globalInstance.getLiteral("PANEL_OVERVIEW_RESOLVE_CONFLICTS"),
        visible: true
    };
    paneltopologyTxt = {
        text: this.globalInstance.getLiteral("PANEL_OVERVIEW_PANEL_TOPOLOGY"),
        visible: true
    };
    paneltopology = { text: "", visible: true };
    noofloopTxt = {
        text: this.globalInstance.getLiteral("PANEL_OVERVIEW_PANEL_NO_OF_LOOPS"),
        visible: true
    };
    noofloop = { text: "00", visible: true };
    panelOverviewVisibility = "hidden";
    currentPanel: Panel = new Panel();
    constructor(private cacheComponentObj: CacheComponent,
        private panelServiceObj: PanelService) {
    }

    ngOnInit() {
        const selectedPanelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        if (selectedPanelId) {
            this.panelServiceObj
                .getPanel(selectedPanelId)
                .then(response => this.populatePanelContent(response));
        }
    }

    getPanel(panelId: any): any {
        this.panelServiceObj
            .getPanel(panelId)
            .then(response => this.populatePanelContent(response));
    }

    populatePanelContent(resp): any
    {
        console.log(resp);
        console.log()
        this.fusionPanelLable.text = this.globalInstance.getLiteral(PanelType[resp.type]);
        this.panelId.text = (`000${resp.id}`).slice(-3).toString();
        this.paneltopology.text = this.globalInstance.getLiteral(PanelType[resp.type]);
        //this.panelfun.text = CountryFunctionality[resp.countryFunctionality];
        this.noofloop.text = resp.noOfLoops.toString();
        this.panelOverviewVisibility = "visible";
        this.currentPanel = resp;
        this.nextserviceon.text = (new Date(resp.nextServiceDate)).toLocaleDateString();
        this.lastupdateon.text = (new Date(resp.lastModifiedDate)).toLocaleDateString();
    }

    openEditView() {
        //this.modal.popupLbl.text = this.globalInstance.getLiteral("ADDNEWPANEL_HEADER_EDIT");
        //this.modal.confirm.text = this.globalInstance.getLiteral("COMMON_SAVE");
        //this.modal.cancel.visible = true;
        //this.modal.panel = Object.assign({}, this.currentPanel);
        this.addMode = false;
        this.getPanel(this.currentPanel.id);
        this.editPanelDetailsEvent.emit(this.currentPanel);
    }
}
