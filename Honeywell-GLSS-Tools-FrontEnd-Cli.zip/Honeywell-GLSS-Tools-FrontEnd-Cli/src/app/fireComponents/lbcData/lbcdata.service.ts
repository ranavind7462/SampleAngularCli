﻿import { Injectable } from "@angular/core";
import { Headers, Http, RequestOptions } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from "../../shared/hooks/config";
import { LBCPanel } from "../../model/LbcPanel";
import { LBCDevices } from "../../model/LBCDevices";

@Injectable()
export class LBCDataService {

    constructor(private http: Http,
        private serviceUrlObj: ServiceUrl,
        private configObj: Config,
        private errorHandlerObj: MyErrorHandler) {
       this.serviceUrlObj = new ServiceUrl(this.configObj);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching list of panel by site id
     */
    getLBCData(panelId: string): Promise<LBCPanel[]> {

        let getLBCUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetLBCData);
        const re = /\/id\//g;
        getLBCUrl = getLBCUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(getLBCUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
    }
    ///Save Lbc Device Data
    saveLBCData(device: LBCDevices)
    {
        let saveLBCUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.SaveLBCData);
        return this.http.post(saveLBCUrl, device, { headers: contentHeaders })
            .toPromise().then(responce => { return responce; }).catch(this.errorHandlerObj.handleError);        
    }
}