import { Component, Input, ViewChild, ElementRef } from '@angular/core';
import { Globals } from "../../shared/hooks/globals";
import { Router } from "@angular/router";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { LBCDataService } from "../lbcData/lbcdata.service";
import { LBCPanel } from "../../model/LbcPanel";

@Component({
    selector: "lbcData-app",
    templateUrl: "./lbcdata.component.html",
    styleUrls: ["./lbcdata.component.css"]
})
export class LBCData {
    @Input() panelname: string;
    lbcpanel: LBCPanel = new LBCPanel();    
    globalInstance = Globals.getInstance();
    header: string;
    panelName: string;
    status: string;
    totalPanelCurrent: number;
    loop1: string;
    loop2: string;
    loop3: string;
    loop4: string;
    lbcViewDetails: string;
    lblquiscentCurrent: string;
    lblalarmCurrnet: string;
    quiscentCurrent: number | DoubleRange;
    alarmCurrnet: number | DoubleRange;
    pass: string;
    fail: string;
    count: number;
    @ViewChild("closeBtn")
    closeBtn: ElementRef;


    constructor(private cacheComponentObj: CacheComponent, private lbcServiceObj: LBCDataService, private route: Router) {
    }
  
    ngOnInit() {        
        this.getLBCData();   
        this.lbcViewDetails = this.globalInstance.getLiteral("LBC_VIEWDETAILS") ;
        this.header = this.globalInstance.getLiteral("LBC_HEADER");
        this.panelName = this.globalInstance.getLiteral("LBC_PANELNAME");
        this.status = this.globalInstance.getLiteral("LBC_STATUS");
        this.totalPanelCurrent = this.globalInstance.getLiteral("PANELTOTAL_CURRENT");
        this.loop1 = this.globalInstance.getLiteral("LBC_LOOP1");
        this.loop2 = this.globalInstance.getLiteral("LBC_LOOP2");
        this.loop3 = this.globalInstance.getLiteral("LBC_LOOP3");
        this.loop4 = this.globalInstance.getLiteral("LBC_LOOP4");
        this.lblquiscentCurrent = this.globalInstance.getLiteral("LBC_QUISCENTCURRENT");
        this.lblalarmCurrnet = this.globalInstance.getLiteral("LBC_ALARMCURRENT");
        this.pass = this.globalInstance.getLiteral("LBC_PASS");
        this.fail = this.globalInstance.getLiteral("LBC_FAIL");
        this.count = 1;
    }

    getLBCData() {
        const selectedPanelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        this.lbcServiceObj.getLBCData(selectedPanelId).then(response => this.populateLBCContent(response));
    }

    populateLBCContent(resp) {
        console.log(resp);
        this.lbcpanel = resp;     
    }

    onClose() {
        this.closeBtn.nativeElement.click();       
    }
    onLBCScreen() {        
        this.route.navigateByUrl("site/LBC");
    }
}
