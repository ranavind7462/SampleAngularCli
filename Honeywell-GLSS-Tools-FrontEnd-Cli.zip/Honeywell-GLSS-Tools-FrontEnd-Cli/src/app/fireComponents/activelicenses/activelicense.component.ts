import { Component, OnInit, ViewChild, ViewEncapsulation, ElementRef, Output, EventEmitter,Input } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Globals } from "../../shared/hooks/globals";
import { ActiveLicense} from "../../model/activeLicense";
@Component({
    selector: "activelicense-view",
    templateUrl: "./activelicense.component.html",
    styleUrls: ["./activelicense.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class ActiveLicenseComponent {
    @Output()
    editTimerDetailsEvent = new EventEmitter();


    globalInstance = Globals.getInstance();
    selectedCheckboxCount: number = 0;
    @Input() activeLicenses: ActiveLicense[]=[];
}
