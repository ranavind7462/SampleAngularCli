import { Component, OnInit, Output, ViewChild, EventEmitter, ElementRef, ViewEncapsulation } from
    "@angular/core";
import { PanelLayout, PanelModule, PanelModuleViewModel, ModuleType } from "../../model/panelmodule";
import { AddPanelModuleService } from "./addpanelmodule.service";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { ActivatedRoute } from "@angular/router";
import { Globals } from "../../shared/hooks/globals";
import { EJComponents } from "ej-angular2/src/ej/core";
import { AlertTypes } from "../../model/alertTypes";

@Component({
    selector: "addPanelModule-app",
    templateUrl: "./addpanelmodule.component.html",
    styleUrls: ["./addpanelmodule.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class AddPanelModuleComponent implements OnInit {

    @Output()
    createPanelModuleEvent = new EventEmitter();

    @Output()
    fetchPanelModuleDetails = new EventEmitter();

    @Output()
    fetchModuleFreeSlots = new EventEmitter();

    @ViewChild("closeBtn")
    closeBtn: ElementRef;

    @ViewChild("addnewmodule__modulelist")
    moduleListPopup: EJComponents<any, any>;

    //For Internaliization
    globalInstance = Globals.getInstance();
    moduleType: any = ModuleType;

    //Html elements with its properties
    popupLbl = { text: this.globalInstance.getLiteral("PANEL_MODULE_ADD"), visible: true };
    selectModuleLbl = {
        text: this.globalInstance.getLiteral("PANEL_MODULE_SLOT_LOCATION"),
        visible: true
    };
    panelModuleLbl = { text: this.globalInstance.getLiteral("PANEL_MODULE_TYPE"), visible: true };
    panelSlotsLayoutLbl = {
        text: this.globalInstance.getLiteral("PANEL_MODULE_LAYOUTS"),
        visible: true
    };
    toolTipMessage = {
        text: this.globalInstance.getLiteral("PANEL_MODULE_TOOLTIP"),
        visible: true
    };
    dlsAlertBoxProp = { message: "", visible: false, type: AlertTypes.Info };

    private panelModuleListdata: PanelModule[];

    slots = [
        { no: 1, visible: true, selected: false, used: false, disabled: true },
        { no: 2, visible: true, selected: false, used: false, disabled: true },
        { no: 3, visible: true, selected: false, used: false, disabled: true },
        { no: 4, visible: true, selected: false, used: false, disabled: true },
        { no: 5, visible: true, selected: false, used: false, disabled: true },
        { no: 6, visible: true, selected: false, used: false, disabled: true },
        { no: 7, visible: true, selected: false, used: false, disabled: true },
        { no: 8, visible: true, selected: false, used: false, disabled: true },
        { no: 9, visible: true, selected: false, used: false, disabled: true },
        { no: 10, visible: true, selected: false, used: false, disabled: true },
        { no: 11, visible: true, selected: false, used: false, disabled: true },
        { no: 12, visible: true, selected: false, used: false, disabled: true },
        { no: 13, visible: true, selected: false, used: false, disabled: true },
        { no: 14, visible: true, selected: false, used: false, disabled: true }
    ];

    private panelSlotLayoutList = [
        { no: 0, display: "6 Slots Layout" },
        { no: 8, display: "6 + 2 Slots Layout" },
        { no: 10, display: "6 + 2 + 2 Slots Layout" },
        { no: 12, display: "6 + 2 + 2 + 2 Slots Layout" },
        { no: 14, display: "6 + 2 + 2 + 2 + 2 Slots Layout" }
    ];

    currentModule: PanelModuleViewModel;
    private panelLayout: PanelLayout;
    currentPanelId: any;
    currentSelectedSlot: any;
    confirm = { text: "Add", visible: true };
    cancel = { text: "Cancel", visible: false };
    isFormDisabled = true;
    headertemplate: string;
    template: string;
    watermark = this.globalInstance.getLiteral("PANEL_MODULE_TYPE");
    panelModulefieldsvalues: Object;

    constructor(private cacheComponentObj: CacheComponent,
        private routeParams: ActivatedRoute,
        private addPanelModuleServiceObj: AddPanelModuleService) {
        this.currentModule = new PanelModuleViewModel();
        this.headertemplate = '<div class="panelmodule__dropheader--size"><span>' + this.watermark + '</span></div>';
        this.panelModulefieldsvalues = {
            dataSource: this.panelModuleListdata,
            text: "labelRows"
        };
        this.template = '<div class=""><img class="panelmodule__dropimage--pos" src="app/shared/images/zones.png"/>' +
            '<span class="panelmodule__dropitem--size"> ${labelRows} </span></div>';
    }

    // set moduleTypeNo(moduleTypeNo: any) {
    //     this.currentModule.moduleType = moduleTypeNo;
    //     this.updateFormValidation();
    //     this.fetchModuleFreeSlots.emit(moduleTypeNo);
    // }

    // get moduleTypeNo(): any { return this.currentModule.moduleType; }

    setPanelModuleList(moduleList: any) {
        this.panelModuleListdata = moduleList;
    } 

    setPanelLayout(panelLayout: any) {
        this.panelLayout.layoutId = panelLayout;
    } 

    ngOnInit() {
        this.panelLayout = new PanelLayout();
        this.fetchPanelModuleDetails.emit(this.cacheComponentObj
            .getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId));
    }

    updateFormValidation() {
        if (this.currentModule.moduleType && this.currentModule.SlotNumber) {
            this.isFormDisabled = false;
        } else {
            this.isFormDisabled = true;
        }
    }

    selectSlot(currentSlot) {
        if (currentSlot.used) {
            return;
        }

        currentSlot.selected = true;
        this.currentSelectedSlot = currentSlot;
        this.currentModule.SlotNumber = currentSlot.no;
        this.slots.filter(x => x.no !== currentSlot.no).forEach(y => y.selected = false);
        this.updateFormValidation();
    }

    panelLoyoutChanged(layoutNo) {
        this.slots.filter(x => x.no > layoutNo).forEach(y => y.selected = false);
    }

    dlsAlertBox(msg: string, type: AlertTypes) {
        this.dlsAlertBoxProp.message = msg;
        this.dlsAlertBoxProp.type = type;
        this.dlsAlertBoxProp.visible = true;
    }

    /**
    * This method is used to clear the panel details on reopening the add new panel popup.
    */
    onClose() {
        this.formCleanUp();
        this.slots.forEach(y => {
            y.selected = false;
        });
    }

    /**
     * This method emits an event as create panel to its parent component and informs
     * about new panel getting added.
     */
    createNewPanelModule(): void {
        this.currentModule.PanelId = this.cacheComponentObj
            .getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        if (!this.currentModule.moduleType) {
            this.dlsAlertBox(this.globalInstance.getLiteral("PANEL_MODULE_TYPE_ERRORMSG"), AlertTypes.Error);
            return;
        }
        if (!this.currentModule.SlotNumber) {
            this.dlsAlertBox(this.globalInstance.getLiteral("PANEL_MODULE_ERRORMSG"), AlertTypes.Error);
            return;
        }
        this.createPanelModuleEvent.emit(JSON.stringify(this.currentModule));
        this.closeBtn.nativeElement.click();
    }

    formCleanUp() {
        this.currentModule = new PanelModuleViewModel();
        this.updateFormValidation();
        this.slots.forEach(y => {
            y.selected = false;
            y.used = false;
        });
    }

    validateSlotAvailability(moduleList: any) {
        this.formCleanUp();
        if (moduleList) {
            for (let i = 0; i < moduleList.length; i++) {
                this.slots.filter(x => x.no === moduleList[i].slotNumber)[0].used = true;
            }
            if (moduleList.length >= this.panelLayout.layoutId) {
                this.dlsAlertBox(this.globalInstance.getLiteral("PANEL_MODULE_NO_EMPTY_ABAILABLE_SLOT_MSG"),
                    AlertTypes.Error);
                return;
            }
        }
        this.dlsAlertBoxProp.visible = false;
    }

    onopen(args) {
        const ddlobj = this.moduleListPopup.widget.element.ejDropDownList("instance");
        ddlobj.popupListWrapper.offset({ top: ddlobj.popupListWrapper.offset().top - ddlobj.wrapper.height() - 3 });
    }

    onModuleValueChange(panelModule){
        if(panelModule.isInteraction){
            this.currentModule.moduleType = panelModule.selectedValue;
            this.fetchModuleFreeSlots.emit(panelModule);
        }
        //console.log('panel module change');
    }

    getFreeSlots(freeSlots) {
        this.slots.forEach(y => {
            y.disabled = true;
        });

        if (freeSlots.length > 0) {            
            for(var i = 0; i < freeSlots.length; i++){
                this.slots.filter(x => x.no === freeSlots[i]).forEach(y => y.disabled = false);
            }
        }
    }
}
