import { Injectable } from "@angular/core";
import { Headers, Http } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { PanelLayout } from "../../model/panelmodule";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from "../../shared/hooks/config";

@Injectable()
export class AddPanelModuleService {

    constructor(private http: Http,
        private serviceUrlObj: ServiceUrl,
        private configObj: Config,
        private errorHandlerObj: MyErrorHandler) {
        this.serviceUrlObj = new ServiceUrl(this.configObj);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching the current panel Module layout based on the
     * panel id passed.
     */
    getPanelModuleLayout(panelId: any): Promise<PanelLayout> {
        let postPanelUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Panel) + "/" + panelId.replace(/"/g, "");
        postPanelUrl = "https://api.myjson.com/bins/j1lfz";
        return this.http
            .get(postPanelUrl)
            .toPromise().then(function(response) {
                    const data = response.json();
                    return data; // Change it on integration with proper API.
                },
                function(response) {

                }).catch(this.errorHandlerObj.handleServerError);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching the current panel Module list based on the
     * panel id passed.
     */
    getPanelModuleList(panelId: any): Promise<PanelLayout> {
        let postPanelUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Panel) + "/" + panelId.replace(/"/g, "");
        postPanelUrl = "https://api.myjson.com/bins/1gcmkf";
        return this.http
            .get(postPanelUrl)
            .toPromise().then(function(response) {
                    const data = response.json();
                    return data; // Change it on integration with proper API.
                },
                function(response) {

                }).catch(this.errorHandlerObj.handleServerError);
    }
}