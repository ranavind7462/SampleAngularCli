import { Component, OnInit } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { PanelService } from "../../baseComponents/panel/panel.service";
import { Globals } from "../../shared/hooks/globals";
import { ModuleType } from "../../model/panelmodule";

@Component({
    selector: "panelconfiggraphical-app",
    templateUrl: "./panelconfiggraphical.component.html",
    styleUrls: ["./panelconfiggraphical.component.css"]
})
export class PanelConfigGraphicalComponent implements OnInit {

    //For Internationalization
    globalInstance = Globals.getInstance();

    constructor(private cacheComponentObj: CacheComponent, private panelServiceObj: PanelService) {
    }

    ngOnInit() {
        this.loadAllModules(this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId));
    }

    panelSlotsContainer = [];

    loadAllModules(panelId: any) {
        this.panelServiceObj
            .getModuleList(panelId)
            .then(response => this.populateAllModules(response));
    }

    populateAllModules(moduleList: any) {
        if (moduleList) {
            if (moduleList.length > 0) {
                moduleList.sort((b, a) => (a.slotNumber > b.slotNumber) ? 1 : ((b.slotNumber > a.slotNumber) ? -1 : 0));
                this.loadModuleWithSlot(moduleList[0].slotNumber, moduleList);
            }
        } else {
            this.loadModuleWithSlot(6, []);
        }
    }

    /**
     * This method will update the layout based on dropdown value selcted and also based saved layout.
     * @param layoutType : no of slots for this layout
     */
    loadModuleWithSlot(noOfSlots, moduleList: any) {
        this.panelSlotsContainer = [];
        const containerOf6Slots = [];
        //default selection will show layout of 6 slots
        for (let j = 1; j <= 6; j++) {
            const foundModule = moduleList.filter(x => x.slotNumber === j)[0];
            if (foundModule)
                containerOf6Slots.push({
                    isFilled: true,
                    id: foundModule.id,
                    slotNumber: j,
                    label: ModuleType[foundModule.moduleType],
                    image: "app/shared/images/zones.png"
                });
            else
                containerOf6Slots
                    .push({
                        isFilled: false,
                        id: j,
                        slotNumber: j,
                        moduleType: -1,
                        image:
                            "app/shared/images/add.png"
                    });
        }
        this.panelSlotsContainer.push({ slotType: 6, slots: containerOf6Slots });
        if (noOfSlots > 6) {
            noOfSlots = noOfSlots - 6;
            if (noOfSlots % 2 !== 0)
                noOfSlots = noOfSlots + 1;
            noOfSlots = noOfSlots / 2;

            let slotNo = 7;
            for (let i = 0; i < noOfSlots; i++) {
                const containerOf2Slots = [];
                for (let j = 0; j < 2; j++) {
                    const foundModule = moduleList.filter(x => x.slotNumber === slotNo)[0];
                    if (foundModule)
                        containerOf2Slots.push({
                            isFilled: true,
                            id: foundModule.id,
                            slotNumber: slotNo,
                            label: ModuleType[foundModule.moduleType],
                            image: "app/shared/images/zones.png"
                        });
                    else
                        containerOf2Slots.push({
                            isFilled: false,
                            id: slotNo,
                            slotNumber: slotNo,
                            moduleType: -1,
                            image: "app/shared/images/add.png"
                        });
                    slotNo++;
                }
                this.panelSlotsContainer.push({ slotType: 2, slots: containerOf2Slots });
            }
        }
    }
}
