import { Component, OnInit, Input, Output, EventEmitter,ViewEncapsulation } from "@angular/core";

@Component({
    selector: "siteDetail-app",
    templateUrl: "./site-detail.component.html",
    styleUrls: ["./site-detail.component.css"],
    encapsulation:ViewEncapsulation.None
})
export class SiteDetailComponent {
    //Events emitted to the parent consumer.
    @Output()
    siteDetailsEvent = new EventEmitter();

    @Output()
    siteOptionsEvent = new EventEmitter();

    @Input()
    index: any;

    @Output()
    editSiteEvent = new EventEmitter();

    //Html elements with its properties
    
    buildingName = { text: "", visible: true };
    lastUpdatedOn = { text: "", visible: true };
    faultList = { text: "", visible: true };
    panelCount = { text: "", visible: true };
    buildingAddress = { text: "- Add Address Details", visible: true };
    projectId = { text: "3452", visible: true };

    referenceNo = { text: "Site type:", visible: true };

    constructor() {}

    //TODO Methods
    getSiteDetails(): void {
        //TODO
    }

    ngOnInit() {
        this.siteDetailsEvent.emit();
    }

     /**
     * This method emits the site options event to sitecart component to display the popover.
     */
    displaySiteOptions() {
        this.siteOptionsEvent.emit();
    }

    openEditView() {
        this.editSiteEvent.emit();
    }

    
}
