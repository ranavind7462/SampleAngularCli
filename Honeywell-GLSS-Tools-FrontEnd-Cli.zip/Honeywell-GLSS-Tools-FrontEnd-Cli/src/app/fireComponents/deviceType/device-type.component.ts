import { Component, OnInit, Input,Output, ViewChild, EventEmitter, ElementRef } from "@angular/core";
import { Globals } from "../../shared/hooks/globals";
import { AddDevices } from "../../model/addDevices";
import { FormControl } from '@angular/forms';
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";


@Component({
    selector: "deviceType-app",
    templateUrl: "./device-type.component.html",
    styleUrls: ["./device-type.component.css"]
})
export class DeviceTypeComponent {

    @Input() selectedType: number;

    @Input() TypesList: any;

    @Output()
    updateDeviceTypeEvent = new EventEmitter();

    @ViewChild("closeBtn")
    closeBtn: ElementRef;

    isAddBtnDisabled = true;

    //For Internaliization
    globalInstance = Globals.getInstance();

    popupLbl = { text: this.globalInstance.getLiteral("CHANGE_DEVICE_TYPE"), visible: true };
   
    //footer
    changeButtonText = { text: this.globalInstance.getLiteral("COMMON_CHANGE"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };

    currentType: number;

    constructor(private cacheComponentObj: CacheComponent) {
       
    }

    ngOnDestroy() {
        console.log("destroying");
    }

    ngOnInit()
    {
        this.currentType = this.selectedType;
    }

    ngOnChanges()
    {    
        this.currentType = this.selectedType;
    }

    onSelectionChange(deviceType: number)
    {
        this.currentType = deviceType;
    }
    /**
     * This method emits an event to its parent component and informs
     * about new new device type is selected.
     */
    updateDevices(): void {
        this.updateDeviceTypeEvent.emit(this.currentType);
        this.closeBtn.nativeElement.click();       
    }
    
    /**
    * This method is used to open the device type popup.
    */
    onOpen() {
        
    }

    /**
    * This method is used to clear the device type details on reopening the device type popup.
    */
    onClose() {
        this.currentType = -1;
    }
}
