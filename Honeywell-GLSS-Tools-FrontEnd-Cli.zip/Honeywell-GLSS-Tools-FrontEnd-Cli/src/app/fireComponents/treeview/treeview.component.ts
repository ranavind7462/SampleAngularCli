import { Component, Input, Output, EventEmitter,ViewEncapsulation } from "@angular/core";
import { TreeNode } from "../../model/treeNode";
import { Loop } from "../../model/loop";



@Component({
    selector: "tree-view-app",
    templateUrl: "./treeview.component.html",
    styleUrls: ["./treeview.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class TreeViewComponent {

    @Output()
    nodeClickedEvent = new EventEmitter<TreeNode>();
    @Output()
    loopClickEvent = new EventEmitter<Loop>();

    @Input()
    root;
    @Input()
    selectedNode: any;
    selectedLoop: Loop;

    nodeClicked(treeNode: TreeNode): any {
        this.selectedNode = treeNode;
        treeNode.expand();
        this.nodeClickedEvent.emit(treeNode);
    }
    createRange(number) {
        var items: Loop[] = [];
        for (var i = 0; i <number; i++) {
            var loop = new Loop;
            loop.loopDescription = "0" + (i + 1) + " Loop (00)";
            items.push(loop);
        }
        return items;
    }
    selectLoop(loop: Loop):any
    {
        this.selectedNode = loop;
      //  this.selectedLoop = loop;
        this.loopClickEvent.emit(loop);

    }
}
