import { Component, OnInit, Output, ViewChild, EventEmitter, ElementRef} from "@angular/core";
import { Zone } from "../../model/zone";
import { Globals } from "../../shared/hooks/globals";
import { ZoneService } from "../../baseComponents/zone/zone.service";

@Component({
    selector: "addNewZone-app",
    templateUrl: "./add-new-zone.component.html",
    styleUrls: ["./add-new-zone.component.css"]
})
export class AddNewZoneComponent implements OnInit {

    @Output()
    newZoneAddEvent = new EventEmitter();

    @Output()
    cancelZoneAddEvent = new EventEmitter();

    @ViewChild('zoneAddForm') form;
    @ViewChild("closeBtn")
    closeBtn: ElementRef;

    //For Internaliization
    globalInstance = Globals.getInstance();

    isDuplicate: boolean = false;
    isZoneNoRange: boolean = true;
    isZoneMaxReached: boolean = false;

    //Html elements with its properties
    popupTitle = { text: this.globalInstance.getLiteral("ZONE_ADD_ZONE"), visible: true };
    create = { text: this.globalInstance.getLiteral("COMMON_CREATE"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };
    zoneNumber = { text: this.globalInstance.getLiteral("ZONE_ZONE_NO"), visible: true };
    zoneDescription = { text: this.globalInstance.getLiteral("ZONE_ZONE_DESCRIPTION"), visible: true };
    rangeErrMsg = { text: this.globalInstance.getLiteral("ZONE_RANGE_ERR_MSG"), visible: true };
    zoneExistMsg = { text: this.globalInstance.getLiteral("ZONE_EXIST_ERR_MSG"), visible: true }; 
    zoneMaxReachedMsg = { text: this.globalInstance.getLiteral("ZONE_MAX_REACHED_ERR_MSG"), visible: true };
       
    addZone: Zone;

    constructor(private zoneServiceObj: ZoneService)
    {    
    }

    loadZone(zone: Zone): any
    {
        this.addZone = zone;

        if (this.addZone != null)
        {
            this.addZone.zoneNumberDisplay = this.globalInstance.getSingleZoneNumberDisplay(this.addZone.zoneNumber);
        }
    }

    dataByZoneId(zoneId: any): any
    {
        this.zoneServiceObj
            .getZone(zoneId)
            .then(response => this.loadZone(response));
    }

    ngOnInit()
    {
        this.addZone = new Zone();  
    }

    /**
     * This method is used to open the add new site popup.
     */
    onOpen()
    {
        this.addZone = new Zone();
    }

    /**
    * This method is used to clear the customer site details on reopening the add new site ite popup.
    */
    onClose()
    {
        this.addZone = new Zone();
        this.isDuplicate = false;
        this.isZoneNoRange = true;
        this.closeBtn.nativeElement.click();
        this.cancelZoneAddEvent.emit();

    }
    ngOnDestroy() {
        console.log("destroying");
    }
    /**
     * This method emits an event as create site to its parent component and informs
     * about new site getting added.
     */
    createZone(): void
    {
        this.newZoneAddEvent.emit(this.addZone);
    }

    onlyNumberKey(event)
    {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    validateRange(val: any)
    {
        //if (!val)
        //{
            this.isDuplicate = false;
            this.isZoneNoRange = true;
        //}
        let min: number = 2;//(this.zoneEditDisabled ? 1 : 2);    

        if (val > 199 || val < min)
        {
            this.isZoneNoRange = false;
        }
        else
        {
            this.isZoneNoRange = true;
        }
    }

}
