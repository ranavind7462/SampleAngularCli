import { Component, OnInit, ViewChild, ViewEncapsulation, ElementRef, Output, EventEmitter } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { TimerService } from "../../fireComponents/Timer/timer.service";
import { Timer } from "../../model/timer";
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";
import { Globals } from "../../shared/hooks/globals";
import { TimerComponent } from "../../fireComponents/Timer/timer.component";
import { EJComponents } from "ej-angular2";

//Testing
@Component({
    selector: "timer-view",
    templateUrl: "./timerview.component.html",
    styleUrls: ["./timerview.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class TimerViewComponent implements OnInit {
    @ViewChild("gridTimer") grid: EJComponents<any, any>;
    @Output()
    editTimerDetailsEvent = new EventEmitter();
    scrollSettings = { height: "200px", width: "auto", allowVirtualScrolling: false, autoHide: true, enableColumnScrolling: true };
    @Output()
    TimerCountEvent = new EventEmitter();

    globalInstance = Globals.getInstance();
    selectedCheckboxCount: number = 0;
    timers: Timer[];
    rowsSelected = false;
    customAttributes = { "disabled": "true" };
    delete = { text: this.globalInstance.getLiteral("COMMON_DELETE"), visible: true };
    montofri = { text: this.globalInstance.getLiteral("TIMER_REPEAT_MODE_MONTOFRI"), visible: true };
    weekly = { text: this.globalInstance.getLiteral("TIMER_REPEAT_MODE_WEEKLY"), visible: true };
    timerSel = { text: this.globalInstance.getLiteral("TIMER_SELECTED"), visible: true };

    constructor(private cacheComponentObj: CacheComponent,
         private timerServiceObj: TimerService) {
    }

    ngOnInit() {
        this.getTimers();
    }

    getTimers() {
        const selectedPanelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        this.timerServiceObj
            .getTimerSrvc(selectedPanelId)
            .then(response => this.populateTimerContent(response));
    }
 
    populateTimerContent(resp)
    {
        if (resp) {
            this.timers = resp;
            this.selectedCheckboxCount = 0;
            this.enableDisableFooterActions();
            this.TimerCountEvent.emit(this.timers.length);
        }
        else
        {
            this.TimerCountEvent.emit(0);
            this.timers = null;
            this.selectedCheckboxCount = 0;
        }
    }
   selectedAll:boolean=false
    selectAll()
    {
        for (var i = 0; i < this.timers.length; i++) {
            this.timers[i].isSelected = this.selectedAll;
        }
        this.selectedCheckboxCount = this.timers.filter(i => i.isSelected == true).length;
   }
    checkIfAllSelected() {
        this.selectedAll = this.timers.every(function (item: any) {
            return item.isSelected == true;
        })
        this.selectedCheckboxCount = this.timers.filter(i => i.isSelected == true).length;
    }

    openEditView(currentTimer: Timer) {
        this.editTimerDetailsEvent.emit(currentTimer);
    }

    @ViewChild(DeletePopupComponent)
    deletepopupComponentObj: DeletePopupComponent;

    deleteTimer() {

        var keys: any[] = [];
        this.timers.filter(i => i.isSelected == true).map(j => { keys.push(j.id) });
        var repeatDays:string = "";
        this.deletepopupComponentObj.popupLabel.text = this.globalInstance.getLiteral("DELETE_TIMER_LABEL");

        if (keys.length == 1) {
            this.deletepopupComponentObj.deletemsg.text = this.globalInstance.getLiteral("DELETE_TIMER_CONFIRMATION_MESSAGE");
            if (this.timers.filter(i => i.isSelected == true)[0].repeatMode == 2) {
                repeatDays = this.weekly.text;
            }
            else if (this.timers.filter(i => i.isSelected == true)[0].repeatMode == 3) {
                repeatDays = this.montofri.text;
            }
            else {
                repeatDays = this.timers.filter(i => i.isSelected == true)[0].repeatDays;
            }

            //this.deletepopupComponentObj.currentDeleteObj.label = "";
            this.deletepopupComponentObj.currentDeleteObj.desc = this.timers.filter(i => i.isSelected == true)[0].startTime + " to " + this.timers.filter(i => i.isSelected == true)[0].endTime + "     |     " + repeatDays;
        }
        else
        {
            this.deletepopupComponentObj.deletemsg.text = this.globalInstance.getLiteral("DELETE_MUL_TIMER_CONFIRMATION_MSG").replace("{0}", keys.length);
            this.deletepopupComponentObj.description.visible = true;
        }

        this.deletepopupComponentObj.confirmationMsg.text = "";
        this.deletepopupComponentObj.currentDeleteObj.id = "Timer";
        this.deletepopupComponentObj.lastUpdated.visible = false;
        this.deletepopupComponentObj.enterPassword.visible = false;
        this.deletepopupComponentObj.deleteFiles.visible = false;
        this.deletepopupComponentObj.confirmationMsg.visible = false;
        this.deletepopupComponentObj.projId.visible = false;
        this.deletepopupComponentObj.showDeleteicon = false;
        this.deletepopupComponentObj.lastUpdated.text = "";

    }


    deleteTimerData() {
        var keys: any[]=[];
        this.timers.filter(i => i.isSelected == true).map(j => { keys.push(j.id) });
       
        this.timerServiceObj.deleteTimerSrvc(keys).then(
          response => {
              if (response.ok) {

                  this.getTimers();
                 
              }
         },
         error => {
           console.log(error);
            }
        );
    }
    onRowSelected(e: any) {
        var selectedRecords: Object[] = this.grid.widget.getSelectedRecords();
        this.setSelectedRowsCount(selectedRecords.length, e, true);
        this.selectedCheckboxCount = selectedRecords.length;
        this.enableDisableFooterActions();       
    }
    onRowDeselected(e: any) {
        var selectedRecords: Object[] = this.grid.widget.getSelectedRecords();
        this.setSelectedRowsCount(selectedRecords.length, e, false);
        this.selectedCheckboxCount = selectedRecords.length;        
        this.enableDisableFooterActions();       
    }
    enableDisableFooterActions() {
        debugger;
        if (this.timers && this.timers.length > 0) {
            if (this.selectedCheckboxCount > 0) {
                this.rowsSelected = true;                
            }
            else
                this.rowsSelected = false;
        }
    }
    setSelectedRowsCount(count: number, e: any, selected: boolean) {

        if (this.timers.length == count) {
            this.timers.forEach(res => {
                res.isSelected = selected;
            });
        }
        else if (count == 0) {
            this.timers.forEach(res => {
                res.isSelected = selected;
            });
        }
        else {
            this.timers.filter(i => i.id == e.row["0"].cells["1"].innerHTML).map(res => {
                res.isSelected = selected;
            });
        }
    }
}
