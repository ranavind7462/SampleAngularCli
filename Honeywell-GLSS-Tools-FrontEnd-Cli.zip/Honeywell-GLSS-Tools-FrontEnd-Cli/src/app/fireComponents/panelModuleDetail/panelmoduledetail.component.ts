import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from "@angular/core";
import { Router } from "@angular/router";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { PanelService } from "../../baseComponents/panel/panel.service";
import { DeletePopupComponent } from "../deletePopup/delete-popup.component";
import { Panel, PanelContentView } from "../../model/panel";
import { PanelModuleViewModel, ModuleType } from "../../model/panelmodule";
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "panelmoduledetail-app",
    templateUrl: "./panelmoduledetail.component.html",
    styleUrls: ["./panelmoduledetail.component.css"]
})
export class PanelModuleDetailComponent {

    @Output()
    deleteModuleEvent = new EventEmitter();

    @Output()
    deletePanelModuleEvent = new EventEmitter();

    @ViewChild(DeletePopupComponent)
    deletepopupComponentObj: DeletePopupComponent;

    //For Internationalization
    globalInstance = Globals.getInstance();

    moduleType: any = ModuleType;

    edit = { text: this.globalInstance.getLiteral("COMMON_EDIT"), visible: true };
    delete = { text: this.globalInstance.getLiteral("COMMON_DELETE"), visible: true };
    confirm = { text: this.globalInstance.getLiteral("COMMON_SAVE"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: false };

    editMode = false;
    moduleName = "Input-Output Module";
    panelLabel = "Abc";
    private layoutType: any = "06";
    layoutLabel = this.layoutType + " " +this.globalInstance.getLiteral("PANEL_SLOT_LAYOUT");

    currentModule: PanelModuleViewModel;
    parentDivs = [];
    oldParentDivs = [];
    availableSlots = [];
    blockedSlots = [];
    configuredSlot;
    updatedSlotNumber;

    constructor(private panelServiceObj: PanelService, private cacheComponentObj: CacheComponent) {
        this.currentModule = new PanelModuleViewModel();
    }

    setPanelLayoutType(layoutType: any) {
        this.layoutType = layoutType;
    }

    /**
     * Create the Panel slot layout for the selected panel module
     * @param cardLayoutInfo - Slot layout info
     */
    createCardLayout(cardLayoutInfo: any) {
        let layout = this.layoutType;
        let layoutArray = layout.split("+");
        let cards = [];
        //let configuredSlot = cardLayoutInfo.slotNumber;
        //let blockedSlots = [];
        //let availableSlots = [];
        let slotCount = 0;
        let highlightCard = false;
        let blockCard = false;
        let availableCard = false;
        this.parentDivs = [];

        this.configuredSlot = cardLayoutInfo.slotNumber;
        this.moduleName = this.moduleType[cardLayoutInfo.moduleType];
        this.getBlockedSlots(this.configuredSlot);

        for (let i = 0; i < layoutArray.length; i++) {
            if (layoutArray[i] === "6") {
                for (let j = 0; j < parseInt(layoutArray[i]); j++) {
                    slotCount += 1;
                    highlightCard = ((slotCount === this.configuredSlot) ? true : false);

                    for (let k = 0; k < this.blockedSlots.length; k++) {
                        blockCard = false;
                        if (slotCount === this.blockedSlots[k]) {
                            blockCard = true;
                            break;
                        }
                    }

                    for (let l = 0; l < this.availableSlots.length; l++) {
                        availableCard = false;
                        if (slotCount === this.availableSlots[l]) {
                            availableCard = true;
                            break;
                        }
                    }
                    cards.push({ id: slotCount, configured: highlightCard, blocked: blockCard, available: availableCard });
                }
                this.parentDivs.push({ id: cards });
                cards = [];
            } else if (layoutArray[i] === "2") {
                for (let j = 0; j < parseInt(layoutArray[i]); j++) {
                    slotCount += 1;
                    highlightCard = ((slotCount === this.configuredSlot) ? true : false);
                    cards.push({ id: slotCount, configured: highlightCard, blocked: false, available: availableCard });
                }
                this.parentDivs.push({ id: cards });
                cards = [];
            }
        }
    }

    /**
     * Prepare the blocked slots array using available slots and configured slot
     * @param configuredSlot - Slot configured for the selected panel module
     */
    getBlockedSlots(configuredSlot){
        this.blockedSlots = [];
        let layout = this.layoutType;
        let layoutArray = layout.split("+");
        let slotCount = 0;
        let checkBlocked = false;

        for (let i = 0; i < layoutArray.length; i++) {
            if (layoutArray[i] === "6") {
                for (let j = 0; j < parseInt(layoutArray[i]); j++) {
                    slotCount += 1;
                    checkBlocked = false;
                    /*Check if slot is present in available slots */
                    for (let k = 0; k < this.availableSlots.length; k++) {
                        if(slotCount === this.availableSlots[k]){
                            checkBlocked = true;
                            break;
                        }
                    }
                    /* if slot not in available slots and also not configured for the selected module, add to blocked slots */
                    if(!checkBlocked && slotCount !== configuredSlot){
                        this.blockedSlots.push(slotCount);
                    }
                }
            }
            else if (layoutArray[i] === "2") {
                for (let j = 0; j < parseInt(layoutArray[i]); j++) {
                    slotCount += 1;
                    checkBlocked = false;
                    /*Check if slot is present in available slots */
                    for (let k = 0; k < this.availableSlots.length; k++) {
                        if(slotCount === this.availableSlots[k]){
                            checkBlocked = true;
                            break;
                        }
                    }
                    /* if slot not in available slots and also not configured for the selected module, add to blocked slots*/
                    if(!checkBlocked && slotCount !== configuredSlot){
                        this.blockedSlots.push(slotCount);
                    }
                }
            }
        }
    }

    /**
     * Enable edit mode (Make slot layout editable)
     */
    enableEditMode(){
        this.editMode = true;
    }

    /**
     * Assign the slot for panel module in edit mode
     * @param slotNumber - Newly selected slot number in edit mode
     */
    asignSlot(slotNumber) {
        
        /*If edit mode is true and available slot number is selected, highlight the selected slot*/
        if(this.editMode && !this.blockedSlots.includes(slotNumber)){
            for (let i = 0; i < this.parentDivs.length; i++) {
                for (let j = 0; j < this.parentDivs[i].id.length; j++) {
                    if(slotNumber === this.parentDivs[i].id[j].id){
                        this.parentDivs[i].id[j].configured = true;
                        this.parentDivs[i].id[j].available = false;
                    }
                    else{
                        if(this.parentDivs[i].id[j].configured){
                            this.parentDivs[i].id[j].available = true;
                        }
                        this.parentDivs[i].id[j].configured = false;
                    }
                }
            }
            this.updatedSlotNumber = slotNumber;
        }
        
    }

    /**
     * Delete panel module
     */
    deletePanelModule() {
        this.deleteModuleEvent.emit();
    }

    /**
     * Save the changes done to Panel module
     */
    saveModuleData(){
        
        this.currentModule.PanelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        this.currentModule.Id = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedModuleId);
        this.currentModule.moduleType = this.moduleType[this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedModuleName)];
        this.currentModule.SlotNumber = this.updatedSlotNumber ? this.updatedSlotNumber : this.configuredSlot;

        this.panelServiceObj.updatePanelModuleSrvc(JSON.stringify(this.currentModule)).then(
            response => {
                var data = response;
            },
            error => {
                console.log(error);
            }
        );

        this.currentModule = new PanelModuleViewModel();
        this.editMode = false;
    }

    /**
     * Hide the footer of panel edit mode on cancel click and restore the slot layout to original if any changes were made
     */
    hideFooter(){

        /*Restores the slot layout to original form if any changes were made */
        this.asignSlot(this.configuredSlot);
        this.currentModule = new PanelModuleViewModel();
        this.editMode = false;
    }
}
