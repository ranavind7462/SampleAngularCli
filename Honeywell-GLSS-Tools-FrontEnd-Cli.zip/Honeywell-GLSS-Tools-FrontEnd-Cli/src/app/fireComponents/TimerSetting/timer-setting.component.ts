import { Input, Component, ViewChild, HostListener, Output, EventEmitter, OnInit, DoCheck }  from '@angular/core';
import { Globals } from "../../shared/hooks/globals";
import { TimerComponent } from "../../fireComponents/Timer/timer.component";
import { Panel } from "../../model/panel";
import { Timer } from "../../model/timer";
import { PanelService } from "../../baseComponents/panel/panel.service";

@Component({
    selector: "timerSetting-app",
    templateUrl: "./timer-setting.component.html",
    styleUrls: ["./timer-setting.component.css"]
})
export class TimerSettingComponent 
{
    @ViewChild(TimerComponent)
    timerModal: TimerComponent;
    @Input() currentSetting: Panel;
    @Output() timerSettingSaveClick = new EventEmitter<Panel>();
    //@Output() onAddTimerClick = new EventEmitter();
    showDetectionMode: boolean = false;
    detectionModemaxSec: number = 60;
    limitexceeded: boolean = true;
    errormsg:string="nothing"
    isEdit = false;
    constructor(private panelServiceObj: PanelService)
    {
        
    }
    checkNoOfDetectionMode()
    {
        this.limitexceeded = true;
        if (this.panelSetting.detectionMode > 14) {
            this.limitexceeded = false;
        }
   }
    panelSetting: Panel;
    ngOnChanges() {
        this.panelSetting = Object.assign({}, this.currentSetting);
        debugger;
        this.checkNoOfDetectionMode();
    }
   
    //For Globalization
    globalInstance = Globals.getInstance();

    //Html elements with its properties
    dateFormat = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_DATE_FORMAT"), visible: true };
    acessTimeout = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_ACESS_TIMEOUT"), visible: false };
    mins = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_MINS"), visible: true };
    inhibitTimeout = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_INHIBIT_TIMEOUT"), visible: true };
    sec = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SEC"), visible: true };
    timerDetectionMode = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_TIMER_DETECTION_MODE"), visible: true };
    detectionMode = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_DETECTION_MODE"), visible: true };
    newTimer = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_NEW_TIMER"), visible: true };

    nextServiceDateErrMsg = { text: this.globalInstance.getLiteral("PANEL_SETTING_NEXT_SERVICE_DATE_ERR_MSG"), visible: true };
    acessTimeoutErrMsg = { text: this.globalInstance.getLiteral("PANEL_SETTING_ACESS_TIMEOUT_ERR_MSG"), visible: true };
    inhibitTimeoutErrMsg = { text: this.globalInstance.getLiteral("PANEL_SETTING_INHIBIT_TIMEOUT_ERR_MSG"), visible: true };
    save = { text: this.globalInstance.getLiteral("COMMON_SAVE"), visible: true };

    @Output() onPanelClick = new EventEmitter<Panel>();


    private dateFormats = [
        { value: 0, text: "DD-MM-YYYY" },
        { value: 1, text: "MM-DD-YYYY" }
    ];

    private Stages = [
        { value: 0, text: "Alert / Alarm" },
        { value: 1, text: "Alarm / Alert" }
    ];

    private DetectionModes = [
        { value: 0, text: "No Action" },
        { value: 1, text: "Sensitivity" },
        { value: 2, text: "Delayed" },
        { value: 3, text: "Verification" }
    ];
    validateRange(obj: any) {
        switch (obj.name) {
            case "accessTimeout":
                if (obj.value > 60 || obj.value < 1)
                    this.panelSetting.accessTimeout = null;
                break;

            case "inhibitTimeout":
                if (obj.value > 180 || obj.value < 0)
                    this.panelSetting.inhibitTimeout = null;
                break;

            case "noOfRepeaters":
                if (obj.value > 16 || obj.value < 0)
                    this.panelSetting.numberOfRepeater = null;
                break;

            case "defaultSounderMode":
                if (obj.value > 32 || obj.value < 1)
                    this.panelSetting.defaultSounderMode = null;
                break;


            case "nextServiceDate":
                if (isNaN(new Date(obj.value).valueOf()))
                    this.panelSetting.nextServiceDate = null;
                break;

        }
    }

    detectionmodechanges(value: any) {
        console.log("detectionmodevalue : "+value);
        this.showDetectionMode = (value == 2 ||value==3) ? true : false;
        this.detectionModemaxSec = value == 2 ? 120 : 60
    }

    ///*Timer code */
    //addTimer(): void {
    //    this.onAddTimerClick.emit();

    //}

    buttonClick(clickType: string) {
        this.panelServiceObj.editPanelSrvc(this.panelSetting);
        this.currentSetting = this.panelSetting;
        this.timerSettingSaveClick.emit(this.panelSetting);
        this.isEdit = false;
    }

    getPanelSetting(panelId: any): any
    {
        this.panelServiceObj
            .getPanel(panelId)
            .then(response => this.populateSettingContent(response));
    }

    populateSettingContent(resp): any
    {
        this.panelSetting.label = resp.label;
        this.panelSetting.protocol = resp.protocol;
        this.panelSetting.phoneNo = resp.phoneNo;
        this.panelSetting.nextServiceDate = resp.nextServiceDate;
        this.panelSetting.isBlinking = resp.isBlinking;
        this.panelSetting.isIOCardFitted = resp.isIOCardFitted;
        this.panelSetting.isFatFbeFitted = resp.isFatFbeFitted;
        this.panelSetting.ioSounderId = resp.ioSounderId;
        this.panelSetting.softwareVer = resp.softwareVer;
        this.panelSetting.language = resp.language;
        this.panelSetting.dateFormat = resp.dateFormat;
        this.panelSetting.accessTimeout = resp.accessTimeout;
        this.panelSetting.inhibitTimeout = resp.inhibitTimeout;
        this.panelSetting.numberOfRepeater = resp.numberOfRepeater;
        this.panelSetting.isLogDiagnostic = resp.isLogDiagnostic;
        this.panelSetting.isAutoResound = resp.isAutoResound;
        this.panelSetting.isExtendedPSUFitted = resp.isExtendedPSUFitted;
        this.panelSetting.isSounderDisable = resp.isSounderDisable;
        this.panelSetting.defaultSounderMode = resp.defaultSounderMode;
        this.panelSetting.stage = resp.stage;
        this.panelSetting.detectionMode = resp.detectionMode;
    }
    enableEdit(isEnable: boolean) {
       this.isEdit = isEnable;
    }

    onlyNumberKey(event:any) {
        //console.log(event.name);
        if (this.panelSetting.detectionMode == 2)
        {
            let totalDelay = this.panelSetting.delayT1 + this.panelSetting.delayT2
            console.log(totalDelay);
            if (event.name == "DelayT1") {
                if (this.panelSetting.delayT1 > 600) {
                    this.panelSetting.delayT1 = 600;
                    this.panelSetting.delayT2 = 0;
                }
                else {
                   
                    if (totalDelay>600)
                    {
                        this.panelSetting.delayT2 = 600 - this.panelSetting.delayT1;
                    }
                }
            }
            if (event.name == "DelayT2") {
                if (this.panelSetting.delayT2 > 600) {
                    this.panelSetting.delayT2 = 600;
                    this.panelSetting.delayT1 = 0;
                }
                else {
                    if (totalDelay > 600) {
                        this.panelSetting.delayT1 = 600 - this.panelSetting.delayT2;
                    }
                }
            }
        }
        if (this.panelSetting.detectionMode == 3) {
            if (this.panelSetting.verificationT2 > 60)
            {
                this.panelSetting.verificationT2 = 60;
            }
            if (this.panelSetting.verificationT1 > 60) {
                this.panelSetting.verificationT1 = 60;
            }
        }
        return this.panelSetting;
       //
        // console.log(this.secValue);
    }
}
