import { Component, OnInit, ViewChild, ViewEncapsulation, ElementRef, Output, EventEmitter,Input } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Globals } from "../../shared/hooks/globals";
import { LicenseHistory} from "../../model/licensesHistory"
@Component({
    selector: "licensehistory-view",
    templateUrl: "./licensehistory.component.html",
    styleUrls: ["./licensehistory.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class LicenseHistoryComponent {
    @Output()
    editTimerDetailsEvent = new EventEmitter();


    globalInstance = Globals.getInstance();
    selectedCheckboxCount: number = 0;
    @Input() licensesHistory: LicenseHistory[]=[];
}
