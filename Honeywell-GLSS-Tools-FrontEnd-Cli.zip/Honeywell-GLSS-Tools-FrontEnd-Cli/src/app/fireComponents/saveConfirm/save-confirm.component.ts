import { Component, EventEmitter, Output } from '@angular/core';
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "saveConfirm-app",
    templateUrl: "./save-confirm.component.html",
    styleUrls: ["./save-confirm.component.css"]
})
export class SaveConfirmComponent
{
    @Output() onButtonClick = new EventEmitter<string>();
    buttonClick(clickType: string)
    {
        this.onButtonClick.emit(clickType);
    }

    //For Globaliization
    globalInstance = Globals.getInstance();

    headerText = { text: this.globalInstance.getLiteral("PANEL_SETTING_SAVE_HEADER"), visible: true };
    confirmMsg1Text = { text: this.globalInstance.getLiteral("PANEL_SETTING_SAVE_CONFIRM_MSG1"), visible: true };
    confirmMsg2Text = { text: this.globalInstance.getLiteral("PANEL_SETTING_SAVE_CONFIRM_MSG2"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: false };
    save = { text: this.globalInstance.getLiteral("COMMON_SAVE"), visible: true };
    dontsave = { text: this.globalInstance.getLiteral("COMMON_DONT_SAVE"), visible: true };
}
