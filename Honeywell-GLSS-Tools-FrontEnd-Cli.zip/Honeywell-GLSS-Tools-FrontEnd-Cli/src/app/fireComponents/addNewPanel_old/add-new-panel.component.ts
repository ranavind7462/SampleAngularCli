import { Component, OnInit, Output, ViewChild, EventEmitter, ElementRef} from "@angular/core";
import { Panel } from "../../model/panel";
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "addNewPanel-app",
    templateUrl: "./add-new-panel.component.html",
    styleUrls: ["./add-new-panel.component.css"]
})
export class AddNewPanelComponent {

    @Output()
    createPanelEvent = new EventEmitter();

    @ViewChild("closeBtn")
    closeBtn: ElementRef;

    //For Internaliization
    globalInstance = Globals.getInstance();


    selectedLoop;

    //Html elements with its properties
    popupLbl = { text: this.globalInstance.getLiteral("PANEL_ADDNEWPANEL"), visible: true };
    panelLbl = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW_FUSIONPANEL"), visible: true };
    panelVariantLbl = { text: this.globalInstance.getLiteral("PANEL_VARIANT"), visible: true };
    panelDescLbl = { text: this.globalInstance.getLiteral("PANEL_DESCRIPTION"), visible: true };
    panelLoopsLbl = { text: this.globalInstance.getLiteral("PANEL_NUMBER_OF_LOOPS"), visible: true };

    panelSavedConfigTxt = { text: this.globalInstance.getLiteral("PANEL_OPEN_SAVED_CONFIGURATION_FILE"), visible: true };


    panelHeadingLbl = { text: this.globalInstance.getLiteral("PANEL_HEADING_DESCRIPTION"), visible: true };
    serialNoLbl = { text: this.globalInstance.getLiteral("PANEL_OVERVIEW_SERIALNO") + " xxxxxxxxxx", visible: true };
    
    loop01 = {
        text: this.globalInstance.getLiteral("01"),
        visible: true
    };
    loop02 = {
        text: this.globalInstance.getLiteral("02"),
        visible: true
    };
    loop04 = {
        text: this.globalInstance.getLiteral("04"),
        visible: true
    };

    loop05 = {
        text: this.globalInstance.getLiteral("05"),
        visible: true
    };

    startxloops = [
        {
            text: this.globalInstance.getLiteral("01"),
            visible: true
        },
        {
            text: this.globalInstance.getLiteral("02"),
            visible: true
        }
    ];

    smartxloops = [
        {
            text: this.globalInstance.getLiteral("01"),
            visible: true
        },
        {
            text: this.globalInstance.getLiteral("02"),
            visible: true
        },
        {
            text: this.globalInstance.getLiteral("04"),
            visible: true
        },

        {
            text: this.globalInstance.getLiteral("05"),
            visible: true
        }
    ];


    panelVariantList = [
        { text: this.globalInstance.getLiteral("PANEL_STARTX"),value:0, visible: true, noofloop: this.startxloops },
        { text: this.globalInstance.getLiteral("PANEL_SMARTX"), value:1,visible: true, noofloop: this.smartxloops }
    ];

    loops = this.startxloops;

    confirm = { text: this.globalInstance.getLiteral("COMMON_DONE"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: false };
    add = { text: this.globalInstance.getLiteral("COMMON_ADD"), visible: true };

    panel: Panel;

    constructor() {
        this.panel = new Panel();
        this.panel.noOfLoops = this.loop01.text;
        this.panel.variant = this.panelVariantList[0].text;
        this.loops = this.startxloops;
        this.selectedLoop = this.loop01.text;
    }



    onSelectionChange(loop) {
        debugger;
        this.selectedLoop = Object.assign({}, this.selectedLoop, loop);
        this.panel.noOfLoops = this.selectedLoop.text;
    }

    OnVariantChange(selectedValue: number) {
        debugger;
        this.panelVariantList.forEach(e => {
            if (e.value == selectedValue) {
            this.loops = e.noofloop;
            this.panel.variant = e.text;
            }
        })
    }


    /**
     * This method is used to open the add new panel popup.
     */
    onOpen() {
        this.panel = new Panel();
    }

    /**
    * This method is used to clear the panel details on reopening the add new panel popup.
    */
    onClose() {
        this.panel = new Panel();
    }

    /**
     * This method emits an event as create panel to its parent component and informs
     * about new panel getting added.
     */
    createPanel(): void {
        this.createPanelEvent.emit(this.panel);
        this.panel = new Panel();
        this.closeBtn.nativeElement.click();
    }
}
