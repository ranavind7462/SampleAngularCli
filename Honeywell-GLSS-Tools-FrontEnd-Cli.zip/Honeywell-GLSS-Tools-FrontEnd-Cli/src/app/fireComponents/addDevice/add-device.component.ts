import { Component, OnInit, Output, ViewChild, EventEmitter, ElementRef,Input } from "@angular/core";
import { Globals } from "../../shared/hooks/globals";
import { AddDevices } from "../../model/addDevices";
import { Module } from "../../model/modulesModel";
import { Detector } from "../../model/detectorModel";
import { FormControl } from '@angular/forms';
import {DeviceService } from "../../baseComponents/device/device.service"
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Loop } from "../../model/loop";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { DeviceTypes } from "../../model/DetailsTypes";
import { ModuleCategory } from "../../model/enums";

@Component({
    selector: "addDevices-app",
    templateUrl: "./add-device.component.html",
    styleUrls: ["./add-device.component.css"]
})
export class AddDeviceComponent {

    @Output() addDetectorsModules = new EventEmitter();
    @ViewChild("closeBtn") closeBtn: ElementRef;
    @ViewChild("DetectorInput") DetectorInput: ElementRef;
    @ViewChild("ModuleInput") ModuleInput: ElementRef;
    @Input() currentLoop: Loop = new Loop();
    detectorsList: Detector[] = [];
    moduleList: Module[] = [];
    deviceTypeMasterList :DeviceTypes[]=[];
    isAddBtnDisabled = true;
    selectedAddressCount: number = 0;
    

    //For Internaliization
    globalInstance = Globals.getInstance();

    //Html elements with its properties
    //header
    popupLbl = { text: this.globalInstance.getLiteral("DEVICE_ADD_DEVICES"), visible: true };

    //body
    numberOfDetector = { text: this.globalInstance.getLiteral("DEVICE_NUMBER_OF_DETECTORS"), visible: true };
    numberOfModule = { text: this.globalInstance.getLiteral("DEVICE_NUMBER_OF_MODULES"), visible: true };
    //footer
    addButtonText = { text: this.globalInstance.getLiteral("COMMON_ADD"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };


    rangeErrMsg = { text: this.globalInstance.getLiteral("DEVICE_RANGE_ERR_MSG"), visible: true };

    //validation
    validationMsg = {
        text: this.globalInstance.getLiteral("ADDNEWSITE_POSTAL_CODE_ERR_MSG"),
        visible: true
    };

    isDetectorsRange: boolean = true;
    isModulesRange: boolean = true;

    addDevice: AddDevices;

    constructor(private cacheComponentObj: CacheComponent, private detailServiceObj: DetailsService, private deviceServiceObj: DeviceService) {
        this.addDevice = new AddDevices();
        this.getDeviceTypeListMaster();
        //this.getDevicesList();
    }

    getDevicesList()
    {
        var loopId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedLoopId);
        this.deviceServiceObj.getDetectorsSrvc(loopId).subscribe(response => { this.populateDetectorsList(response) });
        this.deviceServiceObj.getModulesSrvc(loopId).then(response => { this.populateModulesList(response) });
        console.log(this.isDetector);
        this.selectDeviceCategoryEvent(this.isDetector);
        this.getDeviceTypeListMaster();
    }
    getDeviceTypeListMaster()
    {
        this.detailServiceObj.getDeviceTypesSrvc().subscribe((data) => {
            this.deviceTypeMasterList = data;
            console.log(data);
            console.log(this.deviceTypeMasterList);
        });
    }
    ngOnDestroy() {
        console.log("destroying");
    }
    ///**
    // * This method emits an event as create site to its parent component and informs
    // * about new site getting added.
    // */
    addDevices(): void {
        if (!this.isAddBtnDisabled) {
            if (this.detectorsList.length > 0)
                this.saveDetectors(this.detectorsList);
            else if (this.moduleList.length > 0)
                this.saveModules(this.moduleList);
            //this.closeBtn.nativeElement.click();
        }    
       
    }
    saveDetectors(detectors: Detector[])
    {
        this.deviceServiceObj.addDetectorsSrvc(detectors).then(response => { this.populateDevicesGrid(response.obj) });
       
    }
    saveModules(modules: Module[])
    {
        this.deviceServiceObj.addModulesSrvc(modules).then(response => { this.addDetectorsModules.emit(); });
      
    }
    populateDevicesGrid(resp) {
       
            if (this.moduleList.length > 0) {
                this.saveModules(this.moduleList);
            }
            else {
                this.addDetectorsModules.emit();
            }
      
    }
  

    /**
    * This method is used to open the add devices popup.
    */
    onOpen() {
        this.addDevice = new AddDevices();
    }

    /**
    * This method is used to clear the panel details on reopening the adddevices popup.
    */
    public onClose() {
        this.closeBtn.nativeElement.click();
        //this.addDevice = new AddDevices();
    }
    isDetector: boolean = true;
    startAddress: number = 1;
    endAddress: number = 149;
    selectedDeviceType: number=1;
    selectDeviceCategoryEvent(isDetector: boolean)
    {
        this.isDetector = isDetector;
        if (isDetector == false)
        {
            this.startAddress = 150;
            this.endAddress = 199;
            this.selectedDeviceType = 6;
        }
        else
        {
            this.startAddress = 1;
            this.endAddress = 149;
            this.selectedDeviceType =1;
        }
    }
    assignDeviceAddress(deviceAddress: string)
    {
        if (this.isDetector) {
           
                var index = this.detectorsList.findIndex(i => i.deviceAddress == deviceAddress);
                if (index == -1) {
                    this.addDetector(deviceAddress);
                }
                else {
                    this.detectorsList.splice(index, 1);
                }
                this.selectedAddressCount = this.detectorsList.filter(i => i.id == undefined && i.deviceTypeId == this.selectedDeviceType).length;
                this.isAddBtnDisabled = this.detectorsList.filter(i => i.id == undefined).length < 1;
        }
        else {
           
                var index = this.moduleList.findIndex(i => i.deviceAddress == deviceAddress);
                if (index == -1) {
                    this.addModule(deviceAddress);
                }
                else {
                    this.moduleList.splice(index, 1);
                }
                this.selectedAddressCount = this.detectorsList.filter(i => i.id == undefined && i.deviceTypeId == this.selectedDeviceType).length;
                this.isAddBtnDisabled = this.moduleList.filter(i => i.id == undefined).length < 1;
            }
    }

    addDetector(deviceAddress: string)
    {
        console.log(this.currentLoop);
        var detector = new Detector();
        detector.deviceAddress = deviceAddress;
        detector.loopId = this.currentLoop.id;// this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedLoopId);
        detector.deviceTypeId = this.selectedDeviceType;
        detector.zoneId = this.currentLoop.defaultDetectorZoneId;
        detector.isAssigned = true;
        this.detectorsList.push(detector);
        console.log(this.detectorsList);
    }
    addModule(deviceAddress: string)
    {
        console.log(this.currentLoop);
        var module = new Module();
        module.deviceAddress = deviceAddress;
        module.loopID = this.currentLoop.id;// this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedLoopId);
        module.deviceTypeId = this.selectedDeviceType;
        module.isAssigned = true;
        if (module.deviceTypeId == 9 || module.deviceTypeId == 10) {
            module.zoneID = this.currentLoop.defaultDetectorZoneId;
        }
        else
            module.zoneID = this.currentLoop.defaultModuleZoneId;

        this.moduleList.push(module);
        console.log(this.moduleList);
    }
    getDeviceType(deviceType: number)
    {
        this.selectedDeviceType = deviceType;
        console.log(this.selectedDeviceType);
    }    
    populateModulesList(resp) {
        console.log(resp);
        if (resp !== undefined)
            this.moduleList = resp;
        else
            this.moduleList = [];
        console.log(this.moduleList);
    }
    populateDetectorsList(resp) {
        if (resp !== undefined)
            this.detectorsList = resp;
        else
            this.detectorsList = [];
        console.log(resp);
    }

}
