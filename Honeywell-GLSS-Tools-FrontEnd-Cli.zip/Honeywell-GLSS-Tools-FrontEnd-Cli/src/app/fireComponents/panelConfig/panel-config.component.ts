import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { AddPanelModuleComponent } from "../addNewPanelModule/addpanelmodule.component";
import { PanelLayout, ModuleType } from "../../model/panelmodule";
import { PanelService } from "../../baseComponents/panel/panel.service";
import { PanelModuleListComponent } from "../panelModuleList/panelmodulelist.component";
import { PanelModuleDetailComponent } from "../panelModuleDetail/panelmoduledetail.component";
import { DeletePopupComponent } from "../deletePopup/delete-popup.component";
import { PanelComponent } from "../../baseComponents/panel/panel.component";
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "panel-config-app",
    templateUrl: "./panel-config.component.html",
    styleUrls: ["./panel-config.component.css"]
})
export class PanelConfigComponent {

    @Output()
    hideHeaderContent = new EventEmitter();

    @ViewChild(PanelModuleListComponent)
    private panelModuleListComponentObj: PanelModuleListComponent;

    @ViewChild(PanelModuleDetailComponent)
    private panelModuleDetailComponentObj: PanelModuleDetailComponent;

    @ViewChild(AddPanelModuleComponent)
    private newPanelModuleObj: AddPanelModuleComponent;

    @ViewChild(DeletePopupComponent)
    deletepopupComponentObj: DeletePopupComponent;

    //For Internationalization
    globalInstance = Globals.getInstance();
    moduleType: any = ModuleType;

    defaultView = { text: "", visible: true };
    addNewModule = {
        text: `+ ${this.globalInstance.getLiteral("PANEL_MODULE_ADD")}`,
        visible:
        false
    };
    defaultTxt = {
        text: this.globalInstance.getLiteral("PANEL_CONFIG_DEFAULTTEXT"),
        visible: true
    };

    constructor(private cacheComponentObj: CacheComponent, private panelServiceObj: PanelService) {
    }

    ngOnInit() {
        //this.defaultView.visible = true;
        this.loadModuleListEvent(this.cacheComponentObj
            .getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId));
        this.hideHeaderContent.emit();
    }


    getNewCardDetails(currentPanelId): void {
        this.getPanelModuleList(currentPanelId);
        this.getPanelModuleLayout(currentPanelId);
        //this.getFreeSlots(myobj);
    }

    getPanelModuleList(panelId) {
        this.panelServiceObj
            .getSupportedModuleTypesSrvc(panelId)
            .then(response => this.populatePanelModuleList(response));
    }

    getPanelModuleLayout(panelId) {
        this.panelServiceObj
            .getPanel(panelId)
            .then(response => this.populatePanelLayout(response));
    }

    populatePanelModuleList(response) {
        this.newPanelModuleObj.setPanelModuleList(JSON.parse(response));
    }

    populatePanelLayout(response) {
        //Need to hardcode 8 as right now service is returing 0
        this.newPanelModuleObj.setPanelLayout(6);
    }

    getModuleFreeSlots(panelModule){
        var moduleDetail = {'PanelId': '', 'ModuleType':'', 'LayoutType':''};
        moduleDetail.PanelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        moduleDetail.ModuleType = this.moduleType[panelModule.text];

        this.panelServiceObj.getFreeSlots(moduleDetail).then(
            response => {
                var data = response;
                this.newPanelModuleObj.getFreeSlots(data);
            },
            error => {
                console.log(error);
            }
        );
    }

    addNewCardConfDetails(obj) {
        this.panelServiceObj.createNewCardConfDetailsSrvc(obj).then(
            response => {
                var data = response;
                this.loadModuleListEvent(this.cacheComponentObj
                    .getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId));
            },
            error => {
                console.log(error);
            }
        );
    }

    addNewModuleEvent(evt) {
        this.getNewCardDetails(this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId));
    }

    loadModuleListEvent(panelId: any) {
        this.getPanelModules(panelId);
    }
    
    getPanelModules(panelId: any) {
        this.panelServiceObj
            .getModuleList(panelId)
            .then(response => this.validateModuleList(response));
    }

    validateModuleList(moduleList: any) {
        if (!moduleList) {
            this.defaultView.visible = true;
        } else if (moduleList && moduleList.length > 0) {
            this.defaultView.visible = false;
            this.panelModuleListComponentObj.loadPanelModuleList(moduleList);
            //Need to hardcode 8 as right now service is returing 0
            this.panelModuleListComponentObj.setPanelLayoutNo(6);
        }
        this.newPanelModuleObj.validateSlotAvailability(moduleList);
    }

    loadModuleDetailEvent(moduleId: any) {
        this.panelModuleDetailComponentObj.editMode = false;
        this.panelServiceObj
            .getPanel(this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId))
            .then(response => this.getPanelLayout(response, moduleId));
    }

    getPanelLayout(layout: any, moduleId: any) {
        let layoutType: string;

        /*As service provides '0' as default value(hardcoded), onle one case is written as of now */
        switch (layout.layoutType) {
            default:
                //Need to hardcode 6+2 as right now service is returing 0
                layoutType = "6";
                break;
        }

        /*Assign layout type and freeslots from panel model */
        this.panelModuleDetailComponentObj.setPanelLayoutType(layoutType);
        this.panelModuleDetailComponentObj.availableSlots = layout.freeSlots ? layout.freeSlots : [];

        this.panelServiceObj
            .getModuleDetails(moduleId)
            .then(response => this.panelModuleDetailComponentObj.createCardLayout(response));
    }

    deletePanelModuleData() {
        this.panelServiceObj.deletePanelModuleSrvc(this.cacheComponentObj
            .getKeyData(StorageType.LocalStorage, StorageKey.selectedModuleId))
            .then(response => {
                this.cacheComponentObj.setKeyData(StorageType.LocalStorage,
                    StorageKey.selectedModuleId,
                    {});
                this.loadModuleListEvent(this.cacheComponentObj
                    .getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId));
            },
            error => {
                console.log(error);
            }
            );
    }

    showDeletePopup() {
        this.deletepopupComponentObj.popupLabel.text = this.globalInstance.getLiteral("PANEL_MODULE_DELETE_LABEL");
        this.deletepopupComponentObj.confirmationMsg.text = this.globalInstance
            .getLiteral("PANEL_MODULE_DELETE_CONFIRMATION_MSG");
        this.deletepopupComponentObj.currentDeleteObj.label = this.cacheComponentObj
            .getKeyData(StorageType.LocalStorage, StorageKey.selectedModuleName);
        this.deletepopupComponentObj.currentDeleteObj.id = "PanelModule";
        this.deletepopupComponentObj.lastUpdated.visible = false;
        this.deletepopupComponentObj.enterPassword.visible = false;
        this.deletepopupComponentObj.deleteFiles.visible = false;
        this.deletepopupComponentObj.description.visible = true;
        this.deletepopupComponentObj.projId.visible = false;
        this.deletepopupComponentObj.deleteicon = "file.png";
    }
}
