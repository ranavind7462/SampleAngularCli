import { Component, OnInit } from '@angular/core';

@Component({
    selector: "tab-content-app",
    templateUrl: "./tabContent.component.html",
    styleUrls: ["./tabContent.component.css"]
})
export class TabContentComponent {
}
