import { Component, EventEmitter, Output, Input } from '@angular/core';
import { Globals } from "../../shared/hooks/globals";
import { Router } from "@angular/router";
import { Headerservice } from "../../fireComponents/header/header.service";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";

@Component({
    selector: "nfrpopuppanel-app",
    templateUrl: "./NFRPopupPanel.component.html",
    styleUrls: ["./NFRPopupPanel.component.css"]
})
export class NFRPopupPanel
{   
    //@Output() onButtonClick = new EventEmitter<string>();
    //@Input() isLicenseAvaiable: string ;
    //constructor(private route: Router, private headerserviceObj: Headerservice, private cacheComponentObj: CacheComponent) {
    //    this.isLicenseAvaiable = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.isLicenseAvailable);
  //  }
   
    //For Globaliization
    debugger;
    globalInstance = Globals.getInstance();
    literal = this.globalInstance.literalObj;
    confirmMsg1Text = { text: this.literal["PANEL_NFR_LIMIT_EXCEEDED"], visible: true };
    headerText = { text:"Alert!!!!!!", visible: true };        
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: false };
    save = { text: this.globalInstance.getLiteral("COMMON_SAVE"), visible: true };
   
}
