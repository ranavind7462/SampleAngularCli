import { Component, Input, Output, EventEmitter, OnChanges } from "@angular/core";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { DeviceTypes } from "../../model/DetailsTypes"


@Component({
    selector: "detectors-modules-app",
    templateUrl: "./detectors_modules.component.html",
    styleUrls: ["./detectors_modules.component.css"]
})
export class DetectorsModulesComponent {


    @Input()
    isDetector: boolean=true;
   @Input()
    selecteddeviceType: number;
   @Input() count: number;
   deviceTypesList: any[] = [];
   @Input() deviceTypes: DeviceTypes[]=[];
    @Output() selectdeviceTypeEvent = new EventEmitter();
    constructor(private detailServiceObj: DetailsService)
    {
        
    }
   
    populateDeviceTypeList()
    {
        console.log(this.isDetector);
        //if (this.deviceTypes.length == 0)
        //{
        //    this.detailServiceObj.getDeviceTypesSrvc().subscribe((data) => {
        //        this.deviceTypes = data;
        //        console.log(data);
        //        console.log(this.deviceTypes);
        //    });
        //}
        console.log(this.deviceTypes);
        if (this.isDetector === true) {
            this.deviceTypesList = [];
            this.deviceTypesList = this.deviceTypes.filter(i => i.isDetector == true && i.isModule == false);
            //this.selecteddeviceType = 1;
        }
        else {
            this.deviceTypesList = [];
            this.deviceTypesList = this.deviceTypes.filter(i => i.isDetector == false && i.isModule == true);
            // this.selecteddeviceType = 6;
        }
        console.log(this.deviceTypesList); 
    }
    //private deviceTypes = [
    //    { value: "1", text: "Optical_Smoke", isDetector: 1, isModule: 0 },
    //    { value: "2", text: "Heat_Sensor", isDetector: 1, isModule: 0 },
    //    { value: "3", text: "Multi_Sensor", isDetector: 1, isModule: 0 },
    //    { value: "4", text: "Beam_Sensor", isDetector: 1, isModule: 0 },
    //    { value: "5", text: "Duct_Sensor", isDetector: 1, isModule: 0 },
    //    { value: "6", text: "Sounder", isDetector: 0, isModule: 1 },
    //    { value: "7", text: "CTRL", isDetector: 0, isModule: 1 },
    //    { value: "8", text: "Relay", isDetector:0, isModule: 1 },
    //    { value: "9", text: "CallPoint", isDetector: 0, isModule: 1 },
    //    { value: "10", text: "ZoneMonitor", isDetector:0, isModule: 1 },
    //];

    selectType(selectedType: number): any {
        this.selecteddeviceType = selectedType;
        this.selectdeviceTypeEvent.emit(selectedType);

      //  this.selecteddeviceType=
      //  this.nodeClickedEvent.emit(treeNode);
    }
    ngOnChanges()
    {
        this.populateDeviceTypeList();
    }
}
