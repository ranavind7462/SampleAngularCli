import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { DeviceComplex } from "../../model/device";
import { ZoneService } from "../../baseComponents/zone/zone.service";

@Component({
    selector: "devicegrid-app",
    templateUrl: "./devicegrid.html",
    styleUrls: ["./devicegrid.css"]
})
export class DeviceGridComponent {
    @Input() devices: DeviceComplex[];
    @Input() actualDevices: DeviceComplex[];
    selectedDevice: DeviceComplex;

    @Output()
    selectedDeviceEvent = new EventEmitter();

    //selectedDevice: DeviceComplex;

    //For Internationalization
    globalInstance = Globals.getInstance();
    add = { text: this.globalInstance.getLiteral("ZONE_DEVICE_ADD"), visible: true };
    clear = { text: this.globalInstance.getLiteral("ZONE_DEVICE_CLEAR"), visible: true };
    gridHeight = "700px";

    totalChecked: number = 0;
   
    ngOnInit()
    {
        let height = window.screen.availHeight;
        this.gridHeight = ((height * 2) / 3) + "px";
        this.actualDevices = this.devices;
        console.log(this.actualDevices);
        this.setGridDevices(this.devices);
    }

    setGridDevices(data: DeviceComplex[])
    {
        this.devices = data;
        if (this.devices)
        {
            this.devices = this.globalInstance.getZoneNumberDisplay(this.devices);   
        }
        this.deselectAll();
    }

    devicecheck(checkbox: any) {
        
        if (checkbox.checked) {
            this.totalChecked++;
        }
        else if (!checkbox.checked) {
            this.totalChecked--;
        }

    }
    ApplyFilter(filterCriteria: any) {
        //this.filterCriteriaLoop = filterCriteria;
        console.log(this.actualDevices);
        let deviceFilter: DeviceComplex[] = this.actualDevices;
        if (filterCriteria.DeviceTypes.length > 0) 
            {
                deviceFilter = deviceFilter.filter(i => filterCriteria.DeviceTypes.some(j => j == i.deviceTypeId));
                if (filterCriteria.DeviceWithLabel != undefined) {
                    if (filterCriteria.DeviceWithLabel == true) {
                        deviceFilter = deviceFilter.filter(i => i.label !== "" && i.label !== null);
                    }
                    else {
                        deviceFilter = deviceFilter.filter(i => i.label == "" || i.label == null);
                    }
                }
                this.setGridDevices(deviceFilter);
            }
        else {
            if (filterCriteria.DeviceWithLabel != undefined) {

                if (filterCriteria.DeviceWithLabel == true) {
                    deviceFilter = deviceFilter.filter(i => i.label !== "" && i.label !== null);
                }
                else {
                    deviceFilter = deviceFilter.filter(i => i.label == "" || i.label == null);
                }
            }
            this.setGridDevices(deviceFilter);
        }
        console.log(filterCriteria);
    }
    deselectAll()
    {
        if (this.devices && this.devices.length > 0)
        {
            this.devices.forEach((item) => {
                item.isSelected = false;
            })
        }
        this.totalChecked = 0;
    }

    assigntozone()
    {
        let selectedDevices: DeviceComplex[];
        selectedDevices = this.devices.filter(d => d.isSelected === true);
        this.selectedDeviceEvent.emit(selectedDevices);
    }

}
