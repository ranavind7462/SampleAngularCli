import { Component,Input,Output,EventEmitter,OnChanges } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';
import { Zone } from "./../../model/zone";
import { ProgZone } from "./../../model/progZone";
import { EJComponents, EJTemplateDirective } from "ej-angular2";
@Component({
    selector: "progZone-List",
    templateUrl: "./progzonelist.component.html",
    styleUrls: ["./progzonelist.component.css"]
})
export class ProgZoneListComponent {

    @Input() zonelist: Zone[];
    @Input() progZoneList: ProgZone[]=[];
    @Input() selectedprogZoneType: number;
    @Output() selectzoneEvent = new EventEmitter();
    selectedZonesList: Zone[] = [];
    //Ej grid
    scrollSettings = { height: 320, allowVirtualScrolling: false, autoHide: true };
    constructor()
    {
       
   }
    actionComplete(e: any) {
        console.log("testing pro");           
    }
    onRowSelected(e: any) {
        console.log('testing check box selection');
    }
   getStatus(zone: Zone)
   {
       if (this.progZoneList !== undefined) {
           var progZone = this.progZoneList.filter(i => i.zoneID == zone.id);
           if (progZone.length > 0) {
               if (progZone[0].progZoneTypeID != this.selectedprogZoneType) {
                   return true;
               }
               else {
                   return false;
               }
           }
           else {
               return false;
           }
       }
       else
           return false;
     
    }
    selectZones(zone: Zone)
    {
        this.selectedZonesList.push(zone);
        var zones = this.selectedZonesList;
        console.log(zones);
        this.selectedZonesList = [];
        this.selectzoneEvent.emit(zones);
   }
   onChange(isChecked: boolean)
   {
       console.log(isChecked);
    }
   onCreate(e: any) {
       //e.find(".e-headercelldiv").on("change", "input[type='checkbox']", function (a) {
       //    console.log("add ing event");
       //    a.preventDefault();

       //    //Do something


       //});
       console.log("create");
       console.log(e);
       //e - headercelldiv
   }
   ngOnChanges()
   {
       console.log("create change");
   }
}
