import { Component, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { FormArray } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";

@Component({
    selector: "importConfig-app",
    templateUrl: "./import_configuration.component.html",
    styleUrls: ["./import_configuration.component.css"]
})

export class ImportConfigurationComponent {
    globalInstance = Globals.getInstance();
    @ViewChild("closeBtn")
    closeBtn: ElementRef;
    selectedImport: number;
    panelName: string = "";
    isOverride: boolean = false;
    panelDescLbl = { text: this.globalInstance.getLiteral("PANEL_DESCRIPTION"), visible: true };
    @Output()
    onSaveClick = new EventEmitter();
    panelImportOverride = { text: this.globalInstance.getLiteral("PANEL_IMPORT_OVERRIDE_EXITING"), value: 0, visible: true };
    panelImportAsNew = { text: this.globalInstance.getLiteral("SAVEAS_NEW_PANEL"), value: 1, visible: true };
    isSaveAsNew: boolean = false;
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };
    done = { text: this.globalInstance.getLiteral("COMMON_DONE"), visible: true };
    panelConfigOverrideMsg = {
        text: this.globalInstance.getLiteral("PANEL_IMPORT_OVERRIDE_EXITING_WARNING_MSG"), value: 0, visible: true
    };
    panelImportConfig = { text: this.globalInstance.getLiteral("PANEL_IMPORT_CONFIG_EXIST_MSG"), visible: true };
    error: string;
    panelLabel: string;
    isDoneEnabled: boolean = false;

    ngOnInit()
    {
        this.isSaveAsNew = false;
        this.isOverride = false; 
        this.isDoneEnabled = false;
    }
    onSelectionChange(isNew: boolean) {
        if (isNew) {
            this.isSaveAsNew = isNew; this.isOverride = !isNew;
        }
        else {
            this.isOverride = !isNew; this.isSaveAsNew = isNew;
        }

        this.isDoneEnabled = true;
    }
    Save(): void {
        if (this.isSaveAsNew)
            this.onSaveClick.emit(this.panelName);
        if (this.isOverride)
            this.onSaveClick.emit("overwrite");
    }

    onClose() {
        this.panelName = "";
        this.ngOnInit();
        this.closeBtn.nativeElement.click();
   }
}
