import { Component, OnDestroy,  ViewChild, ElementRef,ViewEncapsulation } from "@angular/core";
import { Headerservice } from "../../fireComponents/header/header.service";
import { Subscription } from "rxjs/Subscription";
import { Router } from "@angular/router";
import { Globals } from "../../shared/hooks/globals";
import { ActiveSitesService } from "../../baseComponents/shared/active-sites.service";
import { CustomerSite } from "../../model/customerSite";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { SiteoverviewComponent } from "../../baseComponents/siteoverview/siteoverview.component";
import { ActiveLicense } from "../../model/activeLicense";
import { LicenseService } from "../../baseComponents/license/license.service";
import { Licensetab, LicenseModel, FlexActionTypes } from "../../model/licenseModel";
//import { BlueToothDevices } from "../../model/bluetoothModel";

@Component({
    selector: "header-app",
    templateUrl: "./header.component.html",
    styleUrls: ["./header.component.css"],
    encapsulation: ViewEncapsulation.None
    //animations: [
 // trigger, state, style, transition, animate,
    //    trigger("slideItem",
    //        [
    //            state("show", style({ width: "320px",right:0 })),
    //            state("hide", style({ width: 0 })),
    //            transition("hide => show", animate("300ms ease-in-out")),
    //            transition("show => hide", animate("300ms ease-in-out"))
    //        ])

    //]
})
export class HeaderComponent implements OnDestroy {

    //For Internaliization
    activeLicenses: ActiveLicense[] = [];
    globalInstance = Globals.getInstance();
    licenseModel = new LicenseModel();
    subscription: Subscription;
    //Html elements with its properties
    headerValue = { text: "", visible: true };
    headerTooltip = { text: "tooltip", visible: true };
    synchButton = { text: "Synchronise", visible: false };
    userName = { text: "John Smith", visible: true };
    userCategory = { text: "Commissioning engineer", visible: true };
    switchSite = { text: "switchSite", visible: false };
    @ViewChild("bluetoothPop") popUpBtn: ElementRef;
    // Flag to toggle the main menu's sub menu item between collapsed and displayed status
    displaySubMenu = true;

    // Property used to trigger the animation of the menu status (hide->show,  show-> hide)
    menuState = "hide";
    headerSiteName = false;
    private sites: CustomerSite[] = null;
    private selectedSite: number;
    blueToothimgSrc: string = 'app/shared/images/PanelNotConnected.png';
    licenseTitle: string;
    @ViewChild(SiteoverviewComponent) siteOverViewComponentObj: SiteoverviewComponent;
    constructor(private lisenceSvcObj: LicenseService, private headerserviceObj: Headerservice, private route: Router, private activeSitesSrvcObj: ActiveSitesService, private cacheComponentObj: CacheComponent) {
        this.makeHeaderTextShorter(headerserviceObj.headerValue);
        this.subscription = headerserviceObj.dispatcher.subscribe((action) => this.handleAction(action));
        //LicensPOC
        // this.checkLicenseAvailablity();
        console.log(this.headerNavs);
        this.menuState = "hide";
    }

    //array of object defines the main menu items with its properties
    headerNavs = [
        {
            text: this.globalInstance.getLiteral("HEADER_DASHBOARD_TXT"),
            navLink: "dashboard",
            image: "fa fa-sitemap header__menuimage",
            image2: "",
            visible: true,
            expands: false,
            submenu: false,
            disabled: false
        },
        {
            text: this.globalInstance.getLiteral("HEADERNAV_USER_MANAGEMENT"),
            navLink: "",
            image: "fa fa-user header__menuimage",
            image2: "",
            visible: true,
            expands: false,
            submenu: false,
            disabled: false
        },
        {
            text: this.globalInstance.getLiteral("HEADERNAV_UTILITY_TOOLS"),
            navLink: "",
            image: "fa fa-wrench header__menuimage",
            image2: "fa fa-angle-down",
            visible: true,
            expands: true,
            submenu: false,
            disabled: false
        },
        {
            text: this.globalInstance.getLiteral("HEADERNAV_BATTERY_CALC"),
            navLink: "",
            image: "fa fa-square header__submenuimage",
            image2: "",
            visible: false,
            submenu: true,
            disabled: false
        },
        {
            text: this.globalInstance.getLiteral("HEADERNAV_DEVICE_PROFILE"),
            navLink: "",
            image: "fa fa-square header__submenuimage",
            image2: "",
            visible: false,
            submenu: true,
            disabled: false
        },
        {
            text: this.globalInstance.getLiteral("HEADERNAV_TOOL_SETTING"),
            navLink: "",
            image: "fa fa-cogs header__menuimage",
            image2: "",
            visible: true,
            expands: false,
            submenu: false,
            disabled: false
        },
        {
            text: this.globalInstance.getLiteral("HEADERNAV_HELP"),
            navLink: "",
            image: "fa fa-question header__menuimage",
            image2: "",
            visible: true,
            expands: false,
            submenu: false,
            disabled: false
        },
        {
            text: "License",
            navLink: "site/license",
            image: "fa fa-sitemap header__menuimage",
            image2: "",
            visible: true,
            expands: false,
            submenu: false,
            disabled: false
        }
    ];

    private handleAction(action): void {

        if (action === this.globalInstance.getLiteral("HEADER_DASHBOARD_TXT")) {
            this.switchSite.visible = false;
            console.log(action);
        }
        else {
            this.getActiveSites();
            this.switchSite.visible = true;
        }
        this.makeHeaderTextShorter(action);
    }

    ngOnDestroy() {
        // prevent memory leak when component destroyed
        this.subscription.unsubscribe();
    }

    navClick(navLink): void {
        //If condition will be removed once we implement the navigation for other route links.
        if (navLink === "dashboard")
            this.route.navigateByUrl(`/${navLink}`);
        else if (navLink === "site/license")
            this.route.navigateByUrl(`/${navLink}`);
    }

    ngOnInit() {
        this.menuState = "hide";
        this.licenseTitle = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.isLicenseAvailable);
        //  this.getActiveSites();
        // this.makeHeaderTextShorter();
    }

    /**
    * This method triggers the animation of the main menu status change from 'hide' to 'show''
    */
    showMenu() {
        this.menuState = "show";
    }

    /**
     * This method triggers the animation of the main menu status change from 'show to hide'
     */
    slideMenu() {
        this.menuState = "hide";
    }

    /**
     * This method triggers the animation of the main menu status change from 'show to hide' when the mouse leaves the side menu area
     */
    navCollapse() {
        this.menuState = "hide";
    }

    /**
     * This method makes the main menu's expandable item to open/close its sub menu items
     * by changing the visibility parameter on the headerNavs object definition
     * @param element - this is the selected main menu index in string format
     */
    toggleSubMenu(element: string) {
        let index = +element;

        // get the next element of the expandable item
        index++;
        if (this.headerNavs.length >= index) {
            while (this.headerNavs.length > index) {
                if (this.headerNavs[index].submenu) {
                    this.headerNavs[index].visible = !this.headerNavs[index].visible;
                }
                index++;
            }
        }
    }

    /**
     * This method evaluates if we need to shorten the header text value and dipslay an icon with the tooltip
     */
    makeHeaderTextShorter(currentPageTitle) {

        console.log(currentPageTitle);
        this.toggleSelectableMenuItems(currentPageTitle);

        if (currentPageTitle) {
            if (currentPageTitle.indexOf(">") !== -1) {
                this.headerTooltip.visible = true;
                const splitted = currentPageTitle.split(">", 2);
                this.headerTooltip.text = splitted[0];
                this.headerValue.text = splitted[1];

            } else {
                this.headerTooltip.visible = false;
                this.headerTooltip.text = "";
                this.headerValue.text = currentPageTitle;
            }
        }
    }

    /**
     * This method searches through the menu items text value. When the selected menu text includes the currently displayed page title,
     * the selection of the same menu will automatically disabled otherwise the menu item will be enabled
     * @param title - the currrently displayed page title
     */
    toggleSelectableMenuItems(title: string) {
        if (title) {
            this.headerNavs.forEach(item => item.disabled = (title.includes(item.text)));
        }
    }

    onSiteMouseHover(event) {
        this.headerSiteName = true;
    }

    onSiteMouseOut(event) {
        this.headerSiteName = false;
    }
    getActiveSites(): void {
        this.activeSitesSrvcObj
            .getActiveSitesSrvc()
            .then(response => this.populateSwitchSite(response));
        //var result1 = this.activeSitesSrvcObj
        //    .getCurrentSiteSrvc("123");
        //console.log(result1);
        //this.populateActiveSite(result1);
    }

    populateSwitchSite(resp) {
        this.sites = resp;
        this.selectedSite = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.currentSiteId);
        console.log(this.sites);
    }

    switchOverSite(siteId: number) {
        console.log(siteId);
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.currentSiteId, siteId);
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.isSiteSwitched, true);
        this.route.navigateByUrl("/dashboard");
    }
    navLicense() {
        this.licenseTitle = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.isLicenseAvailable);
        console.log(this.licenseTitle);
        //this.route.navigateByUrl("/site/license");
    }
    checkLicenseAvailablity() {
        //this.licenseModel.action = FlexActionTypes.Synchronizing;
        //this.licenseModel.key = "Synchronizing";
        this.lisenceSvcObj.GetActiveLiscenses().then(response => {
            console.log(response)
            this.activeLicenses = response;
            if (this.activeLicenses.length > 0) {
                this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.isLicenseAvailable, true);
                this.licenseTitle = "true";
            }
            else {
                this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.isLicenseAvailable, false);
                this.licenseTitle = "false";
            }
            console.log(this.activeLicenses);
        });



    }
    bluetoothDevices: string[] = [];

    connectBluetooth() {
        this.headerserviceObj.connectBluetoothService().subscribe((data) => {
            for (var i in data) {
                console.log(i["plutoBLE6"]);
            }
            this.bluetoothDevices.push("select")
            this.bluetoothDevices.push(data["plutoBLE6"]);
            // this.bluetoothDevices = data as BlueToothDevices[] ;
            console.log('test');
            console.log(this.bluetoothDevices);
            //console.log(data);
        });
    }
    ScanBluetooth(blutooth: string) {
        console.log(blutooth);
        this.headerserviceObj.scanBluetoothDeviceSrv(blutooth)
            .subscribe((data) => {
                if (data == "Connected") {
                    this.blueToothimgSrc = 'app/shared/images/PanelConnected.png';
                }
                console.log(data);
            })
        setTimeout(() => {

            this.popUpBtn.nativeElement.click();
            console.log("timeout")
        }, 5000)
        //console.log(blutooth);
    }
}
