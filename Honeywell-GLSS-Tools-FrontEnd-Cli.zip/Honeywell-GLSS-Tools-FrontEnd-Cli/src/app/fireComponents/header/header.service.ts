import { Component, OnInit, Output, Injectable } from "@angular/core";
import { Subject, Observable } from "rxjs/Rx";
import { Headers, Http, Response, RequestOptions } from "@angular/http";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { contentHeaders } from "../../shared/api/header";
//import { BlueToothDevices } from "../../model/bluetoothModel";

@Injectable()
export class Headerservice {

    dispatcher = new Subject<any>();
    headerValue: any;
    //licensesAvailable= new Subject<boolean>() ;
    constructor(private http: Http, private serviceUrlObj: ServiceUrl) {
        this.dispatcher.subscribe((action) => this.handleAction(action));
        // this.licensesAvailable.subscribe((action) => this.handleLicenseAction(action));
    }

    private handleAction(action): void {
        this.headerValue = action;
    }

    dispatchAction(action): void {
        debugger;
        this.dispatcher.next(action);
    }
    handleLicenseAction(action): void {
        // this.licensesAvailable.next(action);
    }
    connectBluetoothService(): Observable<string[]> {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Bluetooth);
        //var bluetoothDevices: string[]=[];
        //bluetoothDevices.push('test');
        //bluetoothDevices.push('Hello');
        //return Observable.of(bluetoothDevices);
        //enable while testing
        return this.http
            .post(getSvcUrl, { headers: contentHeaders })
            .map((response: Response) => response.json());
    }
    scanBluetoothDeviceSrv(devicepin: string): any {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.ScanBluetooth);
        //var bluetoothDevices: string[] = [];
        //bluetoothDevices.push('test');
        //bluetoothDevices.push('Hello');

        //return Observable.of(bluetoothDevices).delay(100000);
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        var device = JSON.stringify(devicepin)
        console.log(device);
        return this.http
            .post(getSvcUrl, device, options)
            .map((response: Response) => response.json());
    }
    pairBluetoothDeviceSrv(device: number): Observable<any> {
        let getSvcUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.pairBluetooth);
        //var bluetoothDevices: string[] = [];
        //bluetoothDevices.push('test');
        //bluetoothDevices.push('Hello');

        //return Observable.of(bluetoothDevices).delay(100000);
        return this.http
            .post(getSvcUrl, device, { headers: contentHeaders })
            .map((response: Response) => response.json());
    }
}