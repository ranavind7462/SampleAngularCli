import { Component, Output, Input, ViewChild, EventEmitter, ElementRef, ViewEncapsulation } from "@angular/core";
import { AddNewSiteComponent } from "../../fireComponents/addNewSite/add-new-site.component";
import { Globals } from "../../shared/hooks/globals";
import { ActiveSitesService } from "../../baseComponents/shared/active-sites.service";
import { ConfirmPopupComponent } from "../confirmPopup/confirmpopup.component";
import { NFRChecking } from "../../model/enums";

@Component({
    selector: "sub-header-app",
    templateUrl: "./sub-header.component.html",
    styleUrls: ["./sub-header.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class SubHeaderComponent {
    IsCreateSite: boolean=true;

    @ViewChild(AddNewSiteComponent)
    modal: AddNewSiteComponent;

    
    @ViewChild("alrt")  alertbtn: ElementRef;
    @ViewChild("newSite")  newsiteBtn: ElementRef;
    //Events emitted to the parent consumer.
    @Output()
    activeSiteEvent = new EventEmitter();
    @Output()
    archiveSiteEvent = new EventEmitter();
    @Output()
    newSiteAddEvent = new EventEmitter();

    @Input()
    currentContext: any;

    //For Internaliization
    globalInstance = Globals.getInstance();

    

    //Html elements with its properties
    activeSites = { text: this.globalInstance.getLiteral("SUBHEADER_DASHBOARD_ACTIVE"), visible: true };
    archiveSites = {
        text: this.globalInstance.getLiteral("SUBHEADER_DASHBOARD_ARCHIVE"),
        visible: true
    };
    addSite = { text: this.globalInstance.getLiteral("SUBHEADER_DASHBOARD_NEWSITE"), visible: false };
    gridView = { text: "", visible: true };
    listView = { text: "", visible: true };
    filter = { text: "", visible: true };
    searchBar = { text: "", visible: true };

    constructor(private activeSiteServiceObj: ActiveSitesService) {
       // this.checkSiteNFR();
    }

    loadActiveSites(): void {
        //TODO
        console.log("loadActiveSites");
    }

    loadArchiveSites(): void {
        //TODO
        console.log("loadArchiveSites");
    }

    showGridView(): void {
        //TODO
        console.log("showGridView");
    }

    showListView(): void {
        //TODO
        console.log("showListView");
    }

    addNewSite(): void {
       
            this.newSiteAddEvent.emit();
      
    }    
   
    checkSiteNFR(): any {
        debugger;
        this.activeSiteServiceObj.CheckSiteNFR().then(response => {
         

           // if (response.ok) {
                const data = response.json();
                if (data != NFRChecking.LimitExceded) {
                    this.IsCreateSite = true;
                    this.newsiteBtn.nativeElement.click();

                    return true;
                }
            
                else if (data == NFRChecking.LimitExceded) {                              
                this.IsCreateSite = false;
                //this.alertpopup.confirmMsg1Text.text = this.globalInstance.getLiteral("SITE_NFR_LIMIT_EXCEEDED");
                this.alertbtn.nativeElement.click();
                return false;

            }
        },
            error => {
                console.log(error);
                this.IsCreateSite = false;
                return false;
            }
        );
    }
}
