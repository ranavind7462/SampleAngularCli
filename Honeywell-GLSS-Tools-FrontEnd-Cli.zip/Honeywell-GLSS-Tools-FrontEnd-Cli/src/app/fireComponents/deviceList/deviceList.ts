import { Input, Component, ViewChild, HostListener, Output, EventEmitter, OnInit, DoCheck } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { Device, DetailsViewType } from "../../model/device";
import { Detector } from "../../model/detectorModel";
import { DetailsService } from "../../baseComponents/shared/Details.service";


@Component({
    selector: "devicelist-app",
    templateUrl: "./deviceList.html",
    styleUrls: ["./deviceList.css"]
})
export class DeviceListComponent {
    @Input() detectors: Detector[];
    @Output()
    selectedDeviceEvent = new EventEmitter(); 

    selectedDetector: Detector;

    //For Internationalization
    globalInstance = Globals.getInstance();
    literal = this.globalInstance.literalObj;

   // deviceType = 

    constructor(private detailsServiceObj: DetailsService) {
        //this.headerserviceObj.dispatchAction(`>${this.globalInstance.getLiteral("PANEL_AND_LOOPS")}`);
        console.log(this.detectors);      
    }

    ngOnChanges()
    {
        if (this.detectors && this.detectors.length > 1)
            this.selectedDetector = this.detectors[0];
    }

    deviceInfo(device: Detector)
    {
        this.selectedDetector = device;
        this.selectedDeviceEvent.emit(device);
    }
    GetAddress(detector: Detector)
    {
        console.log(detector);
        return this.globalInstance.getAddress(1, detector.loopId, detector.deviceAddress.toString(), true);
    }

    GetDeviceTypeUrl(deviceTypeId: any):string
    {
        return this.detailsServiceObj.getImageUrl(deviceTypeId);
    }
}
