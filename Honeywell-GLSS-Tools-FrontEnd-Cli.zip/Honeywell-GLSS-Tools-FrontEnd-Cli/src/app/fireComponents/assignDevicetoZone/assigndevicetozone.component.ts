import { Component, EventEmitter, Output, Input,ViewChild,ElementRef } from '@angular/core';
import { Globals } from "../../shared/hooks/globals";
import { Router } from "@angular/router";
import { Zone } from "../../model/zone";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { ZoneDeviceService } from "./zonedevice.service";
import { DeviceService } from "../../baseComponents/device/device.service";
import { ModulesService } from "../../baseComponents/modules/modules.service";
import { Detector } from "../../model/detectorModel";
import { Module } from "../../model/modulesModel";
import { Device } from "../../model/Device";
import { EJComponents } from "ej-angular2";

@Component({
    selector: "AssignDeviceToZone-app",
    templateUrl: "./assigndevicetozone.component.html",
    styleUrls: ["./assigndevicetozone.component.css"]    
})
export class AssignDeviceToZone {
    @Input() currentDevices: any[];
    @Input() isDetector: boolean;
    @Output() assignedZonesEvent = new EventEmitter();
    globalInstance = Globals.getInstance();
    zones: Zone[];
    detectors: Detector[];
    modules: Module[];
    zoneno: string;
    zonedescripton: string;
    devices: string;
    header: string;
    btnCancel: string;
    btnAssign: string;
    deviceCount: number;
    selectedZone: Zone;
    deviceID: number;
    @ViewChild("closeBtn")
    closeBtn: ElementRef;
    gridData: any;
    @ViewChild("changezone") gridview: EJComponents<any,any>;
    //Grid scrolling
    scrollSettings = { height: 420, allowVirtualScrolling: false, autoHide: true };

    constructor(private cacheComponentObj: CacheComponent,
        private zoneServiceObj: ZoneDeviceService, private deviceServiceObj: DeviceService, private modulesServiceObj: ModulesService) {
    }

    ngOnInit() {
        this.getZones();
        this.zoneno = this.globalInstance.getLiteral("ZONE_ZONE_NO");
        this.zonedescripton = this.globalInstance.getLiteral("ZONE_ZONE_DESCRIPTION");
        this.devices = this.globalInstance.getLiteral("ZONE_DEVICES");
        this.header = this.globalInstance.getLiteral("ZONE_ASSIGN_DEVICES");
        this.btnAssign = this.globalInstance.getLiteral("COMMON_ASSIGN");
        this.btnCancel = this.globalInstance.getLiteral("COMMON_CANCEL");
        this.selectedZone = new Zone();
        console.log(this.selectedZone.id);
    }
    getZones() {
        const selectedPanelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        this.zoneServiceObj
            .getZoneSrvc(selectedPanelId)
            .then(response => this.populateZonesContent(response));
    }

    populateZonesContent(resp) {
        this.zones = resp;

        this.zones = this.globalInstance.getZoneNumberDisplay(this.zones);     
        this.gridData = this.zones;
    }
    getdevicecount(zonenumber: number): number {
        var detector: number;
        this.zones.filter(z => z.zoneNumber == zonenumber).map(i => { detector = i.lstDetectors.length });
        var module = this.zones.filter(z => z.zoneNumber == zonenumber).map(i => i.lstModules).length;
        this.deviceCount = detector + module;
        return this.deviceCount;
    }
    getdetectors(zonenumber: number): Detector[] {
        var detectorlst: Detector[];
        this.zones.filter(z => z.zoneNumber == zonenumber).map(i => { detectorlst = i.lstDetectors });
        return detectorlst;
    }
    getmodules(zonenumber: number): Module[] {
        var modulelst: Module[];
        this.zones.filter(z => z.zoneNumber == zonenumber).map(i => { modulelst = i.lstModules });
        return modulelst;
    }

    onRowSelected(e: any) {        
        this.selectedZone = e.data;
        console.log(this.selectedZone);
    }
    assignZone() {
        var zoneID: number;
        var deviceID: number;
        zoneID = this.selectedZone.id;      
       
        if (this.isDetector) {
            this.detectors = this.currentDevices;
            if (this.detectors.length > 0)
                this.detectors.forEach(i => { i.zoneId = zoneID, i.zoneNumber = this.selectedZone.zoneNumber.toString(), i.zoneDescription = this.selectedZone.zoneDescription });
                this.deviceServiceObj.updateDevicesSrvc(this.detectors).then(resp => { this.assignedZonesEvent.emit(); });
            }
        else
        {
            this.modules = this.currentDevices;
            this.modules.forEach(i => { i.zoneID = zoneID });
            this.modulesServiceObj.updateModulesSrvc(this.modules).then(resp => { this.assignedZonesEvent.emit(); });
            }  

       // this.assignedZonesEvent.emit();
    }

    onClose() {
        this.selectedZone = new Zone();
        this.closeBtn.nativeElement.click();
        //this.assignedZonesEvent.emit();
    }

}
