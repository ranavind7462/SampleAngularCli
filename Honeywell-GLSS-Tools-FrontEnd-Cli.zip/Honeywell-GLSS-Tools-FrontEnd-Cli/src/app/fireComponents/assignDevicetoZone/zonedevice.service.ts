﻿import { Injectable } from "@angular/core";
import { Headers, Http, RequestOptions } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from "../../shared/hooks/config";
import { Zone } from "../../model/zone";

@Injectable()
export class ZoneDeviceService {

    constructor(private http: Http,
        private serviceUrlObj: ServiceUrl,
        private configObj: Config,
        private errorHandlerObj: MyErrorHandler) {
        this.serviceUrlObj = new ServiceUrl(this.configObj);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching list of panel by site id
     */
    getZoneSrvc(panelId: string): Promise<Zone[]> {

        let getZoneUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetZones);
        const re = /\/id\//g;
        getZoneUrl = getZoneUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(getZoneUrl)
            .toPromise()
            .then(response => {
                const data = response.json();                
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);      
    }
  
}