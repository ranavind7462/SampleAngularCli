import { Component, OnInit, Input, EventEmitter, Output } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { ZoneService } from "../../baseComponents/zone/zone.service";
import { Globals } from "../../shared/hooks/globals";
import { Zone } from "../../model/zone";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { Observable } from "rxjs";
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";

@Component({
    selector: "zonegridview-app",
    templateUrl: "./zonegridview.component.html",
    styleUrls: ["./zonegridview.component.css"]
})
export class ZoneGridViewComponent
{  
    constructor(private cacheComponentObj: CacheComponent, private zoneServiceObj: ZoneService)
    {
    }
    @Input() gridSource: Zone[];
    selectedZones: Zone[];

    gridVisibility = "hidden";
    scrollSettings = { height: "auto", allowVirtualScrolling: false, autoHide: true };
   
    //For Internaliization
    globalInstance = Globals.getInstance();   
    zoneNumber = { text: this.globalInstance.getLiteral("ZONE_ZONE_NO"), visible: true };
    zoneDescription = { text: this.globalInstance.getLiteral("ZONE_ZONE_DESCRIPTION"), visible: true };
    deviceCount = { text: this.globalInstance.getLiteral("ZONE_DEVICE_COUNT"), visible: true };    
    zonesSelected = { text: this.globalInstance.getLiteral("ZONES_SELECTED"), visible: true };
    deleteConfirmationMsg = { text: this.globalInstance.getLiteral("DEVICE_DELETE_CONFIRMATION_MSG"), visible: true };
    delete = { text: this.globalInstance.getLiteral("COMMON_DELETE"), visible: true };
    noOfZoneSelected: number = 0;///TODO: Bind the selected number of devices to the input box

    @Output() deleteMulZoneViewEvent = new EventEmitter();
    @Output() reloadZoneEvent = new EventEmitter();

    bingGrid(data: Zone[])
    {
        this.gridSource = data;
        if (this.gridSource && this.gridSource.length)
        {
            this.gridSource = this.globalInstance.getZoneNumberDisplay(this.gridSource);   
           // data.forEach(i => { i.zoneNumberDisplay = Number(i.zoneNumber) < 9 ? (String('0').repeat(2) + i.zoneNumber).substr((2 * -1), 2) : i.zoneNumber.toString(); });
            this.gridSource.sort((b, a) => (b.zoneNumber > a.zoneNumber) ? 1 : ((a.zoneNumber > b.zoneNumber) ? -1 : 0));
            this.gridVisibility = "visible";
        }
        else
        {
            this.gridVisibility = "hidden";
        }
    }

    ngOnInit()
    {
        let panelId: any = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        if (panelId)
        {
            this.zonesByPanelId(panelId);
        }
    }

    zonesByPanelId(panelId: any): any
    {
        // Get zones for panel id
        this.zoneServiceObj
            .geZonesByPanelId(panelId).subscribe((data) =>
            {
                this.bingGrid(data);
            });
    }

    ngDoCheck()
    {
        if (this.gridSource && this.gridSource.length > 0)
        {
            this.noOfZoneSelected = this.gridSource.filter(i => i.isSelected == true && i.zoneNumber > 1).length;
        }
    }

    openMulDeleteView()
    {
        if (this.noOfZoneSelected > 0)
        {
            this.selectedZones = this.gridSource.filter(i => i.isSelected == true && i.zoneNumber > 1);
            this.deleteMulZoneViewEvent.emit(this.selectedZones);
        }        
    }   

    onrowdatabound(e: any)
    {
        var zoneNumber = e.rowData.zoneNumber;

        if (zoneNumber < 2)
        {
            if (this.gridSource.length > 1)
            {
                e.row["0"].cells["1"].style.visibility = "hidden";
            }
            else if (this.gridSource.length == 1)
            {
                var html = e.row["0"].cells["1"].innerHTML.replace('<input type="checkbox">', '<input type="checkbox" style="visibility:hidden;">');
                e.row["0"].cells["1"].innerHTML = html;
            }            
        }
    }   

}
