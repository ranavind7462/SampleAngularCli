import { Input, Component, ViewChild, HostListener, Output, EventEmitter, OnInit, OnChanges,AfterViewInit} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { DetailsViewType} from "../../model/device";
import { DeviceService } from "../../baseComponents/device/device.service";
import { Detector } from "../../model/detectorModel";
import { DeletePopupComponent } from "../../fireComponents/deletePopup/delete-popup.component";
import { AssignDeviceToZone } from "../../fireComponents/assignDevicetoZone/assigndevicetozone.component";

@Component({
    selector: "deviceinfo-app",
    templateUrl: "./deviceInfo.html",
    styleUrls: ["./deviceInfo.css"]
})
export class DeviceInfoComponent {
    @Input() currentDevice: Detector;

    detectorInfo:Detector = new Detector();


    @ViewChild(DeletePopupComponent)
    deleteModal: DeletePopupComponent;

    @Output() devicesDeletedEvent = new EventEmitter<Detector>();
    @ViewChild(AssignDeviceToZone) assignZoneModal: AssignDeviceToZone;


    
    //For Internationalization
    globalInstance = Globals.getInstance();
    literal = this.globalInstance.literalObj;
    deviceLabel = { text: this.literal["DEVICES_INFO_DEVICE_LABEL"], visible: true };
    assignedToZone = { text: this.literal["DEVICES_INFO_ASSIGNED_TO_ZONE"], visible: true };
    deviceProfile = { text: this.literal["DEVICES_INFO_DEVICE_PROFILE"], visible: true };
    daySettings = { text: this.literal["DEVICES_INFO_DAY_SETTINGS"], visible: true };
    nightSettings = { text: this.literal["DEVICES_INFO_NIGHT_SETTINGS"], visible: true };
    preAlarm = { text: this.literal["DEVICES_INFO_PRE_ALARM"], visible: true };
    alarm = { text: this.literal["DEVICES_INFO_ALARM"], visible: true };
    ledBlink = { text: this.literal["DEVICES_INFO_LED_BLINK"], visible: true };
    latching = { text: this.literal["DEVICES_INFO_LATCHING"], visible: true };
    action = { text: this.literal["DEVICES_INFO_ACTION"], visible: true };
    on = { text: this.literal["DEVICES_INFO_ON"], visible: true };
    off = { text: this.literal["DEVICES_INFO_OFF"], visible: true };
    fire = { text: this.literal["DEVICES_INFO_FIRE"], visible: true };
    plantWarning = { text: this.literal["DEVICES_INFO_PLANT_WARNING"], visible: true };
    comments = { text: this.literal["COMMENTS"], visible: true };
    deviceInfo = { text: this.literal["DEVICES_INFO"], visible: true };
    delete = { text: this.literal["COMMON_DELETE"], visible: true };
    deleteConfirmationMsg = { text: this.literal["DEVICE_DELETE_CONFIRMATION_MSG"], visible: true };
    save = { text: this.literal["COMMON_SAVE"], visible: true };
    change = { text: this.literal["COMMON_CHANGE"], visible: true };

    editInfo = { text: this.literal["DEVICE_INFO_EDIT"], visible: true };
    cancel = { text: this.literal["COMMON_CANCEL"], visible: true };
    //DetailsViewType.DeviceInfo;


    selectedTab = DetailsViewType.DeviceInfo;
    deviceInfoContentView = DetailsViewType;
    isSave = true;

    ngOnChanges()
    {
        this.globalInstance.saveCancelClick(false, "divEditInfoContainer");
        this.detectorInfo = Object.assign({}, this.currentDevice);
    }

    deviceInfoProfileList = [
        { text: "Profile 1", value: 0, visible: true },
        { text: "Profile 2", value: 1, visible: true }
    ];

    constructor(private deviceServiceObj: DeviceService) {
        console.log(DetailsViewType);
        //this.headerserviceObj.dispatchAction(`>${this.globalInstance.getLiteral("PANEL_AND_LOOPS")}`);
    }



    alarmRangeErrMsg = { text: this.literal["DEVICES_INFO_RANGE_ERR_MSG"], visible: true };


    validateRange(obj: any) {
        debugger;
        this.alarmRangeErrMsg = { text: this.literal["DEVICES_INFO_RANGE_ERR_MSG"], visible: true };
        switch (obj.name) {
            case "dayprealarm":
                if (obj.value > 108 || obj.value < 80) {
                    this.detectorInfo.dPreAlarm = null;
                    break;
                }
                else if (this.detectorInfo.dFullAlarm == null)
                {

                }
                else if(obj.value > this.detectorInfo.dFullAlarm) {
                    this.alarmRangeErrMsg = { text: this.literal["DEVICES_INFO_ALARM_RANGE_ERR_MSG"], visible: true };
                    this.detectorInfo.dPreAlarm = null;
                    break;
                }
                break;
            case "nightprealarm":
                if (obj.value > 108 || obj.value < 80) {
                    this.detectorInfo.nPreAlarm = null;
                    break;
                }
                else if (this.detectorInfo.nFullAlarm == null) {

                }
                else if (obj.value > this.detectorInfo.nFullAlarm) {
                    this.alarmRangeErrMsg = { text: this.literal["DEVICES_INFO_ALARM_RANGE_ERR_MSG"], visible: true };
                    this.detectorInfo.nPreAlarm = null;
                    break;
                }
                break;
            case "dayalarm":
                if (obj.value > 108 || obj.value < 80) {
                    this.detectorInfo.dFullAlarm = null;
                    break;
                }
                else if (this.detectorInfo.dPreAlarm == null) {

                }
                else if (obj.value < this.detectorInfo.dPreAlarm) {
                    this.alarmRangeErrMsg = { text: this.literal["DEVICES_INFO_ALARM_RANGE_ERR_MSG"], visible: true };
                    this.detectorInfo.dFullAlarm = null;
                    break;
                }
                break;
            case "nightalarm":
                if (obj.value > 108 || obj.value < 80) {
                    this.detectorInfo.nFullAlarm = null;
                    break;
                }
                else if (this.detectorInfo.nPreAlarm == null) {

                }
                else if (obj.value < this.detectorInfo.nPreAlarm) {
                    this.alarmRangeErrMsg = { text: this.literal["DEVICES_INFO_ALARM_RANGE_ERR_MSG"], visible: true };
                    this.detectorInfo.nFullAlarm = null;
                    break;
                }
                break;
        }
    }


    OnProfileChange(selectedValue: number) {
        debugger;
        this.deviceInfoProfileList.forEach(e => {
            //if (e.value == selectedValue) {

            //}
        })
    }


    onSave() {
        var keys: Detector[] = [];

        keys.push(this.detectorInfo);
        this.deviceServiceObj.updateDevicesSrvc(keys).then(
            response => {
                if (response.ok) {
                    this.globalInstance.saveCancelClick(false, "divEditInfoContainer");
                    this.devicesDeletedEvent.emit(this.currentDevice);///TODO: rename the devicesDeletedEvent to deviceUpdatedEvent
                    
                }
            },
            error => {
                console.log(error);
            }
        );
    }


    openDeleteView() {
        this.deleteModal.currentDeleteObj.id = "Devices";
        this.deleteModal.currentDeleteObj.label = this.currentDevice.deviceAddressLabel;

        //this.deleteModal.currentDeleteObj.label = "PlaceHolder for device address to be deleted"; 
        //this.deleteModal.currentDeleteObj.desc = "PlaceHolder for device address to be deleted";
        this.deleteModal.deletemsg.text = this.deleteConfirmationMsg.text;
        this.deleteModal.popupLabel.text = this.globalInstance.getLiteral("DEVICE_DELETE_LABEL");
        this.deleteModal.currentDeleteObj.id = "Devices";
        this.deleteModal.lastUpdated.visible = false;
        this.deleteModal.enterPassword.visible = false;
        this.deleteModal.deleteFiles.visible = false;
        this.deleteModal.description.visible = true;
        this.deleteModal.projId.visible = false;
        this.deleteModal.deleteicon = "";
        this.deleteModal.confirmationMsg.text = "";
    }


    // delete the devices based on the device id passed
    deleteDevices() {
        var keys: Detector[] = [];
        keys.push(this.currentDevice);
        debugger;
        this.deviceServiceObj.deleteDevicesSrvc(keys).then(
            response => {
                if (response.ok) {
                    this.devicesDeletedEvent.emit(this.currentDevice);///TODO: rename the devicesDeletedEvent to deviceUpdatedEvent
                }
            },
            error => {
                console.log(error);
            }
        );

    }

    setTab(view: DetailsViewType) {
        this.selectedTab = view;
       
    }

    isSelected(view: DetailsViewType) {
       
        if (view === DetailsViewType.DeviceInfo && this.globalInstance.isEditClicked==false)
        {
            console.log(this.globalInstance.isEditClicked);
            console.log("edit button click");
            this.globalInstance.saveCancelClick(false, "divEditInfoContainer");

        }
        return this.selectedTab === view;
    }


    onAssignToZone() {  ///TODO: change zone
        this.assignZoneModal.ngOnInit();
        this.assignZoneModal.isDetector = true;
        var updatedDetectors: Detector[] = [];
        updatedDetectors.push(this.detectorInfo);
        this.assignZoneModal.currentDevices = updatedDetectors;
        // this.assignZoneModal.assignZone();
        // this.populateDevices(this.selectedLoop.id);
    }

    assignedZones(detector: Detector) {
        this.assignZoneModal.onClose();
        this.devicesDeletedEvent.emit(this.currentDevice);  ///TODO: rename the devicesDeletedEvent to deviceUpdatedEvent
       // this.populateDevices(this.selectedLoop.id);
        // this.populateDevicesGrid(resp);
    }


    onEditInfo(flag: boolean = true): void {
        this.globalInstance.saveCancelClick(flag, "divEditInfoContainer");
    }

    cancelClick() {
        this.globalInstance.saveCancelClick(false, "divEditInfoContainer");
        this.detectorInfo = this.currentDevice;
    }
    ngOnInit() {
        this.globalInstance.saveCancelClick(false, "divEditInfoContainer");
    }
    ngAfterViewInit()
    {
        this.globalInstance.saveCancelClick(false, "divEditInfoContainer");
        console.log('test');
    }
    onlyNumberKey(event) {
        console.log(event);
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    } 
}
