import { Component,Output,Input, EventEmitter,ViewChild,ElementRef } from '@angular/core';
import { FormArray } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { Module } from "../../model/modulesModel";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { ZoneService } from "./../../baseComponents/zone/zone.service";
import { ProgZoneService } from "./../../fireComponents/progZones/prog_zones.service";
import { Zone } from "./../../model/zone"
import { ProgZone } from "./../../model/progZone"
import { ProgZoneHeaderComponent} from "../../baseComponents/progZoneHeader/progzoneheader.component";
@Component({
    selector: "progZones-app",
    templateUrl: "./prog_zones.component.html",
    styleUrls: ["./prog_zones.component.css"]
})

export class ProgZonesComponent {
    @Output()
    createProgZonesEvent = new EventEmitter();

    @Input() selectedModule: Module;
    @Input() selectedZoneType: number = 1;
    @Output() assignedProgZonesEvent = new EventEmitter();
    zonelist: Zone[] = [];
    progZoneList: ProgZone[] = [];
    //For Globalization
    globalInstance = Globals.getInstance();
    @ViewChild(ProgZoneHeaderComponent) progZonesheaderModel: ProgZoneHeaderComponent;
    @ViewChild("closeBtn")
    closeBtn: ElementRef;
    //Html elements with its properties
    
    Cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };
    Save = { text: this.globalInstance.getLiteral("COMMON_ASSIGN"), visible: true };
    HeaderText = { text: this.globalInstance.getLiteral("PROG_ZONES_HEADER_TEXT"), visible: true };
    Tab_On_Text = { text: this.globalInstance.getLiteral("PROG_ZONES_ON"), visible: true };
    Tab_Pulse_Text = { text: this.globalInstance.getLiteral("PROG_ZONES_PULSE"), visible: true };
    Tab_Delay_Text = { text: this.globalInstance.getLiteral("PROG_ZONES_DELAY"), visible: true };
    Tab_Coincide_Text = { text: this.globalInstance.getLiteral("PROG_ZONES_COINCIDE"), visible: true };
    Tab_Coincidex3_Text = { text: this.globalInstance.getLiteral("PROG_ZONES_COINCIDE3"), visible: true };
    popupLbl = { text: this.globalInstance.getLiteral("PROG_ZONES_HEADER_TEXT"), visible: true };
    ClearAll = { text: this.globalInstance.getLiteral("COMMON_CLEAR"), visible: true };
    showCustomFields: boolean = true;
    prgZonesSelected = { text: this.globalInstance.getLiteral("PROG_ZONES_SELECTED"), visible: true };    
    sectext = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SEC"), visible: true };
    secValue: number = 0;
    noOfzonesSelected = { text: "000" };
    showClear: boolean = true;


    constructor(private cacheComponentObj: CacheComponent, private zoneServiceObj: ZoneService, private progZoneServiceObj: ProgZoneService) {
        // this.paneltimer = new Timer();
       
    }

    ngOnChanges()
    {
        this.getZones();
    }
    getZones() {
        this.selectedZoneType = 1;
        var selectedPanel = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        this.zoneServiceObj
            .geZones(selectedPanel)
            .then(response => this.updateZonesList(response));
    }

    getProgZones()
    {
        this.getZones();
        console.log(this.selectedModule);
        this.progZoneServiceObj
            .getProgZonesSrvc(this.selectedModule.id)
            .then(response => this.updateProgZonesList(response));

    }
    updateProgZonesList(resp)
    {
        console.log(resp);
        this.progZoneList = resp;
        //this.getZones();
        if (this.progZoneList === undefined)
        {
            this.progZoneList = [];
            this.secValue = 0;
        }
        else {
            console.log(this.progZoneList.filter(i => i.progZoneTypeID == 3).length);
            this.secValue = this.progZoneList.filter(i => i.progZoneTypeID == 3).length > 0 ? this.progZoneList.filter(i => i.progZoneTypeID == 3)[0].progZoneDelay:0;
        }
        this.bindZonesList();
        this.updateZonesSelectedCount();
    }
    updateZonesList(resp)
    {
        this.zonelist = resp;
        this.zonelist = this.globalInstance.getZoneNumberDisplay(this.zonelist);   
    }
    onClose() {
        this.selectedZoneType = 1;
        this.closeBtn.nativeElement.click();
        // this.paneltimer = new Timer();
    }
    getZoneType(zoneType: number) {
        this.selectedZoneType = zoneType;
        this.bindZonesList();
        console.log(this.selectedZoneType);
    }  
    ngOnInit() {
        this.getZones();
        //this.getProgZones();

    }
    bindZonesList()
    {
        if (this.zonelist != undefined) {
            if (this.progZoneList != undefined) {
                this.zonelist.forEach(i => {
                    var index = this.progZoneList.findIndex(j => j.zoneID == i.id);
                    if (index == -1) {
                        i.isSelected = false;
                    }
                    else {
                        i.isSelected = true;
                    }
                });
            }
        }

      
    }
    selectZone(zones: Zone[])
    {
        console.log(zones);
        zones.forEach(i => {
            if (i.isSelected) {
                true;
            }

        });
        for (var i = 0; i < zones.length;i++)
        {
            if (zones[i].isSelected)
        {
                this.AddSelectedZoneToProgZones(zones[i]);
            console.log(this.progZoneList);
        }
        else {
                this.removeSelectedZoneToProgZones(zones[i]);
            }
        };
        this.updateZonesSelectedCount();
    }

    AddSelectedZoneToProgZones(zone:Zone)
    {
        var prgZone = new ProgZone();
        prgZone.moduleID = this.selectedModule.id;
        prgZone.progZoneTypeID = this.selectedZoneType;
        prgZone.zoneID = zone.id;
        this.progZoneList.push(prgZone);
    }

    updateZonesSelectedCount()
    {
        if (this.progZoneList) {
            let selectedcount = this.progZoneList.length;
            this.noOfzonesSelected.text = (String('0').repeat(3) + selectedcount).substr((3 * -1), 3);
            this.showClear = selectedcount > 0 ? true : false;
        }
        else {
            this.noOfzonesSelected.text = "000";
            this.showClear = false;
        }
    }

    removeSelectedZoneToProgZones(zone: Zone) {
        var index = this.progZoneList.findIndex(i => i.zoneID == zone.id);
        if (index != -1) {
            this.progZoneList.splice(index, 1);
        }
    }
    assigProgZones()
    {
        if (this.progZoneList.length > 0)
        {
            this.progZoneList.forEach(p => p.progZoneDelay = this.secValue);
            this.progZoneServiceObj.assignedProgZonesSrvc(this.progZoneList).then(resp => { this.assignedProgZonesEvent.emit();});
        }
        else
        {
            this.progZoneServiceObj.deleteProgZoneSrvc(this.selectedModule.id).then(resp => { this.assignedProgZonesEvent.emit(); });
        }
       // this.selectedZoneType = 1;
        this.assignedProgZonesEvent.emit();
    }
    getProgZoneTypes()
    {
    }

    onclearAll()
    {
        this.progZoneList = [];
        this.bindZonesList();
        this.updateZonesSelectedCount();
    }
    onlyNumberKey(event)
    {
        if (this.secValue > 600)
        {
            this.secValue=600
        };
        return this.secValue;
       // console.log(this.secValue);
    }
}
