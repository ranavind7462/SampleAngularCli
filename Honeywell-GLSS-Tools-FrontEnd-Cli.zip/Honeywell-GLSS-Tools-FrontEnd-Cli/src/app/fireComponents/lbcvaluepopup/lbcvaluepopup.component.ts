import { Component, OnInit, Output, ViewChild, EventEmitter, ElementRef, Input, OnChanges,ViewEncapsulation } from "@angular/core";
import { Globals } from "../../shared/hooks/globals";
import { LBCDevices } from "../../model/LBCDevices";
import { LBCDataService } from "../lbcData/lbcdata.service";

@Component({
    selector: "lbcvaluePopup-app",
    templateUrl: "./lbcvaluepopup.component.html",
    styleUrls: ["./lbcvaluepopup.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class LBCValuePopupComponent {
    @Input()
    lbcDevice: LBCDevices;
    @Output()
    devicevalue = new EventEmitter();
    globalInstance = Globals.getInstance();
    setvaluedevice = { text: this.globalInstance.getLiteral("LBC_SETVALUE_DEVICE"), visible: true };
    quiescent = { text: this.globalInstance.getLiteral("LBC_QUIESCENT"), visible: true };
    alarm = { text: this.globalInstance.getLiteral("LBC_ALARM"), visible: true };
    save = { text: this.globalInstance.getLiteral("COMMON_SAVE"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };
    resetdefaultValue = { text: this.globalInstance.getLiteral("LBC_RESETVALUES"), visible: true };
    constructor(private lbcServiceObj: LBCDataService) {
    }
    ngOnInit() {
        console.log(this.lbcDevice);
    }
    ngOnChanges() {
        console.log(this.lbcDevice);
    }
    addSave() {                
        this.lbcServiceObj.saveLBCData(this.lbcDevice);
        this.devicevalue.emit(this.lbcDevice);
    }
    onClose() {

    }
    ResetValue() {
        this.lbcDevice.alarmCurrent = this.lbcDevice.minAlarm;
        this.lbcDevice.quiscentCurrent = this.lbcDevice.minQuiescent;
    }
}
