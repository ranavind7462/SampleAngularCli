import { Component, OnInit, Output,ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";

@Component({
    selector: "nav-app",
    templateUrl: "./navapp.component.html",
    styleUrls: ["./navapp.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class NavappComponent {

    constructor(private route: Router, private cacheComponentObj: CacheComponent) {
        const lastSelectedLink = route.url.substring(route.url.lastIndexOf("/") + 1);
        this.selectedNavlink = this.navappLinks.filter(x => x.sublink === lastSelectedLink)[0];
    }

    navappLinks = [
        {
            text: "Overview",
            sublink: "siteoverview",
            image: "app/shared/images/overview.png",
            active: "napapp__icon--color"
        },
        { text: "Panels", sublink: "panel", image: "app/shared/images/panel.png", active: "" },
        { text: "Zones", sublink: "zone", image: "app/shared/images/zones.png", active: "" },
       // { text: "Group", sublink: "zone", image: "app/shared/images/zones.png", active: "" },
      //  { text: "C&E Rules", sublink: "cnerules", image: "app/shared/images/c&e.png", active: "" },
       // { text: "Files", sublink: "files", image: "app/shared/images/file.png", active: "" },
        //{ text: "Devices", sublink: "device", image: "app/shared/images/file.png", active: "" },
        { text: "Report", sublink: "report", image: "app/shared/images/report.png", active: "" },
        { text: "Settings", sublink: "settings", image: "app/shared/images/settings.png", active: "" }
    ];

    selectedNavlink;

    navClick(navLink): void {
        this.selectedNavlink = navLink;
        this.cacheComponentObj.setKeyData(StorageType.LocalStorage, StorageKey.isSiteSwitched, false);
        //If condition will be removed once we implement the navigation for other route links.
        if (navLink.sublink === "siteoverview")
            this.route.navigateByUrl(`/site/${navLink.sublink}`);
        else if (navLink.sublink === "panel")
            this.route.navigateByUrl(`/site/${navLink.sublink}`);
        else if (navLink.sublink === "zone")
            this.route.navigateByUrl(`/site/${navLink.sublink}`);
         //else if (navLink.sublink === "device")
         //   this.route.navigateByUrl(`/site/${navLink.sublink}`);
        else
            console.log(`Click not enabled for : ${navLink.sublink}`);
    }
}
