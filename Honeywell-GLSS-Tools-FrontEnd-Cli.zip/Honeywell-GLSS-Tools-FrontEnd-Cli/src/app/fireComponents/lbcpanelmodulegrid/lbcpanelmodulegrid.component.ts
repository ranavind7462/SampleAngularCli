import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { DeviceComplex } from "../../model/device";
import { ZoneService } from "../../baseComponents/zone/zone.service";

@Component({
    selector: "lbcPanelModGrid-app",
    templateUrl: "./lbcpanelmodulegrid.component.html",
    styleUrls: ["./lbcpanelmodulegrid.component.css"]
})
export class LBCPanelModuleGridComponent {

    //For Internationalization
    globalInstance = Globals.getInstance();
    add = { text: this.globalInstance.getLiteral("ZONE_DEVICE_ADD"), visible: true };
    clear = { text: this.globalInstance.getLiteral("ZONE_DEVICE_CLEAR"), visible: true };
    gridHeight = "700px";

    totalChecked: number = 0;

    ngOnInit() {
        let height = window.screen.availHeight;
        this.gridHeight = ((height * 2) / 3) + "px"
        //this.setGridlbcdevices(this.lbcdevices);
    }

    setGridlbcdevices(data: DeviceComplex[]) {
        
    }

    lbcpanelcheck(checkbox: any) {

        if (checkbox.checked) {
            this.totalChecked++;
        }
        else if (!checkbox.checked) {
            this.totalChecked--;
        }

    }

    deselectAll() {        
    }
}
