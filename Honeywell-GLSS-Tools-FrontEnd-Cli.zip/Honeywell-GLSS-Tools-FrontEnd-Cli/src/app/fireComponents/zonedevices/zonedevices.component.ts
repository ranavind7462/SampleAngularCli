import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { ZoneService } from "../../baseComponents/zone/zone.service";
import { ActivatedRoute } from "@angular/router";
import { Globals } from "../../shared/hooks/globals";
import { Detector } from "../../model/detectorModel";
import { Module } from "../../model/modulesModel";
import { DeviceType } from "../../model/enums";
import { DeviceComplex } from "../../model/device";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { Observable } from "rxjs";

@Component({
    selector: "zonedevices-app",
    templateUrl: "./zonedevices.component.html",
    styleUrls: ["./zonedevices.component.css"]
})
export class ZoneDevicesComponent implements OnInit {

    deviceList: DeviceCount[] = [];
    deviceTypes: DeviceType[] = [];
    devicesTypecount: number = 0;
    sensorsTypeCount: number = 0;
    modulesTypeCount: number = 0;
    sensorsDevicesList: DeviceCount[] = [];
    moduleDevicesList: DeviceCount[] = [];
    constructor(private cacheComponentObj: CacheComponent, private detailsServiceObj: DetailsService, private zoneServiceObj: ZoneService)
    {
    }
    @Input() devices: DeviceComplex[];
    @Output()
    zoneDeviceEvent = new EventEmitter();

    //For Internaliization
    globalInstance = Globals.getInstance();

    zoneOverviewVisibility = "hidden";

    opticalSmokeLbl = { text: this.globalInstance.getLiteral("ZONE_OVERVIEW_OPTICAL_SMOKE"), visible: true };
    heatSensorLbl = { text: this.globalInstance.getLiteral("ZONE_OVERVIEW_HEAT_SENSOR"), visible: true };
    multiSensorLbl = { text: this.globalInstance.getLiteral("ZONE_OVERVIEW_MULTI_SENSOR"), visible: true };
    laserSensorLbl = { text: this.globalInstance.getLiteral("ZONE_OVERVIEW_LASER_SENSOR"), visible: true };
    callPointLbl = { text: this.globalInstance.getLiteral("ZONE_OVERVIEW_CALLPOINT"), visible: true };
    relayLbl = { text: this.globalInstance.getLiteral("ZONE_OVERVIEW_RELAY"), visible: true };
    controlModuleLbl = { text: this.globalInstance.getLiteral("ZONE_OVERVIEW_CONTROL_MODULE"), visible: true };
    isZoneOverview: boolean = true;

    noDeviceFound = { text: this.globalInstance.getLiteral("LOOP_OVERVIEW_LABEL_NODEVICEFOUND"), visible: true };
    ngOnChanges()
    {
        //this.devices = Object.assign({}, this.currentZone);
        if (!this.isZoneOverview)
        {
            this.dataByLoopId();
        }
        else
        {
            this.loadDevicesCount(this.devices);
        }

    }

    loadDevicesCount(data: DeviceComplex[])
    {
        this.devices = data;
        this.deviceList = [];

        if (data)
        {   
            data.forEach((item) =>
            {
                    if ((this.deviceList.findIndex(i => i.id == item.deviceTypeId) == -1) && data.filter(z => z.deviceType == item.deviceType).length > 0)
                    {

                        var devicecount = new DeviceCount();
                       
                        devicecount.id = item.deviceTypeId;
                        devicecount.type = item.deviceType;
                        devicecount.count = data.filter(z => z.deviceTypeId == item.deviceTypeId).length;
                        devicecount.ImageUrl = this.detailsServiceObj.getImageUrl(item.deviceTypeId);
                        devicecount.isDetector = item.isDetector;
                        this.deviceList.push(devicecount);
                    }                  
                });
           
        }

     
        this.sensorsTypeCount = this.deviceList != null ? this.deviceList.filter(i => i.isDetector == true).reduce((u, c) => u + c.count, 0): 0;
        this.modulesTypeCount = this.deviceList != null ? this.deviceList.filter(i => i.isDetector == false).reduce((u, c) => u + c.count, 0) : 0;
        this.moduleDevicesList = this.deviceList.filter(i => i.isDetector == false);
        this.sensorsDevicesList = this.deviceList.filter(i => i.isDetector == true);
        this.devicesTypecount = this.deviceList != null ? (this.sensorsTypeCount + this.modulesTypeCount): 0;
       
    }

    ngOnInit()
    {
        if (this.isZoneOverview) {
            let zoneId: any = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedZoneId);
            if (zoneId) {
                this.dataByZoneId(zoneId);
            }
        }
        else
        {
            this.dataByLoopId();
        }

   }

    dataByLoopId() {
    this.detailsServiceObj.getDeviceTypesSrvc().subscribe((i) => {
        this.devices.forEach((item) => {
            var result = i.filter(i => i.id == item.deviceTypeId);
            item.deviceType = result[0].deviceType;
        });
        this.loadDevicesCount(this.devices);
    });
    }

    dataByZoneId(zoneId: any): any
    {
        this.deviceList = [];
        this.zoneServiceObj.getDevicesByZoneId(zoneId).subscribe((resp) =>
        {
            this.detailsServiceObj.getDeviceTypesSrvc().subscribe((i) =>
            {
                resp.forEach((item) =>
                {
                    var result = i.filter(i => i.id == item.deviceTypeId);
                    item.deviceType = result[0].deviceType;
                }); 
                this.loadDevicesCount(resp);
            });            
        });
    }

}

export class DeviceCount
{
    count: number;
    type: string;
    id: number;
    ImageUrl: string;
    isDetector: boolean;
}
