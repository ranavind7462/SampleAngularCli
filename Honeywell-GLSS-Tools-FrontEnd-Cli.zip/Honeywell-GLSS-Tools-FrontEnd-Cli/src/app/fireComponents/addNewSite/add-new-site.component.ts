import { Component, OnInit, Output, ViewChild, EventEmitter, ElementRef,ViewEncapsulation} from "@angular/core";
import { CustomerSite } from "../../model/customerSite";
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "addNewSite-app",
    templateUrl: "./add-new-site.component.html",
    styleUrls: ["./add-new-site.component.css"],
    encapsulation: ViewEncapsulation.None
})
export class AddNewSiteComponent  {

    @Output()
    createSiteEvent = new EventEmitter();
    @ViewChild('siteForm') form;
    @ViewChild("closeBtn")
    closeBtn: ElementRef;
    dropDownCss: string = "fa fa-angle-down";
    dropdownColor: string = "newSiteDrop-down-placholder";
    footerStyle: string = "other-footer-padding";
    //For Internaliization
    globalInstance = Globals.getInstance();

    isWarning: boolean = false;
    isShow: boolean = false;
   
    //Html elements with its properties
    popupLbl = { text: this.globalInstance.getLiteral("ACTIVESITE_NEWSITE_BTN"), visible: true };
    importFile = { text: this.globalInstance.getLiteral("ADDNEWSITE_IMPORTFILE"), visible: false };
    browseButton = { text: this.globalInstance.getLiteral("ADDNEWSITE_BROWSE_BTN"), visible: true };
    siteStatus = { text: this.globalInstance.getLiteral("ADDNEWSITE_SITESTATUS"), visible: true };
    sitenameWarning = { text: this.globalInstance.getLiteral("ADDNEWSITE_SITENAME_ERR_MSG"), visible: true };
    inCommissioning = {
        text: this.globalInstance.getLiteral("ADDNEWSITE_STATUS_COMMISSIONING"),
        visible: true
    };
    underMaintenance = {
        text: this.globalInstance.getLiteral("ADDNEWSITE_STATUS_MAINTENANCE"),
        visible: true
    };
    siteName = { text: this.globalInstance.getLiteral("ADDNEWSITE_SITENAME"), visible: true };
    projId = { text: this.globalInstance.getLiteral("ADDNEWSITE_SELECT_SITE_TYPE"), visible: true };
    custName = { text: this.globalInstance.getLiteral("ADDNEWSITE_CUSTNAME"), visible: true };
    contactName = { text: this.globalInstance.getLiteral("ADDNEWSITE_CONTACTNAME"), visible: true };
    emailField = { text: this.globalInstance.getLiteral("ADDNEWSITE_EMAIL"), visible: true };
    contactNo = { text: this.globalInstance.getLiteral("ADDNEWSITE_NUMBER"), visible: true };
    address = { text: this.globalInstance.getLiteral("ADDNEWSITE_ADDRESS"), visible: true };
    addressLine2 = { text: this.globalInstance.getLiteral("ADDNEWSITE_ADDRESS"), visible: true };
    confirm = { text: this.globalInstance.getLiteral("COMMON_ADD"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };
    validationMsg = {
        text: this.globalInstance.getLiteral("ADDNEWSITE_POSTAL_CODE_ERR_MSG"),
        visible: true
    };
    selectLable = { text: "Select " + this.globalInstance.getLiteral("ADDNEWSITE_SELECT_SITE_TYPE"), visible: true };
    selectTypeLabel = { text: "Select " + this.globalInstance.getLiteral("ADDNEWSITE_SELECT_SITE_TYPE"), visible: true };
    //selectedSiteType: string = this.selectTypeLabel.text;
    currentSite: CustomerSite;

    private siteTypes =
    [
        { value: this.globalInstance.getLiteral("SITE_TYPE_LABEL_RESIDENTIAL"), display: this.globalInstance.getLiteral("SITE_TYPE_LABEL_RESIDENTIAL")},
        { value: this.globalInstance.getLiteral("SITE_TYPE_LABEL_COMMERCIAL"), display: this.globalInstance.getLiteral("SITE_TYPE_LABEL_COMMERCIAL")},
        { value: this.globalInstance.getLiteral("SITE_TYPE_LABEL_HOSPITALITY"), display: this.globalInstance.getLiteral("SITE_TYPE_LABEL_HOSPITALITY")},
        { value: this.globalInstance.getLiteral("SITE_TYPE_LABEL_INDUSTRY"), display: this.globalInstance.getLiteral("SITE_TYPE_LABEL_INDUSTRY")},
       
    ];

    constructor() {
        this.currentSite = new CustomerSite();
       this.dropDownCss= "fa fa-angle-down";
    }

    //ngOnChanges(chnages:SimpleChanges) {
    //    console.log(this.form)
    //    this.form.control.valueChanges
    //        .subscribe(values => this.doSomething(values));
    //}
    //doSomething(values: any) {
    //    console.log(values);
    //}
    //ngDoCheck()
    //{
    //    this.form.control.valueChanges
    //        .subscribe(values => this.doSomething(values));
    //}
    /**
     * This method is used to open the add new site popup.
     */
    onOpen() {
        this.currentSite = new CustomerSite();
        this.dropDownCss = "fa fa-angle-down";
    }

    /**
    * This method is used to clear the customer site details on reopening the add new site ite popup.
    */
    onClose() {
        this.currentSite = new CustomerSite();
        this.isWarning = false;
        this.selectTypeLabel.text = "Select " + this.globalInstance.getLiteral("ADDNEWSITE_SELECT_SITE_TYPE");
        this.closeBtn.nativeElement.click();

    }
    ngOnDestroy() {
        console.log("destroying");
    }
    /**
     * This method emits an event as create site to its parent component and informs
     * about new site getting added.
     */
    createSite(): void
    {
        this.createSiteEvent.emit(JSON.stringify(this.currentSite));
    }

    onlyNumberKey(event)
    {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    showHideAddressDetails(show: boolean) {
        this.isShow = show;
        if (!show) {
            this.footerStyle = "other-footer-padding1";
        }
    }
    selectType(selectedValue: any)
    {
        this.currentSite.siteType = selectedValue.value;
        this.selectTypeLabel.text = selectedValue.display;
        this.dropDownCss = "fa fa-angle-down";
        this.dropdownColor = "newSiteDrop-down-placholder-selected";
        this.footerStyle = "other-footer-padding";
    }
    ToggledropDown() {
        this.dropDownCss = "fa fa-angle-up";
        this.dropdownColor = "newSiteDrop-down-placholder newSiteDrop-down-border";
        if (this.isShow == false) {
            this.footerStyle = "less-view-footer-padding";
        }
        else {
            this.footerStyle = "other-footer-padding";
        }
        console.log("clicked toggle"); 
    }
    toggleOutEvent() {
        this.dropdownColor = "";
        this.dropDownCss = "fa fa-angle-down";
    }
    checkSiteType(siteType: any) {
        console.log(siteType);
    }
}
