import { Component, Input, Output, EventEmitter, ViewChild,OnChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { Loop } from "../../model/Loop";
import { LBCLoop } from "../../model/LBCLoop";
import { LBCDevices } from "../../model/LBCDevices";
import { EJComponents } from "ej-angular2/src";

@Component({
    selector: "lbcLoopDeviceGrid-app",
    templateUrl: "./lbcloopdevicesgrid.component.html",
    styleUrls: ["./lbcloopdevicesgrid.component.css"]
})
export class LBCLoopDeviceGridComponent {

    @Input()
    loopGrid: LBCLoop;
   
    devicesList: LBCDevices[] = [];
    selectedDevice: LBCDevices;
    updateDevices = new EventEmitter();
    public gridData: any;
    //For Internationalization
    globalInstance = Globals.getInstance();   
    quiescent = { text: this.globalInstance.getLiteral("LBC_QUIESCENT"), visible: true };
    alarm = { text: this.globalInstance.getLiteral("LBC_ALARM"), visible: true };
   

    ngOnInit() {
        debugger;
        console.log(this.loopGrid);
        this.devicesList = this.loopGrid.deviceList;
        this.gridData = this.devicesList;
        //this.setGridlbcdevices(this.lbcdevices);
    }
    ngOnChanges() {
        this.gridData = this.loopGrid.deviceList;
    }
    updateDeviceValue(lbcDevice: LBCDevices) {
        debugger;
        this.loopGrid.deviceList.forEach(q => {
            if (q.loopId == lbcDevice.loopId && q.deviceType == lbcDevice.deviceType)
                q = lbcDevice;
                    
        })
        //this.loopGrid.totalDeviceQuiscentCurrent=
        this.gridData = this.loopGrid.deviceList;
        //his.gridData=
       
    }

    callLbcpopup(lbcdevice: LBCDevices) {        
        this.selectedDevice = lbcdevice;        
    }
}
