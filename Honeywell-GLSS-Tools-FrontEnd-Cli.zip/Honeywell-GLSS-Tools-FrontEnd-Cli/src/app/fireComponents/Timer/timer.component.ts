import { Component,Output,EventEmitter,ViewChild,ElementRef } from '@angular/core';
import { FormArray } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { Timer } from "../../model/timer";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";

@Component({
    selector: "newTimer-app",
    templateUrl: "./timer.component.html",
    styleUrls: ["./timer.component.css"]
})

export class TimerComponent
{
    @Output()
    createTimerEvent = new EventEmitter();
    //For Globalization
    globalInstance = Globals.getInstance();
    showErrorMsg: boolean=false;
    paneltimer: Timer = new Timer();
    @ViewChild('timerForm') form;
    @ViewChild("closeBtn")
    closeBtn: ElementRef;
    daysArray:any[] =[];
    days = DaysofWeek;
    keys: any;    
    //Html elements with its properties
    timerMsg = { text: this.globalInstance.getLiteral("TIMER_WARNING_MSG"), visible: this.showErrorMsg }
    newTimer = { text: this.globalInstance.getLiteral("NEW_TIMER_LABEL"), visible: true };
    StartTime = { text: this.globalInstance.getLiteral("START_TIME_LABEL"), visible: true };
    StopTime = { text: this.globalInstance.getLiteral("STOP_TIME_LABEL"), visible: true };
    Repeat = { text: this.globalInstance.getLiteral("TIMER_REPEAT_MODE"), visible: true }; 
    Sun = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SUN"), visible: true };
    Mon = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_MON"), visible: true };
    Tue = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_TUE"), visible: true };
    Wed = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_WED"), visible: true };
    Thu = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_THU"), visible: true };
    Fri = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_FRI"), visible: true };
    Sat = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SAT"), visible: true };
    Cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };
    Add = { text: this.globalInstance.getLiteral("COMMON_ADD"), visible: true };
    showCustomFields: boolean = true;
    daysSelection: boolean = true;
    showchkErrorMsg = false;
    private Repeats = [
        { value: "1", text: this.globalInstance.getLiteral("TIMER_REPEAT_MODE_CUSTOM") }, 
        { value: "2", text: this.globalInstance.getLiteral("TIMER_REPEAT_MODE_WEEKLY") }, 
        { value: "3", text: this.globalInstance.getLiteral("TIMER_REPEAT_MODE_MONTOFRI") }
    ];
    weekdays = [
        { text: this.globalInstance.getLiteral("COMMON_DAY_LABEL_SUN"), value: 0, checked: false },
        { text: this.globalInstance.getLiteral("COMMON_DAY_LABEL_MON"), value: 1, checked: false },
        { text: this.globalInstance.getLiteral("COMMON_DAY_LABEL_TUE"), value: 2, checked: false }, 
        { text: this.globalInstance.getLiteral("COMMON_DAY_LABEL_WED"), value:3, checked: false },
        { text: this.globalInstance.getLiteral("COMMON_DAY_LABEL_THU"), value: 4, checked: false },
        { text: this.globalInstance.getLiteral("COMMON_DAY_LABEL_FRI"), value:5, checked: false },
        { text: this.globalInstance.getLiteral("COMMON_DAY_LABEL_SAT"), value: 6, checked: false },
    ]
    constructor(private cacheComponentObj: CacheComponent) {
        // this.paneltimer = new Timer();
        this.paneltimer.repeatMode = 1;
        this.keys = Object.keys(this.days).filter(f => !isNaN(Number(f)));
    }
    dropdownchanges(value: any)
    {
        console.log(value);
        this.showCustomFields = value == 1 ? true : false;

    }
    onClose() {
        this.paneltimer = new Timer();
        for (var i = 0; i < this.weekdays.length; i++) {

            this.weekdays[i].checked = false;

        }        
        this.showErrorMsg = false;
        this.showchkErrorMsg = false;
    }
    addTimer()
    {
      
        if (this.paneltimer.repeatMode == 2)
        {
            this.paneltimer.noOfDays = 7;
            this.paneltimer.repeatDays = (Object.keys(DaysofWeek).map(key => DaysofWeek[key]).filter(value => typeof value === 'string') as string[]).toString();
        }
        if (this.paneltimer.repeatMode == 3)
        {
            this.paneltimer.repeatDays = (Object.keys(DaysofWeek).map(key => DaysofWeek[key]).filter(value => typeof value === 'string' && value.toLowerCase() != "sun" && value.toLowerCase() != "sat") as string[]).toString();
            this.paneltimer.noOfDays = 5;   
        }
        if (this.paneltimer.repeatMode == 1) {
            this.paneltimer.noOfDays = this.daysArray.length;
            if (this.daysArray.length > 0)
                this.paneltimer.repeatDays = this.daysArray.toString();
            else {
                this.showchkErrorMsg = true;
                return;
            }
        }
        this.paneltimer.panelId = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedPanelId);
        this.createTimerEvent.emit(this.paneltimer);
    
        this.closeBtn.nativeElement.click();
    }
    ngOnInit() {
        this.paneltimer.repeatMode = 1;
        this.showchkErrorMsg = false;
    }
    onChange(day: string, isChecked: boolean) {
        console.log(day);
      

        if (isChecked) {
           this.daysArray.push(day);
        } else {
            let index = this.daysArray.indexOf(day)
            this.daysArray.splice(index, 1);
        }
        if (this.daysArray.length > 0) {
            this.showchkErrorMsg = false;
        }
        console.log(this.daysArray);
    }
    check(day: any)
    {       
        var result = this.paneltimer.repeatDays !== undefined ? this.paneltimer.repeatDays.split(",").indexOf(day) : -1;
        console.log(result);
        if (result != -1)
            return true;
        else
            return false;
      
    }
    validateTime(endTime: any) {
        console.log(endTime);
        if (endTime <= this.paneltimer.startTime) {
            this.showErrorMsg = true;            
        }
        else
        {
            this.showErrorMsg = false;            
        }
        if (this.paneltimer.repeatMode == 2)
        {
            this.daysSelection = true;
        }
        else {
            this.daysSelection = false;
        }
    }
    validateStartTime(startTime: any) {
        console.log(this.paneltimer.endTime);
        if (this.paneltimer.endTime !== undefined) {
            if (this.paneltimer.endTime <= startTime) {
                this.showErrorMsg = true;
            }
            else {
                this.showErrorMsg = false;
            }
        }
       
    }
}

export enum DaysofWeek {
    
    Sun=0,
    Mon,
    Tue,
    Wed,
    Thu,
    Fri,
    Sat
    
};
