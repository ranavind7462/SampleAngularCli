﻿import { Injectable } from "@angular/core";
import { Headers, Http, RequestOptions } from "@angular/http";
import "rxjs/add/operator/toPromise";
import { Timer } from "../../model/timer";
import { ServiceUrl, ApiName } from "../../shared/api/serviceurl";
import { MyErrorHandler } from "../../shared/utility/errorhandler";
import { contentHeaders } from "../../shared/api/header";
import { Config } from "../../shared/hooks/config";

@Injectable()
export class TimerService {

    constructor(private http: Http,
        private serviceUrlObj: ServiceUrl,
        private configObj: Config,
        private errorHandlerObj: MyErrorHandler) {
        this.serviceUrlObj = new ServiceUrl(this.configObj);
    }

    /**
     * This is a service method which makes a rest call to the webapi for fetching list of panel by site id
     */
    getTimerSrvc(panelId: string): Promise<Timer[]> {

        let getTimersUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetTimers);
        const re = /\/id\//g;
        getTimersUrl = getTimersUrl.replace(re, `/${panelId}/`);
        return this.http
            .get(getTimersUrl)
            .toPromise()
            .then(response => {
                const data = response.json();
                //as Panel[];
                //for (var j = 0; j < data.length; j++) {
                //    if (data[j].loops > 0) {
                //        for (var i = 0; i < data[j].loops; i++) {
                //            var loop = new Loop;
                //            loop.loopname = "0" + (i + 1) + " Loop (00)";
                //            data[j].subnodes.push(loop);
                //        }
                //    }
                //}
                return data;
            },
            response => {

            })
            .catch(this.errorHandlerObj.handleServerError);
        // return Promise.resolve(data);
    }

    /**
    * This is a service method which makes a rest call to the webapi for creating or updating a panel
    * through the add new panel popup.
    */
    createTimerSrvc(timerObj) {
        const posttimerUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Timer);
        return this.http
            .post(posttimerUrl, timerObj, { headers: contentHeaders })
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }
    

    deleteTimerSrvc(timers: any[]) {
        const deletePanelUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.DeleteTimer)  ;
        return this.http
            .delete(deletePanelUrl, new RequestOptions({
                headers: contentHeaders,
                body: timers
            }))
            .toPromise()
            .then(response => {
                return response;
            },
            response => {
                console.log(response);
                return response;
            })
            .catch(this.errorHandlerObj.handleServerError);
    }

  //  deletePanelModuleSrvc(moduleId: string) {
  //      const deletePanelModuleUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.DeletePanelModule) + "/" + moduleId;
  //      return this.http
  //          .delete(deletePanelModuleUrl)
  //          .toPromise()
  //          .then(response => {
  //              return response;
  //          },
  //          response => {
  //              console.log(response);
  //              return response;
  //          })
  //          .catch(this.errorHandlerObj.handleServerError);
  //  }

  //  getFreeSlots(moduleDetail: any) {
  //      let panelFreeSlotsUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.GetFreeSlots);
  //      const re = /\/id\//g;
  //      panelFreeSlotsUrl = panelFreeSlotsUrl.replace(re, `/${moduleDetail.PanelId}/`);
  //      // Optional query parameter. If this parameter is not set all free slots will be provided
  //      panelFreeSlotsUrl = panelFreeSlotsUrl.concat("/?moduleType=", `${moduleDetail.ModuleType}`);
  //      // Optional query parameter. Currently not used (can be removed).
  //      panelFreeSlotsUrl = panelFreeSlotsUrl.concat("&layoutType=", `${moduleDetail.LayoutType}`);
  //      return this.http
  //          .get(panelFreeSlotsUrl)
  //          .toPromise()
  //          .then(response => {
  //              const data = response.json();
  //              return data;
  //          },
  //          response => {
  //              const data = response.json();
  //              return data;
  //          })
  //          .catch(this.errorHandlerObj.handleServerError);
  //  }

  //  editPanelSrvc(panelObj) {
  //      debugger;
  //      console.log(panelObj.id);
  //      const panelId = panelObj.id;
  //      const putPanelUrl = this.serviceUrlObj.fetchUrlEndPoint(ApiName.Panel) + "/" + panelId;
  //      return this.http
  //          .put(putPanelUrl, panelObj, { headers: contentHeaders })
  //          .toPromise()
  //          .then(response => {
  //              return response;
  //          },
  //          response => {
  //              return response;
  //          })
  //          .catch(this.errorHandlerObj.handleServerError);
  //  }

}