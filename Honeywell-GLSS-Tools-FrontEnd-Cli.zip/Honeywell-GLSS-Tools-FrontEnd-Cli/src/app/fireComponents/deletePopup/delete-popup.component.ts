import { Component, OnInit, Output, ViewChild, EventEmitter, ElementRef } from "@angular/core";
import { DeleteModel } from "../../model/deleteModel";
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "deletePopup-app",
    templateUrl: "./delete-popup.component.html",
    styleUrls: ["./delete-popup.component.css"]
})
export class DeletePopupComponent {

    @Output()
    deleteSiteEvent = new EventEmitter();

    @Output()
    deletePanelEvent = new EventEmitter();

    @Output()
    deleteTimerEvent = new EventEmitter();

    @Output()
    deletePanelModuleEvent = new EventEmitter();

    @Output()
    deleteDeviceEvent = new EventEmitter();

    @Output()
    deleteZoneEvent = new EventEmitter();

    @Output()
    deleteMulZoneViewEvent = new EventEmitter();

    @ViewChild("closeBtn")
    closeBtn: ElementRef;

    //For Internationalization
    globalInstance = Globals.getInstance();
    literal = this.globalInstance.literalObj;

    popupLabel = { text: this.literal["DELETE_POPUP_LABEL"], visible: true };
    confirmationMsg = { text: this.literal["DELETE_CONFIRMATION_MSG"], visible: true };    
    lastUpdated = { text: this.literal["DELETE_LASTUPDATED"], visible: true };
    lastUpdatedOn = { text: "", visible: true };
    enterPassword = { text: this.literal["DELETE_ENTER_PASSWORD"], visible: true };
    deleteFiles = { text: this.literal["DELETE_FILES"], visible: true };
    delBtn = { text: this.literal["COMMON_DELETE"], visible: true };
    cancel = { text: this.literal["COMMON_CANCEL"], visible: true };
    deleteNote = { text: this.literal["ZONE_DELETE_NOTE"], visible: false };
    deletemsg = { text: this.literal["DELETE_MESSAGE_SITE"], visible: true };
    deleteicon = "site.png";
    description = { visible: false };
    projId = { visible: true };
    showDeleteicon: boolean = true;

    currentDeleteObj: DeleteModel;

    constructor()
    {
        this.currentDeleteObj = new DeleteModel();        
    }

    onClose()
    {
        this.currentDeleteObj = new DeleteModel();        
    }

    deleteData()
    {
        switch (this.currentDeleteObj.id)
        {
            case "Site":
                this.deleteSiteEvent.emit();
                break;
            case "Panel":
                this.deletePanelEvent.emit();
                break;
            case "Modules":
                this.deletePanelModuleEvent.emit();
                break;
            case "Timer":
                this.deleteTimerEvent.emit();
                break;
            case "Devices":
                this.deleteDeviceEvent.emit();
                break;
            case "Zone":
                this.deleteZoneEvent.emit();
                break; 
            case "MulZone":
                this.deleteMulZoneViewEvent.emit();
                break; 
            default:
                break;
        }
        this.currentDeleteObj = new DeleteModel();
    }
}
