import { Component, EventEmitter, Output, Input } from '@angular/core';
import { Globals } from "../../shared/hooks/globals";
import { Router } from "@angular/router";
import { Headerservice } from "../../fireComponents/header/header.service";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";

@Component({
    selector: "Bluetooth-Pairing-app",
    templateUrl: "./bluetooth.pairing.component.html",
    styleUrls: ["./bluetooth.pairing.component.css"]
})
export class BluetoothPairingComponent {
    globalInstance = Globals.getInstance();
    headerText = { text: this.globalInstance.getLiteral("BLUETOOTH-PARINING-HEADER-MESSAGE") , visible: true };
    bodyText = { text: this.globalInstance.getLiteral("BLUETOOTH-PARINGI-BODY-MESSAGE"), visible: true }
    next = { text: this.globalInstance.getLiteral("COMMON_NEXT"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };
    devicePin: string;
    constructor(private headerserviceObj: Headerservice)
    {

    }
    PairBluetooth()
    {
        this.headerserviceObj.pairBluetoothDeviceSrv(parseInt(this.devicePin)).subscribe((data) => { return data; })
    }
}
