import { Input, Component, ViewChild, HostListener, Output, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { Panel } from "../../model/panel";
import { Loop } from "../../model/Loop";
import { OnBoardIO } from "../../model/OnBoardIO";
import { LBCData } from "../lbcData/lbcdata.component";
import { LBCPanel } from "../../model/LbcPanel";
import { LBCLoop } from "../../model/LBCLoop";

@Component({
    selector: "lbcListView-app",
    templateUrl: "./lbclistview.component.html",
    styleUrls: ["./lbclistview.component.css"]
})
export class LBCListViewComponent {
    
    @Input() lbcData: LBCPanel;
    @Output() SelectedOnBoardEvent = new EventEmitter();
    @Output() SelectedLoopEvent = new EventEmitter();
    selectedList:any;
    //For Internationalization
    globalInstance = Globals.getInstance();
    literal = this.globalInstance.literalObj;
    isPanelSelected: boolean = true;
    
    ngOnInit()
    {
        debugger;
        if (this.isPanelSelected && this.lbcData && this.lbcData.loopsList != null) {
            if (this.lbcData.loopsList.length > 1) { 
                
                this.selectedList = this.lbcData.loopsList[0];
                this.SelectedLoopEvent.emit(this.selectedList);
            }
        }
    }

    ngOnChanges()
    {
        if (this.isPanelSelected && this.lbcData && this.lbcData.loopsList != null) {
            if (this.lbcData.loopsList.length > 1) {                
                this.selectedList = this.lbcData.loopsList;
            }
        }
    }   

    lbcOnBoardIOInfo(onBoardIOValue: OnBoardIO) {
        this.selectedList = onBoardIOValue;
        this.SelectedOnBoardEvent.emit(onBoardIOValue);
    }

    lbcLoopInfo(loopValue: LBCLoop) {
        this.selectedList = loopValue;
        this.SelectedLoopEvent.emit(loopValue);
    }
}
