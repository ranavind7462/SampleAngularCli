import { Input, Component, ViewChild, HostListener, Output, EventEmitter, OnChanges,OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { Zone, ZoneContentView } from "../../model/zone";


@Component({
    selector: "zonelist-app",
    templateUrl: "./zoneList.html",
    styleUrls: ["./zoneList.css"]
})
export class ZoneListComponent {
    @Input() zoneList: Zone[];
    @Output()
    selectedZoneEvent = new EventEmitter(); 

   zoneSelected: Zone;

    //For Internationalization
    globalInstance = Globals.getInstance();
    literal = this.globalInstance.literalObj;
    
    ngOnInit()
    {
        if (this.zoneList && this.zoneList.length > 1) {
            this.zoneList = this.globalInstance.getZoneNumberDisplay(this.zoneList);
            this.zoneSelected = this.zoneList[0];
        }
    }

    ngOnChanges()
    {

        if (this.zoneList && this.zoneList.length > 1) {
            this.zoneList = this.globalInstance.getZoneNumberDisplay(this.zoneList);
            this.zoneSelected = this.zoneList[0];
        }
    }

    zoneInfo(zone: Zone)
    {
        this.zoneSelected = zone;
        this.selectedZoneEvent.emit(zone);
    }
}
