import { Component, OnInit } from "@angular/core";
import { Globals } from "../../shared/hooks/globals";


@Component({
    selector: "loopstatus-app",
    templateUrl: "./loopstatus.component.html",
    styleUrls: ["./loopstatus.component.css"]
})

export class LoopStatus implements OnInit {

    //For Internaliization
    globalInstance = Globals.getInstance();

    lbcStatus = { text: this.globalInstance.getLiteral("LBC_STATUS"), visible: true };   
    lbcPass = { text: this.globalInstance.getLiteral("LBC_PASS"), visible: true }; 
    lbcFail = { text: this.globalInstance.getLiteral("LBC_FAIL"), visible: true }; 
    lbcViewDetails = { text: this.globalInstance.getLiteral("LBC_VIEWDETAILS"), visible: true }; 
    lbcLoop1 = { text: this.globalInstance.getLiteral("LBC_LOOP1"), visible: true }; 
    lbcLoop2 = { text: this.globalInstance.getLiteral("LBC_LOOP2"), visible: true }; 

    ngOnInit() {
       
    }
}
