import { Component, Input, OnChanges } from "@angular/core";
import { AlertTypes } from "../../model/alertTypes";

@Component({
    selector: "dlsalertbox-app",
    templateUrl: "./dlsAlertBox.component.html",
    styleUrls: ["./dlsAlertBox.component.css"]
})
export class DlsAlertBoxComponent implements OnChanges {
    @Input()
    message;

    @Input()
    type;

    private imageSource: any;
    private dlsalertboxColor: any;
    private dlsalertboxBorderColor: any;

    ngOnChanges(changes: any) {
        switch (this.type) {
            case AlertTypes.Warning:
                {
                    this.imageSource = "app/shared/images/alertWhite.png";
                    this.dlsalertboxColor = "dlsalertbox__color--warning";
                    this.dlsalertboxBorderColor = "dlsalertbox__border--warning";
                    break;
                }
            case AlertTypes.Error:
                {
                    this.dlsalertboxBorderColor = "dlsalertbox__border--error";
                    this.dlsalertboxColor = "dlsalertbox__color--error";
                    this.imageSource = "app/shared/images/criticalWhite.png";
                    break;
                }
            case AlertTypes.Info:
                {
                    this.dlsalertboxBorderColor = "dlsalertbox__border--information";
                    this.dlsalertboxColor = "dlsalertbox__color--information";
                    this.imageSource = "app/shared/images/infoWhite.png";
                    break;
                }
        }
    }
}
