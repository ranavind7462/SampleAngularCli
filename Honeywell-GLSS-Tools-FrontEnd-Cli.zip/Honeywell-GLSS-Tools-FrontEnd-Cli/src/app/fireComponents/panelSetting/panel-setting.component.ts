import { Input, Component, ViewChild, Output, EventEmitter,OnInit,DoCheck} from '@angular/core';
import { Globals } from "../../shared/hooks/globals";
import { TimerComponent } from "../../fireComponents/Timer/timer.component";
import { Panel } from "../../model/panel";
import { Timer } from "../../model/timer";
import { PanelService } from "../../baseComponents/panel/panel.service";

@Component({
    selector: "panelSetting-app",
    templateUrl: "./panel-setting.component.html",
    styleUrls: ["./panel-setting.component.css"]
})
export class PanelSettingComponent
    implements OnInit
{
    @ViewChild(TimerComponent)
    timerModal: TimerComponent;

    @Input() currentSetting: Panel;

    //@Output() onPanelClick = new EventEmitter<Panel>();
    panelSetting: Panel;

    ngOnChanges()
    {
        this.panelSetting = Object.assign({}, this.currentSetting);
    }


    buttonClick(clickType: string)
    {
        this.panelServiceObj.editPanelSrvc(this.panelSetting);
        this.currentSetting = this.panelSetting;
        this.settingSaveClick.emit(this.panelSetting);       
    }

    @Output() settingSaveClick = new EventEmitter<Panel>();
    @Output() onAddTimerClick = new EventEmitter();
    showDetectionMode: boolean = false;
    detectionModemaxSec: number = 60;
    errormsg: string = "nothing"

    constructor(private panelServiceObj: PanelService)
    {
    }

    ngOnInit()
    {        
        this.globalInstance.saveCancelClick(false);
    }

       
    //For Globalization
    globalInstance = Globals.getInstance();

    //Html elements with its properties
    loops = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_LOOPS"), visible: true };
    protocol = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_PROTOCOL"), visible: false };
    morelyIAS = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_MORELY_IAS"), visible: true };
    enableDeviceBlink = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_ENABLE_DEVICE_BLINKING"), visible: true };
    servicDetail = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SERVICE_DETAILS"), visible: true };
    phonNumber = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_PHONE_NUMBER"), visible: true };
    typePhoneNumber = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_TYPE_PHONE_NUMBER"), visible: true };
    nextServicDate = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_NEXT_SERVICE_DATE"), visible: true };
    sysIOCard = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SYSTEM_IO_CARD"), visible: true };
    enableSysIOCardFitted = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_ENABLE_SYS_IO_CARD_FITTED"), visible: true };
    fatFbeFitted = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_MORELY_FAT_FBE_FITTED"), visible: true };
    sysIOSounder2 = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_ENABLE_DEVICE_SYSTEM_IO_SOUNDER2"), visible: true };
    miscellaneous = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SERVICE_MISCELLANEOUS"), visible: true };
    softwareVersion = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SOFTWARE_VERSION"), visible: true };
    noPanelConnected = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_NO_PANEL_CONNECTED"), visible: true };
    panelLanguages = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_PANEL_LANGUAGES"), visible: true };
    dateFormat = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_DATE_FORMAT"), visible: true };
    acessTimeout = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_ACESS_TIMEOUT"), visible: false };
    mins = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_MINS"), visible: true };
    inhibTimeout = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_INHIBIT_TIMEOUT"), visible: true };
    sec = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SEC"), visible: true };
    noOfRepeater = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_NO_OF_REPEATERS"), visible: true };
    enableLogDiagnostic = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_ENABLE_LOG_DIAGNOSTICS"), visible: true };
    enableAutomatiResound = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_ENABLE_AUTOMATIC_RESOUND"), visible: true };
    enableExtendPsuFitted = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_ENABLE_EXTENDED_PSU_FITTED"), visible: true };
    enableSoundeGroup = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_ENABLE_SOUNDER_GROUP"), visible: true };
    defaultSoundeMode = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_DEFAULT_SOUNDER_MODE"), visible: true };
    stage1_2 = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_SATGE_1_2"), visible: true };
    timerDetectionMode = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_TIMER_DETECTION_MODE"), visible: true };
    detectionMode = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_DETECTION_MODE"), visible: true };
    newTimer = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_NEW_TIMER"), visible: true };
    save = { text: this.globalInstance.getLiteral("COMMON_SAVE"), visible: true };
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: true };

    nextServiceDateErrMsg = { text: this.globalInstance.getLiteral("PANEL_SETTING_NEXT_SERVICE_DATE_ERR_MSG"), visible: true };
    acessTimeoutErrMsg = { text: this.globalInstance.getLiteral("PANEL_SETTING_ACESS_TIMEOUT_ERR_MSG"), visible: true };
    inhibitTimeoutErrMsg = { text: this.globalInstance.getLiteral("PANEL_SETTING_INHIBIT_TIMEOUT_ERR_MSG"), visible: true };
    noOfRepeatersErrMsg = { text: this.globalInstance.getLiteral("PANEL_SETTING_NO_OF_REPEATERS_ERR_MSG"), visible: true };
    defaultSounderModeErrMsg = { text: this.globalInstance.getLiteral("PANEL_SETTING_SOUNDER_MODE_ERR_MSG"), visible: true };


    private Sounders = [
        { value: 0, text: "SND" },
        { value: 1, text: "AUX" }
    ];

    private Languages = [
        { value: 0, text: "ENGLISH" },
        { value: 1, text: "SWEDISH" },
        { value: 2, text: "SPANISH" },
        { value: 3, text: "PORTUGUESE" },
        { value: 4, text: "ICELANDIC" },
        { value: 5, text: "ITALIAN" },
        { value: 6, text: "POLISH" },
        { value: 7, text: "HUNGARIAN" },
        { value: 8, text: "SLOVENIAN " },
        { value: 9, text: "DUTCH" },
        { value: 10, text: "FRENCH" },
        { value: 11, text: "GERMAN" },
        { value: 12, text: "BELGIUM" },
        { value: 13, text: "DANISH" },
        { value: 14, text: "NORWEGIAN" },
        { value: 15, text: "CZECH" },
        { value: 16, text: "UNKNOWN" },
        { value: 17, text: "TURKISH" },
        { value: 18, text: "RUSSIAN" },
        { value: 19, text: "ROMANIAN" },
        { value: 20, text: "BULGARIAN" },
        { value: 21, text: "AUSTRIAN" },
        { value: 22, text: "SLOVAK" },
        { value: 23, text: "CROATIAN" },
        { value: 24, text: "GREEK" },
        { value: 25, text: "LATVIAN" },
        { value: 26, text: "ESTONIAN" },
        { value: 27, text: "LITHUANIAN" },
        { value: 28, text: "INDONESIAN" }
    ];

    private dateFormats = [
        { value: 0, text: "DD-MM-YYYY" },
        { value: 1, text: "MM-DD-YYYY" }
    ];

    private Stages = [
        { value: 0, text: "Alert / Alarm" },
        { value: 1, text: "Alarm / Alert" }
    ];

    private DetectionModes = [
        { value: 0, text: "No Action" },
        { value: 1, text: "Sensitivity" },
        { value: 2, text: "Delayed" },
        { value: 3, text: "Verification" }
    ];
    validateRange(obj: any) {
        switch (obj.name) {
            case "accessTimeout":
                if (obj.value > 60 || obj.value < 1)
                    this.panelSetting.accessTimeout = null;
                break;

            case "inhibitTimeout":
                if (obj.value > 180 || obj.value < 0)
                    this.panelSetting.inhibitTimeout = null;
                break;

            case "noOfRepeaters":
                if (obj.value > 16 || obj.value < 0)
                    this.panelSetting.numberOfRepeater = null;
                break;

            case "defaultSounderMode":
                if (obj.value > 32 || obj.value < 1)
                    this.panelSetting.defaultSounderMode = null;
                break;


            case "nextServiceDate":
                if (isNaN(new Date(obj.value).valueOf()))
                    this.panelSetting.nextServiceDate = null;
                break;

        }
    }

    getPanelSetting(panelId: any): any
    {
        this.panelServiceObj
            .getPanel(panelId)
            .then(response => this.populateSettingContent(response));
    }

    populateSettingContent(resp): any
    {
        console.log(resp);
        this.panelSetting.label = resp.label;
        this.panelSetting.protocol = resp.protocol;
        this.panelSetting.phoneNo = resp.phoneNo;
        this.panelSetting.nextServiceDate = resp.nextServiceDate;
        this.panelSetting.isBlinking = resp.isBlinking;
        this.panelSetting.isIOCardFitted = resp.isIOCardFitted;
        this.panelSetting.isFatFbeFitted = resp.isFatFbeFitted;
        this.panelSetting.ioSounderId = resp.ioSounderId;
        this.panelSetting.softwareVer = resp.softwareVer;
        this.panelSetting.language = resp.language;
        this.panelSetting.dateFormat = resp.dateFormat;
        this.panelSetting.accessTimeout = resp.accessTimeout;
        this.panelSetting.inhibitTimeout = resp.inhibitTimeout;
        this.panelSetting.numberOfRepeater = resp.numberOfRepeater;
        this.panelSetting.isLogDiagnostic = resp.isLogDiagnostic;
        this.panelSetting.isAutoResound = resp.isAutoResound;
        this.panelSetting.isExtendedPSUFitted = resp.isExtendedPSUFitted;
        this.panelSetting.isSounderDisable = resp.isSounderDisable;
        this.panelSetting.defaultSounderMode = resp.defaultSounderMode;
        this.panelSetting.stage = resp.stage;
        this.panelSetting.detectionMode = resp.detectionMode;
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }  

    cancelClick()
    {
        this.globalInstance.saveCancelClick(false);
        this.populateSettingContent(this.currentSetting);
    }
}
