import { Component, Output, EventEmitter, ViewChild, ElementRef,OnInit } from "@angular/core";
import { Globals } from "../../shared/hooks/globals";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { DeviceTypes, FilterCriteria } from "../../model/DetailsTypes";

@Component({
    selector: "deviceFilter-app",
    templateUrl: "./filter.component.html",
    styleUrls: ["./filter.component.css"]
})
export class FilterComponet {
    globalInstance = Globals.getInstance();
    @ViewChild("closeBtn") closeBtn : ElementRef;
    filterPopupHeaderTxt = this.globalInstance.getLiteral("FILTER_DEVICES");
    clearAll = this.globalInstance.getLiteral("COMMON_CLEAR_ALL");
    cancel = { text: this.globalInstance.getLiteral("COMMON_CANCEL"), visible: false };
    add = { text: this.globalInstance.getLiteral("COMMON_APPLY"), visible: true };
    @Output() filterEvent = new EventEmitter<any>();
    detectors: DeviceTypes[]=[];
    modules: DeviceTypes[] = [];
    withLabel: boolean = false;
    withOutLabel: boolean = false;
    public filterCriteriaObj:FilterCriteria;
    constructor(private detailServiceObj: DetailsService) {
      // this.getDeviceTypesMasterData();
    }
    ngOnInit() {
        this.getDeviceTypesMasterData();
    }
    getDeviceTypesMasterData() {
        this.modules = [];
        this.detectors = [];
        this.detailServiceObj.getDeviceTypesSrvc().subscribe((data) => {
            data.forEach(i => {
                if (i.isDetector == true && i.isModule == false) {
                    this.detectors.push(i);
                }
                if (i.isModule == true && i.isDetector == false) {
                    this.modules.push(i);
                }
            });
            console.log(data);
        })
    }
    filter()
    {
        this.filterCriteriaObj = new FilterCriteria();
        this.filterCriteriaObj.DeviceTypes = [];

        this.detectors.filter(i => i.isSelected == true).forEach(i => {
            this.filterCriteriaObj.DeviceTypes.push(i.id);
        });
        this.modules.filter(i => i.isSelected == true).forEach(i => {
            this.filterCriteriaObj.DeviceTypes.push(i.id);
        });
        if (this.withLabel != false || this.withOutLabel != false) {
            if (this.withLabel == true) {
                this.filterCriteriaObj.DeviceWithLabel = true;
            }
            else if(this.withOutLabel == true) {
                this.filterCriteriaObj.DeviceWithLabel = false;
            }
        }
        console.log(this.filterCriteriaObj);
        this.filterEvent.emit(this.filterCriteriaObj);
        console.log(this.detectors);
        console.log(this.modules);
        this.close();
    }
    close() {
        this.closeBtn.nativeElement.click();
    }
    clearFilter() {
        this.filterCriteriaObj = new FilterCriteria();
        this.detectors.forEach(i => { i.isSelected = false; })
        this.modules.forEach(i => { i.isSelected = false; })
        this.withLabel = false;
        this.withOutLabel = false;
       // this.filterEvent.emit(this.filterCriteriaObj);

        
    }
    WithLabel(isWithLabel: boolean)
    {
       
        if (isWithLabel == true)
        {
           
            this.withOutLabel = false;
        }
        else if (isWithLabel == false) {
            this.withLabel = false;
           
        }
    }
}
