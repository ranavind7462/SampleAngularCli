import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";

@Component({
    selector: "lbcLoopParameter-app",
    templateUrl: "./lbcloopparameter.component.html",
    styleUrls: ["./lbcloopparameter.component.css"]
})
export class LBCLoopParaComponent {
    @Input()
    Protocol: string
    //For Internationalization
    globalInstance = Globals.getInstance();   
    loopProtocol = { text: this.globalInstance.getLiteral("LOOP_SETTING_LABEL_PROTOCOL"), visible: true };
    quantityRelay = { text: this.globalInstance.getLiteral("LBC_QUANTITYOFRELAY"), visible: true };
    cableType = { text: this.globalInstance.getLiteral("LBC_CABLETYPE"), visible: true };
    deviceDisribution = { text: this.globalInstance.getLiteral("LBC_DEVICEDISTRIBUTION"), visible: true };
    worstCase = { text: this.globalInstance.getLiteral("LBC_WORSTCASE"), visible: true };
    bestCase = { text: this.globalInstance.getLiteral("LBC_BESTCASE"), visible: true };
    alloec = { text: this.globalInstance.getLiteral("LBC_ALLOEC"), visible: true };
    evenlyac = { text: this.globalInstance.getLiteral("LBC_EVENLYAC"), visible: true };    
    cabletypearray = [
        { text: this.globalInstance.getLiteral("LBC_05MM"), value: 0, visible: true },
        { text: this.globalInstance.getLiteral("LBC_1MM"), value: 1, visible: true },
        { text: this.globalInstance.getLiteral("LBC_15MM"), value: 2, visible: true },
        { text: this.globalInstance.getLiteral("LBC_25MM"), value: 3, visible: true },
    ]
    ngOnInit() {
        this.Protocol = "MorleyIAS";    
    }    
}
