import { Component, OnInit, Input } from "@angular/core";
import { CacheComponent, StorageType, StorageKey } from "./../../shared/utility/cache.component";
import { Headerservice } from "../../fireComponents/header/header.service";
import { ZoneService } from "../../baseComponents/zone/zone.service";
import { Globals } from "../../shared/hooks/globals";
import { DeviceComplex } from "../../model/device";
import { DetailsService } from "../../baseComponents/shared/Details.service";
import { Observable } from "rxjs";

@Component({
    selector: "zonedevicesgrid-app",
    templateUrl: "./zonedevicesgrid.component.html"
})
export class ZoneDevicesGridComponent implements OnInit {
    
    constructor(private cacheComponentObj: CacheComponent, private zoneServiceObj: ZoneService, private detailsServiceObj: DetailsService)
    {
    }
    @Input() gridSource: DeviceComplex[];
    gridVisibility = "hidden";
    scrollSettings = { height: "50%", width: "auto", allowVirtualScrolling: false, autoHide: true, enableColumnScrolling: true };
    textWrapSettings = { wrapMode: "both" };
   
    //For Internaliization
    globalInstance = Globals.getInstance();   
    deviceAddress = { text: this.globalInstance.getLiteral("ZONE_DEVICE_ADDRESS"), visible: true };
    deviceType = { text: this.globalInstance.getLiteral("ZONE_DEVICE_TYPE"), visible: true };
    deviceLabel = { text: this.globalInstance.getLiteral("ZONE_DEVICE_LABEL"), visible: true };
    
    bingGrid(data: DeviceComplex[])
    {
        this.gridSource = data;
        if (this.gridSource && this.gridSource.length)
        {
            this.gridVisibility = "visible";
        }
        else
        {
            this.gridVisibility = "hidden";
        }
    }

    ngOnInit()
    {
        let zoneId: any = this.cacheComponentObj.getKeyData(StorageType.LocalStorage, StorageKey.selectedZoneId);
        if (zoneId)
        {
            this.dataByZoneId(zoneId);
        }
    }

    dataByZoneId(zoneId: any): any
    {
        // Get devices for zone id
        this.zoneServiceObj.getDevicesByZoneId(zoneId)
            .subscribe(
            dev =>
            {
                //Bind to view
                this.detailsServiceObj.getDeviceTypesSrvc().subscribe((i) =>
                {
                    dev.forEach((item) =>
                    {
                        var result = i.filter(i => i.id == item.deviceTypeId);
                        item.deviceType = result[0].deviceType;
                        item.address = this.globalInstance.getAddress(1, item.loopNumber, item.address, item.isDetector);
                        item.ImageUrl = this.detailsServiceObj.getImageUrl(item.deviceTypeId);
                    });
                    this.bingGrid(dev);
                });               
            },
            err => {
                // Log errors if any
                console.log(err);
            });
    }

}
