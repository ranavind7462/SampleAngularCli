import { Input, Component, ViewChild, HostListener, Output, EventEmitter, OnInit, DoCheck } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Globals } from "../../shared/hooks/globals";
import { LBCLoop } from '../../model/LBCLoop';
import { LBCPanel } from '../../model/LbcPanel';

@Component({
    selector: "lbcpanelbatterydetails-app",
    templateUrl: "./lbcpanelbatterydetails.component.html",
    styleUrls: ["./lbcpanelbatterydetails.component.css"]
})
export class LBCPanelBatteryComponent{   

    @Input()
    panelInfo: string;
    @Input() lbcData: LBCPanel;
    //For Internationalization
    globalInstance = Globals.getInstance();
    literal = this.globalInstance.literalObj;
    requiredCapacity = { text: this.globalInstance.getLiteral("LBC_REQUIRED_CAPACITY"), visible: true };
    normalOperation = { text: this.globalInstance.getLiteral("LBC_NORMAL_OPERATION"), visible: true };
    inAlarm= { text: this.globalInstance.getLiteral("LBC_INALARAM"), visible: true };
    deviceDisribution = { text: this.globalInstance.getLiteral("LBC_DEVICEDISTRIBUTION"), visible: true };
    worstCase = { text: this.globalInstance.getLiteral("LBC_WORSTCASE"), visible: true };
    bestCase = { text: this.globalInstance.getLiteral("LBC_BESTCASE"), visible: true };
    alloec = { text: this.globalInstance.getLiteral("LBC_ALLOEC"), visible: true };
    evenlyac = { text: this.globalInstance.getLiteral("LBC_EVENLYAC"), visible: true };    
    overallCurrent = { text: this.globalInstance.getLiteral("LBC_CURRENT_USAGE"), visible: true };    
    panelModule = { text: this.globalInstance.getLiteral("PANEL_CONFIGLIST_PANELMODULES"), visible: true };    
    loops = { text: this.globalInstance.getLiteral("PANEL_SETTING_LABEL_LOOPS"), visible: true };    
    others = { text: this.globalInstance.getLiteral("LBC_OTHERS"), visible: true };    
    batteryReq = { text: this.globalInstance.getLiteral("LBC_BATTERYUL"), visible: true };    
    
    
    LBC_OTHERS
    normalOperatoinValue = [
        { text: this.globalInstance.getLiteral("LBC_4HOURS"), value: 0, visible: true},
        { text: this.globalInstance.getLiteral("LBC_8HOURS"), value: 1, visible: true },
        { text: this.globalInstance.getLiteral("LBC_12HOURS"), value: 2, visible: true },
        { text: this.globalInstance.getLiteral("LBC_24HOURS"), value: 3, visible: true },
        { text: this.globalInstance.getLiteral("LBC_30HOURS"), value: 4, visible: true },
        { text: this.globalInstance.getLiteral("LBC_48HOURS"), value: 5, visible: true },
        { text: this.globalInstance.getLiteral("LBC_72HOURS"), value: 6, visible: true }
    ];
    inAlarmValue = [
        { text: this.globalInstance.getLiteral("LBC_5MINS"), value: 0, visible: true },
        { text: this.globalInstance.getLiteral("LBC_10MINS"), value: 1, visible: true },
        { text: this.globalInstance.getLiteral("LBC_20MINS"), value: 2, visible: true },
        { text: this.globalInstance.getLiteral("LBC_30MINS"), value: 3, visible: true },
        { text: this.globalInstance.getLiteral("LBC_60MINS"), value: 4, visible: true },
        { text: this.globalInstance.getLiteral("LBC_90MINS"), value: 5, visible: true },
    ]
    ngOnInit()
    {        
    
    }

    ngOnChange()
    {
    
    }   
}
