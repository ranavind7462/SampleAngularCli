import { Component, Input, Output, EventEmitter,OnChanges } from "@angular/core";
import { Module } from "../../model/modulesModel";
import { Detector } from "../../model/detectorModel";

@Component({
    selector: "deviceaddress-app",
    templateUrl: "./deviceaddress.component.html",
    styleUrls: ["./deviceaddress.component.css"]
})
export class DeviceAddressComponent {
    @Input() startDeviceAddress: number = 1;
    @Input() endDeviceAddress: number = 148;
    @Input() detectorsList: Detector[] = [];
    @Input() moduleList: Module[] = [];
    @Input() isDetector: boolean = true;
    @Input() deviceType: number;
    @Output() assignDeviceAddressEvent = new EventEmitter();
    selectedAddress: string = "";
    deviceAddress: number[] = [];
    title: any = "";
    lastSelectedAddress: number;
     createDeviceAddressRange(startDeviceAddress, endDeviceAddress) {
         this.deviceAddress = [];
         for (var i = startDeviceAddress; i <= endDeviceAddress; i++) {
           
            this.deviceAddress.push(i);
        }
         return this.deviceAddress;
    }
     ngOnChanges() {
         console.log("input changes");
             this.createDeviceAddressRange(this.startDeviceAddress, this.endDeviceAddress);
     }
    
     assignAddress(deviceAddress: number, event) {
         if (event.shiftKey) {
             if (this.lastSelectedAddress < deviceAddress) {
                 for (var i = this.lastSelectedAddress; i < deviceAddress; i++) {
                     var status = this.getClass(i+1);
                     if (status !== "deactive") {
                         this.assignDeviceAddressEvent.emit(i+1);
                     }
                     if (i+1 === deviceAddress)
                     {
                         this.lastSelectedAddress = deviceAddress
                     }

                 }
             }
             else {
                 for (var i = this.lastSelectedAddress; i > deviceAddress; i--) {
                     var status = this.getClass(i-1);
                     if (status !== "deactive") {
                         this.assignDeviceAddressEvent.emit(i-1);
                     }
                     if ((i -1) === deviceAddress) {
                         this.lastSelectedAddress = deviceAddress
                     }
                 }
             }
         }
         else {
             this.lastSelectedAddress = deviceAddress;
             var status = this.getClass(deviceAddress);
             if (status !== "deactive") {
                 this.assignDeviceAddressEvent.emit(deviceAddress);
             }
         }
       
     }
     getClass(deviceaddress: number)
     {
         var detecotrObj = this.detectorsList.filter(i => i.deviceAddress == deviceaddress.toLocaleString());
         if (detecotrObj.length > 0) {
            
             if (detecotrObj[0].id === undefined) {
                
                 if (detecotrObj[0].deviceTypeId == this.deviceType) {
                     this.title = this.deviceType;
                     return "active";
                 }
                 else {
                     this.title = detecotrObj[0].deviceTypeId;
                     return "deactive";
                 }
             }
             else {
                 this.title = detecotrObj[0].deviceTypeId.toString();
                 return "deactive";
             }
         }
         else {

             var modulesObj = this.moduleList.filter(i => i.deviceAddress == deviceaddress.toLocaleString());
             if (modulesObj.length > 0) {
                
                 if (modulesObj[0].id === undefined) {
                     console.log(this.deviceType);
                     if (modulesObj[0].deviceTypeId == this.deviceType) {
                         this.title = this.deviceType;
                         return "active";
                     }
                     else {
                         this.title = modulesObj[0].deviceTypeId;
                         return "deactive";
                     }
                 }
                 else {
                     this.title = modulesObj[0].deviceTypeId.toString();
                     return "deactive";
                 }
             }
             else
             {
                 this.title = "";
                 return "";
             }
         }
            
     }
}
